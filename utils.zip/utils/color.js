export const primaryColor = "#2196f3";
export const white = "#FFFFFF";
export const red = "#f50057";
export const blue1 = "#82b1ff";
