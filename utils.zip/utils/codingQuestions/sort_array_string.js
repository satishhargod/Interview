const arr = ['rohit', 'Rana', 'virat', 'dhoni', 'sachin', 'sahbag', 'jadeja'];
const sortedArr = arr.sort();

console.log(sortedArr);











