export const codingBabu = "https://codingbabu.com/category/javascript-excercise/";
export const fullstackCafe ="https://www.fullstack.cafe/blog/javascript-code-interview-questions";
export const top50codingquestion="https://www.keka.com/javascript-coding-interview-questions-and-answers"