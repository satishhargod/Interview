// Implement a function to find the sum of all the numbers in an array.

// const arr = [2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6];

// const sum = arr.reduce((acc, ind) => acc + ind, 0);

// console.log(sum);





const arr = [
  [
    ["created"],
    ["12-23-35534"],
    ["12-23-35534"],
    ["12-23-35534"],
    ["12-23-35534"],
  ],
  [
    "hello",
    ["12-23"],
    ["12-23"],
    ["12-23"],
    ["12-23"],
  ],
];


output = [
  {
    created: "12-23-35534",
    created: "12-23-35534",
    created: "12-23-35534",
    created: "12-23-35534",
  },
  {
    hello :"12-23",
    hello :"12-23",
    hello :"12-23",
    hello :"12-23",
  }
];