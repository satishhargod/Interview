import Pagination from "components/common/table/Pagination";
import DetailCard from 'components/common/DetailCard'
import HeadContent from 'components/common/HeadContent'
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

const Job = () => {
  const Data = {
    id:1,
    name: "CPB Contractors",
    email: "cpbfmail.com",
    phone: 1524789306,
    Total_jobs: 10,
    Total_ongoing_jobs: 5,
    Total_completed_jobs: 5
  }
  const navigate = useNavigate()
  const [page, setPage] = useState(1);
  // const demo="archer"
  return (
    <div>
      <div>
        <HeadContent
          title="Builders"
          searchEnabled={true}
          onSearch={() => { }}
          addButtonEnable={true}
          addButtonTitle="Add Site Job"
          onAdd={() => navigate(`/jobs/create`)}
          // onAdd={() => navigate(`/jobs/create/${demo}`)}
        />
      </div>
      <div>
        <div className="grid grid-cols-4 w-full gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <DetailCard
              data={Data}
              onView={() => { navigate(`/jobs/site/view/${Data.id}`) }}
              onDelete={() => { }}
              onEdit={() => { }}
              key={i}
              modal="job"
            />
          ))}
        </div>
        <Pagination
          currentPage={page}
          onPageChange={(page) => setPage(page)}
          pageSize={1}
          totalCount={50}
          className="!border-t-0 !px-0 !bg-transparent !border-0 !py-25"
        />
      </div>
    </div >
  )
}

export default Job