import CustomTable from "components/common/table/CustomTable";
import React, { useEffect, useState } from "react";
import HeadContent from "components/common/HeadContent";
import ConfirmationDialog from "components/common/ConfirmationDialog";
import { toastShow } from "redux/ducks/toast";
import { useDispatch, useSelector } from "react-redux";
import MaxComponentsColumn from "components/maxComponents/column";
import { IMaxComponentsData } from "types/maxCompoents/maxcomponents";
import EditMaxComponents from "components/maxComponents/EditMaxComponentsForm";
import { profileSelector } from "redux/ducks/profile";
import { RoleEnum } from "types/common/common";
import {
  addMaxComponent,
  deleteMaxComponent,
  getMaxComponents,
  updateMaxComponent,
} from "services/maxComponents";
import { RESPONSE_STATUS } from "helper/common/constant";
import { useForm } from "react-hook-form";

const MaxComponents = () => {
  //================================================================//
  //======================== Use State =============================//

  const [componentList, setComponentList] = useState<IMaxComponentsData[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  const [selectedComponentId, setSelectedComponentId] = useState<string | null>(
    null
  );
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState("");
  const [headerBtnTitle, setHeaderBtnTitle] = useState("");
  const [isDeleteLoading, setIsDeleteLoading] = useState(false);
  const [tableLoader, setTableLoader] = useState(false);

  const [searchKeyword, setSearchKeyword] = useState("");

  //================================================================//
  //======================= Use Effect & Hooks ======================//

  const logginUser = useSelector(profileSelector);
  const dispatch = useDispatch();
  const { setError } = useForm();

  useEffect(() => {
    logginUser.roles.includes(RoleEnum.Admin)
      ? setHeaderBtnTitle("Add Max Component")
      : setHeaderBtnTitle("Contact");
  }, [logginUser]);

  //================================================================//
  //======================= Submit Handler =========================//



  //================================================================//
  //========================== Api Calls ===========================//

  const fetchMaxComponentsData = async (filter: object) => {
    try {
      setTableLoader(true);
      const data = await getMaxComponents(filter);

      if (data.status === 200) {
        setComponentList(data.data.data.results);
        setPage(data.data.data.page);
        setTotalCount(data.data.data.totalResults);
        setSelectedComponentId(null);
      }
      setTableLoader(false);
    } catch (error) {
      setTableLoader(false);
      console.log("error: ", error);
    }
  };

  const sendEmail = () => {
    const recipient = "recipient@example.com";
    const subject = " subject";

    const mailtoLink = `mailto:${recipient}?subject=${encodeURIComponent(
      subject
    )}`;

    window.location.href = mailtoLink;
  };

  const handleDelete = async () => {
    try {
      setIsDeleteLoading(true);

      if (selectedComponentId) {
        const apiResponse = await deleteMaxComponent(selectedComponentId);
        dispatch(
          toastShow({
            message: apiResponse.data.message,
            type: apiResponse.data.responseType,
          })
        );
        if (apiResponse.data.responseType === RESPONSE_STATUS.success) {
          setIsDeleteLoading(false);
          setIsDeleteOpen(false);
          await fetchMaxComponentsData({
            page: 1,
            limit: pageSize,
          });
        }
        // Fetch Data From DB
        setIsDeleteOpen(false);
      }
      setIsDeleteLoading(false);
    } catch (error) {
      setIsDeleteLoading(false);
    }
  };

  return (
    <div>
      {/* Table Header */}
      <HeadContent
        title={"Max-Components"}
        addButtonTitle={headerBtnTitle}
        onSearch={(e) => {
          setSearchKeyword(e.target.value.trim());
        }}
        onAdd={() => {
          if (logginUser.roles.includes(RoleEnum.Admin)) {
            setModalTitle("Create Max-Component");
            setIsEditOpen(true);
          } else {
            sendEmail();
          }
        }}
      />

      {/* Listing */}
      <CustomTable
        data={componentList}
        columns={
          MaxComponentsColumn({
            setIsDeleteOpen,
            setIsEditOpen,
            setIsViewOpen,
            setSelectedComponentId,
            setModalTitle,
            totalCount,
            page,
            roles: logginUser.roles,
          }).columns
        }
        fetchData={fetchMaxComponentsData}
        searchKeyword={searchKeyword}
        totalCount={totalCount}
        page={page}
        setPage={setPage}
        pageSize={pageSize}
        isLoading={tableLoader}
        setIsLoading={setTableLoader}
        tbodyTdClassName="py-4"
      />

      {/* Add / Edit Modal */}
      {isEditOpen && (
        <EditMaxComponents
          isOpen={isEditOpen}
          title={modalTitle}
          submitBtnTitle={selectedComponentId ? "Update" : "Create"}
          selectedComponentId={selectedComponentId}
          setIsEditOpen={setIsEditOpen}
          setPage={setPage}
          onClose={() => {
            setSelectedComponentId(null);
            setIsEditOpen(false);
          }}
          pageSize={pageSize}
          fetchMaxComponentsData={fetchMaxComponentsData}
        />
      )}
      {/* Delete Modal */}
      {isDeleteOpen && selectedComponentId && (
        <ConfirmationDialog
          title="Are you sure?"
          message="This action can not be undone. Do you want to continue?"
          onClose={() => setIsDeleteOpen(false)}
          onConfirm={handleDelete}
          isOpen={isDeleteOpen}
          icon={<img src="/assets/images/bin.gif" alt="DELETE" />}
          isLoading={isDeleteLoading}
        />
      )}

      {/* View Modal */}
      {/* {selectedCompany && isViewOpen && (
        <ViewCompany
          data={selectedCompany}
          isOpen={isViewOpen}
          onClose={() => setIsViewOpen(false)}
          title={modalTitle}
          onSubmit={handleSubmit}
          isLoading={isLoading}
        />
      )} */}
    </div>
  );
};

export default MaxComponents;
