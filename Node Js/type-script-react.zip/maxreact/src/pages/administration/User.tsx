import CustomTable from "components/common/table/CustomTable";
import React, { useEffect, useState } from "react";
import HeadContent from "components/common/HeadContent";
import ConfirmationDialog from "components/common/ConfirmationDialog";
import UserColumn from "components/adminstration/users/column";
import { IUser } from "types/users/users";
import EditUser from "components/adminstration/users/EditUser";
import {
  DEFAULT_IMAGE,
  ErrorMessage,
  RESPONSE_STATUS,
} from "helper/common/constant";
import ViewUser from "components/adminstration/users/ViewUser";
import { addUser, deleteUser, getUserList, updateUser } from "services/users";
import { FaQuestion } from "react-icons/fa";
import { dispatchToast } from "helper/common/function";
import { ISelectOptions } from "types/common/common";
import { getRoleList } from "services/roles";

const User = () => {
  const initialValue: IUser = {
    name: "",
    email: "",
    avatar: "",
    status: null,
    username: "",
    avatarUrl: "",
    phone: "",
    roleId: "",
    type: "",
  };
  //================================================================//
  //======================== Use State =============================//

  const [usersList, setUsersList] = useState<IUser[]>([]);
  const [roles, setRoles] = useState<ISelectOptions[]>([]);

  const [totalCount, setTotalCount] = useState(usersList.length);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedUser, setSelectedUser] = useState<IUser | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [isStatusChangeopen, setIsStatusChangeOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState("");
  const [isDeleteLoading, setIsDeleteLoading] = useState(false);
  const [tableLoader, setTableLoader] = useState(false);

  const [searchKeyword, setSearchKeyword] = useState("");

  //================================================================//
  //======================= Use Effect & Hooks ======================//

  useEffect(() => {
    fetchUsers();
    fetchRoles();
  }, []);

  //================================================================//
  //======================= Submit Handler =========================//

  const handleSubmit = async (values: IUser) => {
    const formData = new FormData();

    formData.append("name", values.name);
    formData.append("email", values.email);
    formData.append("roleId", values.roleId as string);
    formData.append("status", values.status as any);
    formData.append("profileImage", (values.profileImage as File) || null);

    let userResponse;
    try {
     
      if (values.userId) {
        formData.append("id", values.userId);
        userResponse = await updateUser(formData);
      } else {
        userResponse = await addUser(formData);
      }
      if (userResponse) {
        if (userResponse.data?.responseType === RESPONSE_STATUS.success) {
          dispatchToast(userResponse.data.message, RESPONSE_STATUS.success);
          setIsEditOpen(false);
          await fetchUsers();
        } else {
          dispatchToast(userResponse.data.message, RESPONSE_STATUS.error);
        }
      }
    } catch (err) {
      dispatchToast(ErrorMessage.SomethingWentWrong, RESPONSE_STATUS.error);
    }
  };

  //================================================================//
  //========================== Api Calls ===========================//

  const fetchUsers = async (values?: {
    page: number;
    limit: number;
    search?: string;
  }) => {
    const companyResponse = await getUserList(values);
    if (companyResponse.status === 200) {
      setUsersList(companyResponse.data.data.results);
      setTotalCount(companyResponse.data.data.totalResults);
    }
  };

  const fetchRoles = async () => {
    try {
      const getRolesResponse = await getRoleList();
      if (getRolesResponse) {
        if (getRolesResponse.data?.responseType === RESPONSE_STATUS.success) {
          const getRoles = getRolesResponse.data.data;
          const filteredRoles = getRoles.results.map(
            (role: { _id: string; name: string; slug: string }) => {
              return { value: role._id, label: role.name };
            }
          );
          setRoles(filteredRoles);
        } else {
          setRoles([]);
        }
      }
    } catch (error) {
      setRoles([]);
    }
  };

  const updateUserStatusBySwitch = async () => {
    try {
      if (selectedUser && selectedUser.userId) {
        const updatedResponse = await updateUser({
          id: selectedUser.userId,
          status: !selectedUser.status,
        });

        if (updatedResponse.data?.responseType === RESPONSE_STATUS.success) {
          dispatchToast(updatedResponse.data.message, RESPONSE_STATUS.success);
          if (page === 1) {
            await fetchUsers();
          } else {
            setPage(1);
          }
        } else {
          dispatchToast(updatedResponse.data.message, RESPONSE_STATUS.error);
        }
      }
      setIsStatusChangeOpen(false);
      setIsViewOpen(false);
    } catch (err) {
      setIsViewOpen(false);
      setIsStatusChangeOpen(false);
      dispatchToast(ErrorMessage.SomethingWentWrong, RESPONSE_STATUS.error);
    }
  };

  const handleDelete = async () => {
    setIsDeleteLoading(true);
    if (selectedUser?.userId) {
      try {
        const deleteUserResponse = await deleteUser(selectedUser?.userId);

        if (deleteUserResponse.data?.responseType === RESPONSE_STATUS.success) {
          dispatchToast(
            deleteUserResponse.data.message,
            RESPONSE_STATUS.success
          );
          if (page === 1) {
            await fetchUsers();
          } else {
            setPage(1);
          }
        } else {
          dispatchToast(deleteUserResponse.data.message, RESPONSE_STATUS.error);
        }
        setIsDeleteOpen(false);
      } catch (error) {
        dispatchToast(ErrorMessage.SomethingWentWrong, RESPONSE_STATUS.error);
        setIsDeleteOpen(false);
      }
      setIsDeleteLoading(false);
    }
  };

  return (
    <div>
      {/* Table Header */}
      <HeadContent
        title={"Users"}
        addButtonTitle={"Add Users"}
        onSearch={(e) => {
          setSearchKeyword(e.target.value.trim());
        }}
        onAdd={() => {
          setIsEditOpen(true);
          setModalTitle("Create User");
          setSelectedUser(null);
        }}
      />

      {/* Users Listing */}
      <CustomTable
        data={usersList}
        columns={
          UserColumn({
            setIsDeleteOpen,
            setIsEditOpen,
            setIsViewOpen,
            setSelectedUser,
            setModalTitle,
            totalCount,
            setIsStatusChangeOpen,
            page,
          }).columns
        }
        fetchData={() => {}}
        searchKeyword={searchKeyword}
        totalCount={totalCount}
        page={page}
        setPage={setPage}
        pageSize={pageSize}
        isLoading={tableLoader}
        setIsLoading={setTableLoader}
      />

      {/* Add / Edit Modal */}
      {isEditOpen && (
        <EditUser
          fieldValue={selectedUser?.userId ? usersList[0] : initialValue}
          roles={roles}
          isLoading={isLoading}
          isOpen={isEditOpen}
          onClose={() => setIsEditOpen(false)}
          onSubmit={handleSubmit}
          title={modalTitle}
          submitBtnTitle={selectedUser?.userId ? "Update" : "Create"}
        />
      )}

      {/* Delete Modal */}
      {isDeleteOpen && (
        <ConfirmationDialog
          title="Are you sure?"
          message="This action can not be undone. Do you want to continue?"
          onClose={() => setIsDeleteOpen(false)}
          onConfirm={handleDelete}
          isOpen={isDeleteOpen}
          icon={<img src={DEFAULT_IMAGE.defaultDelete} alt="DELETE" />}
          isLoading={isDeleteLoading}
        />
      )}

      {/* View Modal */}
      {isViewOpen && (
        <ViewUser
          selectedUserId={selectedUser?.userId as string}
          isOpen={isViewOpen}
          onClose={() => setIsViewOpen(false)}
          title={"View User"}
          // onSubmit={handleSubmit}
          // isLoading={isLoading}
          onStatusChange={updateUserStatusBySwitch}
        />
      )}

      {/* Change status Confimation */}
      {isStatusChangeopen && (
        <ConfirmationDialog
          title="Are you sure?"
          message="You want to change User's Status?"
          onClose={() => setIsStatusChangeOpen(false)}
          onConfirm={() => {
            updateUserStatusBySwitch();
          }}
          isOpen={isStatusChangeopen}
          icon={<FaQuestion />}
          isLoading={isDeleteLoading}
        />
      )}
    </div>
  );
};

export default User;
