import CustomTable from "components/common/table/CustomTable";
import { useState } from "react";
import HeadContent from "components/common/HeadContent";
import ConfirmationDialog from "components/common/ConfirmationDialog";
import { DEFAULT_IMAGE } from "helper/common/constant";
import RolesColumn from "components/adminstration/roles/column";
import { useNavigate } from "react-router-dom";
import { getRoleList } from "services/roles";
import { Role } from "types/administration/role";


const Roles = () => {
  const [rolesList, setRolesList] = useState<Role[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState("");
  const [isDeleteLoading, setIsDeleteLoading] = useState(false);
  const [tableLoader, setTableLoader] = useState(false);

  const [searchKeyword, setSearchKeyword] = useState("");


  const fetchRoles = async(param :{page:number,limit:number}) => {
    const list=await getRoleList(param)
    setRolesList(list.data.data.results)
    setTotalCount(list.data.data.totalResults)
    setPage(list.data.data.page)
  }
  const navigate = useNavigate();

  // const handleSubmit = async (value: any) => {
  //   console.log(value);
  // };

  return (
    <div>
      {/* Table Header */}
      <HeadContent
        title={"Role & Permissions"}
        addButtonTitle={"Create New Role"}
        onSearch={(e) => {
          setSearchKeyword(e.target.value.trim());
        }}
        onAdd={() => navigate("/administration/roles/create")}
      />

      {/* Roles Listing */}
      <CustomTable
        data={rolesList}
        columns={
          RolesColumn({
            setIsDeleteOpen,
            setIsEditOpen,
            setIsViewOpen,
            setSelectedRoleId,
            setModalTitle,
            totalCount,
            page,
          }).columns
        }
        fetchData={fetchRoles}
        searchKeyword={searchKeyword}
        totalCount={totalCount}
        page={page}
        setPage={setPage}
        pageSize={pageSize}
        isLoading={tableLoader}
        setIsLoading={setTableLoader}
      />

      {/* Add / Edit Modal */}
      {/* {isEditOpen && (
        <EditUser
          fieldValue={selectedUserId ? usersList[0] : initialValue}
          isLoading={isLoading}
          isOpen={isEditOpen}
          onClose={() => setIsEditOpen(false)}
          onSubmit={(val: any) => console.log(val)}
          title={modalTitle}
          submitBtnTitle={selectedUserId ? "Update" : "Create"}
        />
      )} */}

      {/* Delete Modal */}
      {isDeleteOpen && (
        <ConfirmationDialog
          title="Are you sure?"
          message="This action can not be undone. Do you want to continue?"
          onClose={() => setIsDeleteOpen(false)}
          onConfirm={() => {}}
          isOpen={isDeleteOpen}
          icon={<img src={DEFAULT_IMAGE.defaultDelete} alt="DELETE" />}
          isLoading={isDeleteLoading}
        />
      )}

   
    </div>
  );
};

export default Roles;
