import Button from "components/common/button/Button";
import DetailCard from "components/common/DetailCard";
import OverviewData from "components/dashboard/OverviewData";

const Dashboard = () => {
  const Data = {
    email: "Abcxyz@gmail.com",
    name: "ABC Contractors",
    phone: "+01 123 456 789",
    address: "123 Pacific Highway North Sydney, ABC 1234, ABC",
    startDate: true,
    endDate: true,
  };
  return (
    <>
      <div className="relative mb-5">
        <h5 className="text-BrandBlack text-22 font-bold leading-150%">
          Dashboard
        </h5>
      </div>
      <OverviewData />

      <div className="flex items-center justify-between mb-6">
        <div className="relative">
          <h5 className="text-BrandBlack text-lg font-bold leading-150%">
            Recently created jobs
          </h5>
        </div>
        <div>
          <Button className={"!px-5"} title={"View More"} />
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 w-full gap-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <DetailCard
            key={i}
            data={Data}
            onDelete={() => {}}
            onView={() => {}}
            onEdit={() => {}}
          />
        ))}
      </div>
    </>
  );
};

export default Dashboard;
