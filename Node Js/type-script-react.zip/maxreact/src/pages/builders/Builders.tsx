import Pagination from "components/common/table/Pagination";
import DetailCard from "components/common/DetailCard";
import HeadContent from "components/common/HeadContent";
import React, { useEffect, useState } from "react";
import ConfirmationDialog from "components/common/ConfirmationDialog";
import { WarningIcon } from "icons";
import AddBuilder from "components/builders/AddBuilder";
import { useNavigate } from "react-router-dom";
import { deleteBuilder, getBuilders } from "services/builder";
import Loader from "components/common/Loader";
import { toastShow } from "redux/ducks/toast";
import { useAppDispatch } from "redux/Hooks";
import { IBuilderDetails } from "types/builders/builders";
import { RiErrorWarningLine } from "react-icons/ri";
import ViewBuilder from "components/builders/ViewBuilder";


const Builders = () => {
  //================================================================//
  //======================= Use State ===========================//
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [totalPages, setTotalPages] = useState(0);
  const [totalResults, setTotalResults] = useState(0);
  const [selectedBuilder, setSelectedBuilder] = useState<string>();
  const [allDataBuilders, setAllDataBuilders] = useState([]);
  const [loading, setLoading] = useState(true);

  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isDeleteAllowOpen, setIsDeleteAllowOpen] = useState(false);
  const [searchKeyword, setSearchKeyword] = useState("");
  const [isViewOpen, setIsViewOpen] = useState(false);
  const dispatch = useAppDispatch();


  const getBuilderData = async (filter: object) => {
    try {
      const data = await getBuilders(filter)
      if (data.status === 200) {
        setAllDataBuilders(data.data.data.results);
        // setPage(data.data.data.page)
        setTotalPages(data.data.data.totalPages)
        setTotalResults(data.data.data.totalResults)
      }
    } catch (error) {
      console.log('error: ', error);
    } finally {
      setLoading(false)
    }
  }

  //================================================================//
  //======================= Use Effect ===========================//
  useEffect(() => {
    const filter = {
      page: searchKeyword ? 1 : page,
      limit: pageSize,
      ...(searchKeyword && { search: searchKeyword }),
    }
    getBuilderData(filter)
  }, [page, searchKeyword])
  //================================================================//
  //======================= Use Hooks ===========================//

  const navigate = useNavigate()

  //================================================================//
  //======================= Submit Handler ===========================//

  //================================================================//
  //======================= Api Function ===========================//

  const handleDelete = async () => {
    if (selectedBuilder) {
      try {
        const deleteBuilderWithId = await deleteBuilder(selectedBuilder)
        dispatch(toastShow({ message: deleteBuilderWithId.data.message, type: deleteBuilderWithId.data.responseType }));
        if (deleteBuilderWithId.status === 200) {
          setIsDeleteAllowOpen(false);
          setLoading(true);
          const filter = {
            page: page,
            limit: pageSize
          }
          await getBuilderData(filter)
          setLoading(false)
        }
      } catch (error) {
        console.log('error: ', error);
      } finally {
        setIsDeleteAllowOpen(false);
      }


      // Fetch Data From DB
    }

  };

  return (
    <div>
      <HeadContent
        title="Builders"
        searchEnabled={!isEditOpen}
        onSearch={(e) => {
          if (e.target.value.trim() === "") {
            const response = getBuilderData({
              page: page,
              limit: pageSize,
            });
          }
          setSearchKeyword(e.target.value);
        }}
        addButtonEnable={!isEditOpen}
        addButtonTitle="Add Builder"
        onAdd={() => navigate("/builder/create")}
      />

      {!loading ? (
        totalResults !== 0 ? (
          <div>
            {/* Builders Listing */}
            <div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 w-full gap-4">
                {allDataBuilders.map((data: IBuilderDetails, i) => (
                  <DetailCard
                    data={data}
                    onView={() => {
                      setSelectedBuilder(data._id);
                      setIsViewOpen(true);
                    }}
                    onDelete={() => {
                      setSelectedBuilder(data._id);
                      setIsDeleteOpen(true);
                    }}
                    onEdit={() => {
                      setSelectedBuilder(data._id);
                      navigate(`/builder/edit/${data._id}`);
                    }}
                    key={i}
                  />
                ))}
              </div>
              <Pagination
                currentPage={page}
                onPageChange={(page) => setPage(page)}
                pageSize={pageSize}
                totalCount={totalResults}
                className="!border-t-0 !px-0 !bg-transparent !border-0 !py-25"
              />
            </div>

            {/* Builder Delete */}
            {selectedBuilder && (
              <div>
                <ConfirmationDialog
                  title="Are you sure?"
                  message="This action can not be undone. Do you want to continue?"
                  onClose={() => {
                    setIsDeleteOpen(false);
                  }}
                  onConfirm={() => {
                    setIsDeleteOpen(false);
                    setTimeout(() => {
                      setIsDeleteAllowOpen(true);
                    }, 200);
                  }}
                  isOpen={isDeleteOpen}
                  icon={<img src="/assets/images/bin.gif" alt="DELETE" />}
                />
                {isDeleteAllowOpen && (
                  <ConfirmationDialog
                    title="If you delete this Builder"
                    message="Account then, the system will delete entire data"
                    onClose={() => {
                      setIsDeleteAllowOpen(false);
                    }}
                    onConfirm={handleDelete}
                    isOpen={isDeleteAllowOpen}
                    icon={<RiErrorWarningLine className="text-red-500" />}
                  />
                )}
                {/* {isViewOpen && (
                  <ViewBuilder
                    selectedBuilder={selectedBuilder}
                    isOpen={isViewOpen}
                    onClose={() => setIsViewOpen(false)}
                    title={"Builder Details"}
                    // onSubmit={handleSubmit}
                    // isLoading={isLoading}
                  />
                )} */}
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center justify-center h-[calc(100vh-218px)] text-5xl">
            No Data Found
          </div>
        )
      ) : (
        <Loader />
      )}
    </div>
  );
};

export default Builders;
