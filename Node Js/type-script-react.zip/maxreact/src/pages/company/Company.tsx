import CustomTable from "components/common/table/CustomTable";
import React, { useState } from "react";
import HeadContent from "components/common/HeadContent";
import CompanyColumn from "components/company/column";
import EditCompanyForm from "components/company/EditCompanyForm";
import ConfirmationDialog from "components/common/ConfirmationDialog";
import ViewCompany from "components/company/ViewCompany";
import { ICompanyData } from "@/types/company/company";
import { createCompany, deleteCompany, getCompanies, updateCompany } from "services/company";
import { toastShow } from "redux/ducks/toast";
import { useDispatch } from "react-redux";
import { FaQuestion } from "react-icons/fa";

const Company = () => {

  const [companyList, setCompanyList] = useState<ICompanyData[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false)
  const [selectedCompany, setSelectedCompany] = useState<ICompanyData | null>(
    null
  );
  // const [searchResults, setSearchResults] = useState("");
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(10);

  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState("");
  const [isDeleteLoading, setIsDeleteLoading] = useState(false);
  const [tableLoader, setTableLoader] = useState(false)
  const [isStatusChangeOpen, setIsStatusChangeOpen] = useState(false);

  const [searchKeyword, setSearchKeyword] = useState("");
  const dispatch = useDispatch();

  const fetchCompanyData = async (values: { page: number, limit: number, search?: string, status?: boolean }) => {
    const companyResponse = await getCompanies(values)
    if (companyResponse.status === 200) {
      setCompanyList(companyResponse.data.data.results)
      setTotalCount(companyResponse.data.data.totalResults)
    }
  }

  const handleSubmit = async (value: ICompanyData ) => {

    setIsLoading(true);
    const params = {
      email: value.email,
      name: value.name,
      status: value.status,
    }
    try {
      const apiResponse = value.companyDetails && value.companyDetails._id ? await updateCompany({ ...params, id: value.companyDetails._id })
        : await createCompany(params);

      setIsStatusChangeOpen(false);
      dispatch(toastShow({ message: apiResponse.data.message, type: apiResponse.data.responseType }));
      if (apiResponse.status === 200) {
        setIsLoading(false);
        setIsViewOpen(false);
        setIsEditOpen(false);
        setTableLoader(true);
        await fetchCompanyData({
          page: value.companyDetails && value.companyDetails._id ? page : 1,
          limit: pageSize,
        })
        setTableLoader(false);
      } else {
        setIsLoading(false);
        return;
      }

    } catch (error) {
      // setIsEditOpen(false);
      setIsLoading(false);
    }
  };

  const initialFormValue: ICompanyData = {
    _id: '',
    name: "",
    email: "",
    status: true,
    phone: "",
    countryCode: "",
    createdAt: new Date().toString(),
  };

  // FOR DELETE COMPANY
  const handleDelete = async () => {
    try {
      setIsDeleteLoading(true)
      if (selectedCompany) {
        const apiResponse = await deleteCompany(selectedCompany?.companyDetails?._id ?? '')
        dispatch(toastShow({ message: apiResponse.data.message, type: apiResponse.data.responseType }));
        if (apiResponse.status === 200) {
          setIsDeleteLoading(false)
          setIsDeleteOpen(false);
          setTableLoader(true)
          await fetchCompanyData({
            page: page,
            limit: pageSize,
          })
          setTableLoader(false)
        }
        // Fetch Data From DB
        setIsDeleteOpen(false);
      }
      setIsDeleteLoading(false)
    } catch (error) {
      setIsDeleteLoading(false)
    }
  };

  return (
    <div>
      {/* Table Header */}
      <HeadContent
        title={"Companies"}
        addButtonTitle="Add Company"
        onSearch={(e) => {
          if (e.target.value.trim() === '') {
            const response = fetchCompanyData({
              page: page,
              limit: pageSize,
            })
          }
          setSearchKeyword(e.target.value.trim())
        }}
        onAdd={() => {
          setModalTitle("Create Company");
          setIsEditOpen(true);
          setSelectedCompany(null);
        }}
      />

      {/* Companies Listing */}
      <CustomTable
        data={companyList}
        columns={
          CompanyColumn({
            setIsDeleteOpen,
            setIsEditOpen,
            setIsViewOpen,
            setSelectedCompany,
            setIsStatusChangeOpen,
            setModalTitle,
            totalCount,
            page,
          }).columns
        }
        fetchData={fetchCompanyData}
        searchKeyword={searchKeyword}
        totalCount={totalCount}
        page={page}
        setPage={setPage}
        pageSize={pageSize}
        isLoading={tableLoader}
        setIsLoading={setTableLoader}
      />

      {/* Add / Edit Modal */}
      {isEditOpen && (
        <EditCompanyForm
          isOpen={isEditOpen}
          isLoading={isLoading}
          title={modalTitle}
          onClose={() => setIsEditOpen(false)}
          fieldValue={selectedCompany ? selectedCompany : initialFormValue}
          submitBtnTitle={selectedCompany ? "Update" : "Create"}
          onSubmit={handleSubmit}
        />
      )}
      {/* Delete Modal */}
      {selectedCompany && isDeleteOpen && (
        <ConfirmationDialog
          title="Are you sure?"
          message="This action can not be undone. Do you want to continue?"
          onClose={() => setIsDeleteOpen(false)}
          onConfirm={handleDelete}
          isOpen={isDeleteOpen}
          icon={<img src="/assets/images/bin.gif" alt="DELETE" />}
          isLoading={isDeleteLoading}
        />
      )}

      {/* View Modal */}
      {selectedCompany && isViewOpen && (
        <ViewCompany
          data={selectedCompany}
          isOpen={isViewOpen}
          onClose={() => setIsViewOpen(false)}
          title={modalTitle}
          onSubmit={handleSubmit}
          isLoading={isLoading}
        />
      )}
      {isStatusChangeOpen && (
        <ConfirmationDialog
          title="Are you sure?"
          message={`You want to ${selectedCompany && selectedCompany.status === false ? "Active" : "In-Active"
              } Company`}
          onClose={() => setIsStatusChangeOpen(false)}
          onConfirm={() => {
            selectedCompany && (selectedCompany.status = !selectedCompany.status);
            selectedCompany && handleSubmit(selectedCompany);;
          }}
          isOpen={isStatusChangeOpen}
          icon={<FaQuestion />}
          isLoading={isLoading}
        />
      )}
    </div >
  );
};

export default Company;
