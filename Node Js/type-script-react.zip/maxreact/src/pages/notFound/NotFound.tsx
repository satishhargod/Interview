import React from "react";
import { Link } from "react-router-dom";

const NotFound = () => {
  return (
    <>
      <div className="flex items-center justify-center h-[calc(100vh-134px)]">
        <div className="relative text-center inline-block xs:w-full md:w-auto max-w-350">
          <div className="relative mb-30 xs:ml-0 md:-ml-105 xs">
            <img className="max-w-full" src="/assets/images/404.svg" alt="" />
          </div>
          <div className="relative">
            <span className="text-black font-medium leading-150% tracking-1.236 block mb-5 text-2xl">
              Uh..oh
            </span>
            <h1 className="text-BrandBlack text-67 font-bold leading-150%">
              404 Error
            </h1>
            <p className="text-BrandBlack text-lg font-normal leading-150% tracking-0.899">
              Looks like this page doesn’t <br /> exist or was removed
            </p>
          </div>
            <div className="relative xs:w-full sm:w-350 py-[15px] bg-BrandBlack rounded-lg mx-auto xs:mt-14 md:mt-16">
              <Link
                to="/Login"
                className="text-white text-base font-medium leading-normal"
              >
                Back To Dashboard
              </Link>
            </div>
        </div>
      </div>
    </>
  );
};

export default NotFound;
