import { profileSelector, setProfile } from "redux/ducks/profile";
import Button from "components/common/button/Button";
import Input from "components/common/formInput/Input";
import HeadContent from "components/common/HeadContent";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import {
  convertFileToDataURL,
  getProfile,
  updateProfile,
} from "services/profile";
import FileUploader from "components/common/FileUpload/FileUploader";
import ChangePassword from "components/profile/ChangePassword";
import { ProfileType, userProfile } from "types/dashboard/dashboard";
import AvatarUpload from "components/common/FileUpload/AvatarUpload";
import { yupResolver } from "@hookform/resolvers/yup";
import { nameConstraint } from "validation/auth/authValidation";
import {
  ALLOWED_IMAGE_MIME_TYPES,
  DEFAULT_COUNTRY_CODE,
  MAX_IMAGE_SIZE,
} from "helper/common/constant";
import { toastShow } from "redux/ducks/toast";
import CustomPhoneInput from "components/common/formInput/CustomPhoneInput";
import {
  isValidPhoneNumber,
  separateCountryCodePhone,
} from "helper/common/function";

const Profile = () => {
  const dispatch = useDispatch();
  const profile = useSelector(profileSelector);
  const [loginProcess, setLoginProcess] = useState(false);
  const [errorMessageImage, setErrorMessageImage] = useState<
    string | undefined
  >(undefined);
  const [profileData, setProfileData] = useState<ProfileType>(profile);
  const [initialProfileData, setInitialProfileData] =
    useState<ProfileType>(profile);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    getValues,
    watch,
  } = useForm<userProfile>({
    defaultValues: {
      name: "",
      email: profileData?.email || "",
      phone: "",
      countryCode: DEFAULT_COUNTRY_CODE,
      file:
        profileData?.image instanceof File
          ? undefined
          : profileData?.image || undefined,
    },
    resolver: yupResolver(nameConstraint),
  });

  const countryCode = watch("countryCode");
  useEffect(() => {
    setValue("countryCode", countryCode);
  }, [countryCode]);

  useEffect(() => {
    setPhoneValues(profile.phone);
    setValue("name", profile.name);
    setInitialProfileData(profile);
  }, [profile]);

  const displayErrorMessage = (errorMessage?: string) => {
    return errorMessage ? (
      <span className="text-Darkred block -mt-5 mb-5">{errorMessage}</span>
    ) : null;
  };

  const onSubmit = async (values: userProfile) => {
    if (errorMessageImage) {
      return;
    }

    const hasChanges =
      values.name !== initialProfileData.name ||
      (profileData.image !== null && profileData.image !== values.file) ||
      initialProfileData.phone !== values.phone;

    if (hasChanges) {
      const formData = new FormData();
      formData.append("name", values.name);
      formData.append("file", profileData.image);
      values.phone.trim() !== "" &&
        formData.append("phone", `${values.countryCode}${values.phone}`);
      formData.append(
        "isImageDeleted",
        profileData.image === "" ? "true" : "false"
      );

      setLoginProcess(true);
      try {
        const loginResponse = await updateProfile(formData);
        dispatch(
          toastShow({
            message: loginResponse.data.message,
            type: loginResponse.data.responseType,
          })
        );
        if (loginResponse.status === 200) {
          const data = await getProfile(profileData.id);

          dispatch(
            setProfile({
              email: data?.data?.data.user.email,
              name: data?.data?.data.user.name,
              userName: data?.data?.data.user.username,
              phone: data.data.data.user.phone,
              image:
                data?.data?.data.user.avatar !== null
                  ? data?.data?.data.user.avatarUrl
                  : null,
              id: data?.data?.data.user._id,
              roles: profile.roles,
            })
          );
        }
        setLoginProcess(false);
      } catch (err) {
        setLoginProcess(false);
      }
    }
  };

  const checkImageType = (image: string) =>
    !ALLOWED_IMAGE_MIME_TYPES.includes(image);
  const checkImageSize = (image: number) => image > MAX_IMAGE_SIZE;

  const handleEditImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const image = e.target.files?.[0] || null;

    if (!image) return;

    if (checkImageType(image.type?.trim())) {
      setErrorMessageImage("Please upload valid image type.");
      return;
    }
    if (checkImageSize(image.size)) {
      setErrorMessageImage(
        "Please upload an image with a size less than 10 MB."
      );
      return;
    }

    setErrorMessageImage(undefined);
    const updatedProfileData = { ...profileData, image: image };
    setProfileData(updatedProfileData);
  };
  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const image = e.target.files?.[0] || null;
    if (!image) return;

    if (checkImageType(image.type?.trim())) {
      setErrorMessageImage("Please upload valid image type.");
      return;
    }
    if (checkImageSize(image.size)) {
      setErrorMessageImage(
        "Please upload an image with a size less than 10 MB."
      );
      return;
    }
    setErrorMessageImage(undefined);
    const updatedProfileData = { ...profileData, image: image };
    setProfileData(updatedProfileData);
  };

  // Function For Separate Country Code & phone and set
  const setPhoneValues = async (phoneNumber: string) => {
    if (phoneNumber) {
      const { countryCode, phone } = separateCountryCodePhone(phoneNumber);
      setValue("countryCode", countryCode);
      setValue("phone", phone);
    }
  };

  return (
    <div>
      {/* Table Header */}
      <HeadContent
        title={"Profile"}
        addButtonEnable={false}
        searchEnabled={false}
      />
      <div className={`flex gap-30 md:flex-col lg:flex-row`}>
        <div className="md:w-full lg:w-2/4 p-30 bg-white border border-solid border-loginBorder rounded-xl">
          <div className="relative">
            <p className="text-BrandBlack text-xl font-medium leading-normal mb-1.5">
              Personal Info
            </p>
            <p className="text-BrandBlack text-sm font-normal leading-normal">
              Details about your personal information
            </p>
          </div>
          <div>
            <div className="flex items-center gap-30 my-6">
              <AvatarUpload
                src={profileData.image}
                alt={"profileImgAlt"}
                handleDeleteImage={() => {
                  const updatedProfileData = { ...profileData, image: "" };
                  setProfileData(updatedProfileData);
                }}
                handleImageChange={handleImageChange}
                handleEditImage={handleEditImage}
              />
              <FileUploader
                handleImageChange={(e: any) => {
                  handleEditImage(e);
                  handleImageChange(e);
                }}
              />
            </div>
            {displayErrorMessage(errorMessageImage)}
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className=" flex flex-col gap-6">
                <Input
                  label="Name"
                  placeholder="Enter Your Name"
                  type="text"
                  register={register("name")}
                  className={`!px-15 !py-2.5 ${
                    errors.name ? "border-Darkred" : ""
                  }`}
                  error={errors.name?.message as string}
                />
                <Input
                  label="Email"
                  placeholder="Enter Your Email"
                  type="text"
                  register={register("email")}
                  disable={true}
                  className="!px-15 !py-2.5"
                />
                <CustomPhoneInput
                  label={"Phone Number"}
                  type="text"
                  className="!px-15 !py-2.5"
                  registerPhoneNo={register("phone", {
                    pattern: {
                      value: /^[0-9+-]+$/,
                      message: "Enter Number's only",
                    },
                  })}
                  registerCountryCode={register("countryCode", {
                    required: "Country Code is Required",
                  })}
                  setValueCountry={(value) => setValue("countryCode", value)}
                  error={errors.phone?.message || errors.countryCode?.message}
                  getValueCountry={getValues("countryCode") as string}
                />
              </div>
              <Button
                title="Save Changes"
                variant="filled"
                type="submit"
                isLoading={loginProcess}
                className={"mt-30 !w-auto !py-2.5 !px-15 ml-auto block"}
              />
            </form>
          </div>
        </div>
        <div className="md:w-full lg:w-2/4 p-30 bg-white border border-solid border-loginBorder rounded-xl">
          <div>
            <ChangePassword />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
