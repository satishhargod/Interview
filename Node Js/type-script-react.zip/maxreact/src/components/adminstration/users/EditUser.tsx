import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import Loader from "components/common/Loader";
import { FaCircle } from "react-icons/fa";
import Button from "components/common/button/Button";
import Dialog from "components/common/Dialog";
import Input from "components/common/formInput/Input";
import Select from "components/common/formInput/Select";
import { IUser } from "types/users/users";
import AvatarUpload from "components/common/FileUpload/AvatarUpload";
import {
  ALLOWED_IMAGE_MIME_TYPES,
  MAX_IMAGE_SIZE,
  USER_TYPE,
  USER_TYPE_OPTION,
} from "helper/common/constant";
import FileUploader from "components/common/FileUpload/FileUploader";
import { userFormSchema } from "validation/administrator/administratorValidation";
import { ISelectOptions } from "types/common/common";

interface IEditUser {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  fieldValue: IUser;
  submitBtnTitle?: string;
  closeButton?: boolean;
  isLoading: boolean;
  onSubmit: (values: IUser) => void;
  roles: ISelectOptions[];
}

const EditUser = (props: IEditUser) => {
  const {
    isOpen,
    title,
    isLoading,
    onClose,
    fieldValue,
    submitBtnTitle = "Submit",
    closeButton = true,
    onSubmit,
    roles,
  } = props;

  const [innerLoader, setInnerLoader] = useState(false);
  const [profileImage, setProfileImage] = useState<string | File | null>(
    fieldValue.avatar || ""
  );
  const [errorMessageImage, setErrorMessageImage] = useState<string | null>(
    null
  );

  const {
    register,
    handleSubmit,
    setValue,
    setError,
    watch,
    getValues,
    formState: { errors },
  } = useForm({
    defaultValues: fieldValue,
    resolver: yupResolver(userFormSchema),
  });

  const watchType = watch("type");

  const STATUS_OPTIONS = [
    {
      value: true,
      label: "Active",
      icon: <FaCircle className="text-green-500" />,
    },
    {
      value: false,
      label: "Inactive",
      selected: false,
      icon: <FaCircle className="text-red-500" />,
    },
  ];

  const checkImageType = (image: string) =>
    !ALLOWED_IMAGE_MIME_TYPES.includes(image);
  const checkImageSize = (image: number) => image > MAX_IMAGE_SIZE;

  const handleEditImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const image = e.target.files?.[0] || null;

    if (!image) return;

    if (checkImageType(image.type?.trim())) {
      setErrorMessageImage("Please upload valid image type.");
      return;
    }
    if (checkImageSize(image.size)) {
      setErrorMessageImage(
        "Please upload an image with a size less than 10 MB."
      );
      return;
    }

    setErrorMessageImage(null);
    setProfileImage(image);
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const image = e.target.files?.[0] || null;
    if (!image) return;

    if (checkImageType(image.type?.trim())) {
      setErrorMessageImage("Please upload valid image type.");
      return;
    }
    if (checkImageSize(image.size)) {
      setErrorMessageImage(
        "Please upload an image with a size less than 10 MB."
      );
      return;
    }
    setErrorMessageImage(null);
    setProfileImage(image);
  };

  const onFormSubmit = (values: IUser) => {
    onSubmit({ ...values, profileImage: profileImage });
  };

  return (
    <div>
      <Dialog onClose={onClose} isOpen={isOpen} title={title}>
        <form
          onSubmit={handleSubmit(onFormSubmit)}
          className={`${innerLoader ? "h-406px rounded-14" : "h-full"}`}
        >
          {innerLoader ? (
            <Loader className={"rounded-14"} />
          ) : (
            <div className="flex gap-6 flex-col">
              <div className="flex items-center gap-30 my-6">
                <AvatarUpload
                  src={profileImage}
                  alt={"profileImgAlt"}
                  handleDeleteImage={() => {
                    setProfileImage("");
                  }}
                  handleImageChange={handleImageChange}
                  handleEditImage={handleEditImage}
                />
                <FileUploader
                  handleImageChange={(e: any) => {
                    handleEditImage(e);
                    handleImageChange(e);
                  }}
                />
              </div>

              {errorMessageImage && (
                <span className="text-Darkred block -mt-5 mb-5">
                  {errorMessageImage}
                </span>
              )}

              <Input
                label="Name"
                placeholder="Enter Name"
                register={register("name")}
                error={errors["name"]?.message as string}
                className="!px-15 !py-2.5"
              />
              <Input
                label="Email Address"
                placeholder="Enter Email"
                register={register("email")}
                error={errors["email"]?.message as string}
                className="!px-15 !py-2.5 !pr-8"
              />

              <Select
                label="Type"
                options={USER_TYPE_OPTION}
                register={register("type")}
                border="sm"
                defaultValue={roles.filter(
                  (opt) => opt.value === fieldValue.name
                )}
                error={errors["type"]?.message as string}
                onChange={(obj: ISelectOptions) => {
                  setError("type", { message: "" });
                  if (obj.value === USER_TYPE.worker) {
                    const roleId = roles.filter(
                      (role) => role.label.toLowerCase() === USER_TYPE.worker
                    );
                    if (roleId.length > 0) {
                      setValue("roleId", roleId[0].value);
                      setValue("type", obj.value);
                    } else {
                      setError("type", {
                        message: "Worker's Type Not Found in Server",
                      });
                    }
                  }else{
                    setError("type",{message : ""})
                    setValue("type", obj.value);
                    setValue("roleId","")
                  }
                }}
              />
              {watchType !== USER_TYPE.worker && (
                <Select
                  label="Roles"
                  options={roles.filter(
                    (role) => role.label.toLowerCase() !== USER_TYPE.worker
                  )}
                  register={register("roleId")}
                  border="sm"
                  defaultValue={roles.filter(
                    (opt) => opt.value === fieldValue.roleId
                  )}
                  error={errors["roleId"]?.message as string}
                  onChange={(obj: ISelectOptions) => {
                    setError("roleId", { message: "" });
                    setValue("roleId", obj.value);
                  }}
                />
              )}
              <Select
                label="Status"
                options={STATUS_OPTIONS}
                register={register("status")}
                border="sm"
                defaultValue={STATUS_OPTIONS.filter(
                  (opt) => opt.value === fieldValue.status
                )}
                error={errors["status"]?.message as string}
                onChange={(obj: any) => {
                  setError("status", { message: "" });
                  setValue("status", Boolean(obj.value));
                }}
              />
              <div className="flex items-center justify-end gap-2.5">
                {closeButton && (
                  <Button
                    type="button"
                    title={"Close"}
                    onClick={onClose}
                    className={
                      "!bg-BrandBlack/10 border !text-black !w-auto px-6"
                    }
                  />
                )}
                <Button
                  type="submit"
                  variant="filled"
                  isLoading={isLoading}
                  className={"!w-auto px-6"}
                  title={submitBtnTitle}
                />
              </div>
            </div>
          )}
        </form>
      </Dialog>
    </div>
  );
};

export default EditUser;
