// import { truncateString } from "helper/common/function";
import { IUser } from "types/users/users";
import React, { useMemo } from "react";
import { AiTwotoneEye } from "react-icons/ai";
import { PiPencilSimpleDuotone, PiTrashDuotone } from "react-icons/pi";
import { DEFAULT_IMAGE, USER_TYPE } from "helper/common/constant";
import Image from "components/common/Image";
import Switch from "components/common/formInput/Switch";

interface IUserColumn {
  setIsEditOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setIsDeleteOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setIsViewOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setSelectedUser: React.Dispatch<React.SetStateAction<IUser | null>>;
  setModalTitle: React.Dispatch<React.SetStateAction<string>>;
  totalCount: number;
  page: number;
  setIsStatusChangeOpen: React.Dispatch<React.SetStateAction<boolean>>;
}

const UserColumn = (props: IUserColumn) => {
  const {
    setIsDeleteOpen,
    setIsEditOpen,
    setIsViewOpen,
    setModalTitle,
    setSelectedUser,
    totalCount,
    page,
    setIsStatusChangeOpen,
  } = props;

  const calculateSerialNumber = (rowIndex: number) => {
    return (page - 1) * 10 + rowIndex + 1;
  };

  const tempColumn = [
    {
      header: "Sr No",
      cell: ({ row }: { row: { original: IUser; index: number } }) => {
        return <div>{calculateSerialNumber(row.index)}</div>;
      },
    },
    {
      header: "Username",
      cell: ({ row }: { row: { original: IUser } }) => {
        return (
          <React.Fragment>
            <div className="relative !w-10 !h-10 rounded-full flex items-center gap-2">
              <Image
                src={row.original.avatarUrl as string}
                defaultImage={DEFAULT_IMAGE.defaultAvatar}
              />
              {row.original.name}
            </div>
          </React.Fragment>
        );
      },
    },
    {
      header: "Email Address",
      cell: ({ row }: { row: { original: IUser } }) => {
        return <React.Fragment> {row.original.email} </React.Fragment>;
      },
    },
    {
      header: "Type",
      cell: ({ row }: { row: { original: IUser } }) => {
        return <React.Fragment> {row.original.userRoleData?.name?.includes(USER_TYPE.worker) ? "Worker" : "Staff"  } </React.Fragment>;
      },
    },
    {
      header: "Role",
      cell: ({ row }: { row: { original: IUser } }) => {
        return (
          <React.Fragment>
            {row.original.userRoleData?.name || "NO ROLE"}
          </React.Fragment>
        );
      },
    },
    {
      header: "Status",
      cell: ({ row }: { row: { original: IUser } }) => {
        return (
          <React.Fragment>
            {row.original.status !== null && (
              <Switch
                size="md"
                checked={row.original.status}
                onChange={() => {
                  setIsStatusChangeOpen(true);
                  setSelectedUser(row.original);
                }}
              />
            )}
          </React.Fragment>
        );
      },
    },
    {
      header: "Action",
      cell: ({ row }: { row: { original: IUser } }) => {
        return (
          <div className="flex gap-4">
            <div className="group relative">
              <AiTwotoneEye
                className="text-gray-600 w-6 h-6 cursor-pointer transition duration-300 ease-in-out transform"
                onClick={() => {
                  setModalTitle("View User");
                  setIsViewOpen(true);
                  setSelectedUser(row.original);
                }}
              />
              <div className="absolute left-1/2 z-10 transform -translate-x-1/2 bottom-full invisible group-hover:visible group-hover:opacity-100 bg-gray-800 text-white text-xs px-2 py-1 rounded transition-opacity">
                View
              </div>
            </div>

            <div className="group relative">
              <PiPencilSimpleDuotone
                className="text-gray-600 w-6 h-6 cursor-pointer transition duration-300 ease-in-out transform"
                onClick={() => {
                  setModalTitle("Edit User");
                  setIsEditOpen(true);
                  setSelectedUser(row.original);
                }}
              />
              <div className="absolute left-1/2 z-10 transform -translate-x-1/2 bottom-full invisible group-hover:visible group-hover:opacity-100 bg-gray-800 text-white text-xs px-2 py-1 rounded transition-opacity">
                Edit
              </div>
            </div>

            <div className="group relative">
              <PiTrashDuotone
                className="text-red-500 w-6 h-6 cursor-pointer transition duration-300 ease-in-out transform"
                onClick={() => {
                  setIsDeleteOpen(true);
                  setSelectedUser(row.original);
                }}
              />
              <div className="absolute left-1/2 z-10 transform -translate-x-1/2 bottom-full invisible group-hover:visible group-hover:opacity-100 bg-gray-800 text-white text-xs px-2 py-1 rounded transition-opacity">
                Delete
              </div>
            </div>
          </div>
        );
      },
    },
  ];

  const columns = useMemo(() => tempColumn, [page, totalCount]);
  return { columns };
};

export default UserColumn;
