import React, { useEffect, useState } from "react";
import Loader from "components/common/Loader";
import Button from "components/common/button/Button";
import Dialog from "components/common/Dialog";
import { IUser } from "types/users/users";
import Image from "components/common/Image";
import { DEFAULT_IMAGE } from "helper/common/constant";
import { getUserById } from "services/users";
import Switch from "components/common/formInput/Switch";

interface IViewUser {
  onClose: () => void;
  title?: string;
  selectedUserId: string;
  isOpen: boolean;
  onStatusChange?: () => void;
  //   isLoading: boolean;
  //   onSubmit: (values: ICompanyData) => void;
}

const ViewUser = (props: IViewUser) => {
  const { onClose, title, selectedUserId, isOpen, onStatusChange } = props;
  const [selectedData, setSelectedData] = useState<IUser | null>(null);
  const [isDataFetching, setIsDataFetching] = useState(true);

  const fetchSelectedUserData = async () => {
    setIsDataFetching(true);
    if (selectedUserId) {
      const userReponse = await getUserById(selectedUserId);
      if (userReponse) {
        setSelectedData(userReponse.data.data);
      }
    } else {
      setSelectedData(null);
    }
    setIsDataFetching(false);
  };

  useEffect(() => {
    fetchSelectedUserData();
  }, [selectedUserId]);

  return (
    <div>
      <Dialog
        onClose={onClose}
        title={title}
        isOpen={isOpen}
        className={`${!selectedData ? "h-406px rounded-14" : "h-full"}`}
      >
        {isDataFetching && <Loader />}
        {selectedData ? (
          <div className="flex flex-col">
            <div className="flex items-center justify-between w-full">
              <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
                Avatar :
              </span>
              <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
                <div className="relative w-10 h-10 rounded-full">
                  <Image
                    defaultImage={DEFAULT_IMAGE.defaultAvatar}
                    src={selectedData.avatarUrl || ""}
                  />
                </div>
              </span>
            </div>
            <div className="flex items-center justify-between w-full">
              <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
                Name :
              </span>
              <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
                {selectedData.name}
              </span>
            </div>
            <div className="flex items-center justify-between w-full">
              <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
                Email :
              </span>
              <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
                {selectedData.email}
              </span>
            </div>
            <div className="flex items-center justify-between w-full">
              <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
                Role :
              </span>
              <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
                {selectedData.userRoleData?.name || "No Role"}
              </span>
            </div>
            <div className="flex items-center justify-between w-full">
              <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
                Status :
              </span>
              <span className="text-gray-600 text-base flex items-center font-normal leading-12 w-2/4">
                {selectedData.status !== null && (
                  <Switch
                    size="md"
                    checked={selectedData.status}
                    onChange={onStatusChange}
                  />
                )}
              </span>
            </div>
          </div>
        ) : (
          <span className="flex justify-center text-center py-4 text-gray-600 text-xl">
            No Data Found
          </span>
        )}
      </Dialog>
    </div>
  );
};

export default ViewUser;
