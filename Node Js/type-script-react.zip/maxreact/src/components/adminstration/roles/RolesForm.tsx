import Input from "components/common/formInput/Input";
import CheckBox from "components/common/checkBox/NewCheckBox";
import HeadContent from "components/common/HeadContent";
import { ChangeEvent, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import Button from "components/common/button/Button";
import { createRoleWithPermission, getPermissionList, getSelectedPermissions, updatePermission } from "services/permission";
import { useDispatch } from "react-redux";
import { toastShow } from "redux/ducks/toast";
import { useNavigate, useParams } from "react-router-dom";
import { PermissionSelected } from "types/administration/role";

interface propsType {
  selectedBuilder?: string | undefined;
}

const RolesForm = (props: propsType) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { id } = useParams()
  const [convertedData, setConvertedData] = useState<any>([])
  const [idMapping, setIdMapping] = useState<{ name: string; _id: string }[]>([]);
  const [rollError, setRollError] = useState('')
  const [selectedPermission, setSelectedPermission] = useState<string[]>([])
  const [roleId, setRoleId] = useState('');
  const [isLoading, setIsLoading] = useState(false)
  // const [selectedAccountType,setSelectedAccountType]=useState('')
  const {
    register,
    setValue,
    getValues,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const fetchPermission = async () => {
    let selectedPer: PermissionSelected[]
    if (id) {
      const param = {
        roleId: id
      }
      const data = await getSelectedPermissions(param)
      selectedPer = data.data.data.permissions
      setRoleId(id)
      setValue('roleName', data.data.data.role)
      // setSelectedAccountType(data.data.data.accountType)
      const selectedId = selectedPer.map((idArray: { permissionId: string }) => (idArray.permissionId));
      setSelectedPermission(selectedId)
    }
    const listOfPermission = await getPermissionList()
    const data = listOfPermission.data.data;
    const idMappingData = data.map((idArray: { _id: string, name: string }) => ({
      name: idArray.name,
      _id: idArray._id,
    }));

    setIdMapping(idMappingData);

    const transformedData = data.reduce((result: any, item: { name: string, _id: string }) => {
      const [moduleName, permission] = item.name.split('_');

      if (!result[moduleName]) {
        result[moduleName] = {};
      }

      const matchingPermission = selectedPer ? selectedPer.find((selected: { permissionId: string }) => selected.permissionId === item._id) : false;
      result[moduleName][permission] = matchingPermission ? true : false;
      result[moduleName].checked = result[moduleName].checked || result[moduleName][permission];

      return result;
    }, {});

    const resultArray = Object.keys(transformedData).map(moduleName => ({
      [moduleName]: transformedData[moduleName],
    }));
    setConvertedData(resultArray);
  }

  useEffect(() => {
    fetchPermission()
  }, [id])

  const onSubmit = async (values: any) => {
    setIsLoading(true);
    try {
      const roleName = getValues("roleName");
      if (roleName === undefined || roleName === null) {
        setRollError("Roll Name is Required")
        return
      }

      const dataArray: string[] = Object.entries(values).flatMap(([moduleName, modulePermissions]: [string, any]) => {
        return Object.entries(modulePermissions)
          .filter(([permission, isChecked]: [string, any]) => isChecked && permission !== 'checked')
          .map(([permission]: [string, any]) => `${moduleName}_${permission}`);
      });

      const idsArray = dataArray.map((key: string) => {
        const idObj = idMapping.find((idMap) => idMap.name === key);
        return idObj ? idObj._id : null;
      }).filter(Boolean);

      let response
      if (id) {
        const param = {
          role: roleName,
          permissions: [...idsArray],
          roleId: roleId,
          permissionsEdit: !(idsArray.every((value, index) => value === selectedPermission[index])) || idsArray.length !== selectedPermission.length,
          // accountType:values.type
        }
        response = await updatePermission(param)
      } else {
        const param = {
          role: roleName,
          permissions: [...idsArray],
          // accountType:values.type
        }
        response = await createRoleWithPermission(param)
      }
      setIsLoading(false);
      dispatch(toastShow({ message: response.data.message, type: response.data.responseType }));
      if (response.status === 200) {
        navigate(`/administration/roles`)
      }
    } catch (error) {
      console.log('error: ', error);
    }

  };

  const handleCheckAll = (value: string[], checked: boolean) => {
    const permissions = ['create', 'edit', 'delete', 'list', 'checked'];

    permissions.forEach((permission) => {
      setValue(`${value}.${permission}`, checked);
    });
  };


  const handlePermissionChange = (permission: string, moduleKey: string, isChecked: boolean) => {
    setValue(`${moduleKey}.${permission}`, isChecked);

    if (isChecked) {
      setValue(`${moduleKey}.checked`, true);
    } else {
      const otherPermissions = ['create', 'edit', 'delete', 'list'].filter(p => p !== permission);
      const anyPermissionChecked = otherPermissions.some(p => getValues(`${moduleKey}.${p}`));
      setValue(`${moduleKey}.checked`, anyPermissionChecked);
    }
  };

  return (
    <div>
      <HeadContent
        title={false ? "Update Roles" : "Create New Role"}
        searchEnabled={false}
        addButtonEnable={false}
        // filterByEnabled
        // filterByOptions={ACCOUNT_TYPE}
        // onFilterBy={(e)=> {
        //   setValue('type',e.value)
        // }}
        // filterByPlaceholder="Select Account Type"
        // selectedFilter={selectedAccountType}
      />

      <div className="">
        <div className="w-1/4 my-5">
          <Input
            label="Role Name"
            register={register("roleName")}
            onChange={(e: ChangeEvent<HTMLInputElement>) => {
              setValue('roleName', e.target.value)
              setRollError('')
            }}
            error={rollError && rollError}
          />
        </div>

        <div
          className={`overflow-auto relative rounded-xl border border-solid border-loginBorder bg-white`}
        >
          <div className={`w-full m-0 p-0 rounded-xl `}>
            <div className="rounded-t-xl bg-tableheaderbg sticky top-0 z-10 overflow-hidden outline outline-1 outline-loginBorder">
              <div className=" flex items-center justify-between w-full">
                <div className="text-start text-15 font-medium leading-normal capitalize py-4 first:pl-7 pr-7 whitespace-nowrap">
                  <span className="flex items-center gap-2">Module</span>
                </div>
                <div className="text-start text-15 capitalize py-4 first:pl-7 pr-7 whitespace-nowrap text-base font-medium leading-12 w-2/4">
                  <span className="flex items-center gap-2">Permissions</span>
                </div>
              </div>
            </div>
            <form onSubmit={handleSubmit(onSubmit)}>
              {convertedData &&
                convertedData.length > 0 &&
                convertedData.map((role: any, i: number) => {
                  return (
                    <div
                      className="flex items-center justify-between w-full"
                      key={i}
                    >
                      <div className="text-start text-18 apitalize py-4 first:pl-7 pr-7 whitespace-nowrap text-gray-500 text-base font-normal leading-12">
                        <span className="flex items-center gap-2">
                          <CheckBox
                            checkboxKey={Object.keys(convertedData[i]).toString()}
                            size="sm"
                            label={Object.keys(convertedData[i]).toString()}
                            labelClassName="capitalize"
                            border="sm"
                            onChange={(e) =>
                              handleCheckAll(
                                Object.keys(convertedData[i]),
                                e.target.checked
                              )
                            }
                            register={register(`${Object.keys(convertedData[i])}.checked`)}
                            checked={convertedData[i][Object.keys(convertedData[i])[0]]?.checked}
                            name={"Check All"}
                          />
                        </span>
                      </div>
                      <div className="flex gap-3 text-start text-18 capitalize py-4 first:pl-7 pr-7 whitespace-nowrap text-gray-500 text-base font-normal leading-12 w-2/4">
                        <span className="flex items-center gap-2">
                          <div>
                            <CheckBox
                              checkboxKey={"create"}
                              size="sm"
                              label={"Create"}
                              labelClassName={` font-normal font-sans text-sm text-dark w-12 xs:w-full sm:w-36 lg:w-12 capitalize `}
                              border="sm"
                              register={register(`${Object.keys(convertedData[i])}.create`)}
                              checked={convertedData[i][Object.keys(convertedData[i])[0]]?.create || false}
                              onChange={(e: ChangeEvent<HTMLInputElement>) => handlePermissionChange('create', Object.keys(convertedData[i])[0], e.target.checked)}
                            />

                          </div>
                        </span>
                        <span className="flex items-center gap-2">
                          <div>
                            <CheckBox
                              checkboxKey={"edit"}
                              size="sm"
                              label={"Edit"}
                              labelClassName={` font-normal font-sans text-sm text-dark w-12 xs:w-full sm:w-36 lg:w-12 capitalize `}
                              border="sm"
                              register={register(`${Object.keys(convertedData[i])}.edit`)}
                              checked={convertedData[i][Object.keys(convertedData[i])[0]]['edit']}
                              onChange={(e: ChangeEvent<HTMLInputElement>) => handlePermissionChange('edit', Object.keys(convertedData[i])[0], e.target.checked)}
                            />
                          </div>
                        </span>
                        <span className="flex items-center gap-2">
                          <div>
                            <CheckBox
                              checkboxKey={"delete"}
                              size="sm"
                              label={"Delete"}
                              labelClassName={` font-normal font-sans text-sm text-dark w-12 xs:w-full sm:w-36 lg:w-12 capitalize `}
                              border="sm"
                              register={register(
                                `${Object.keys(convertedData[i])}.delete`
                              )}
                              checked={convertedData[i][Object.keys(convertedData[i])[0]]['delete']}
                              onChange={(e: ChangeEvent<HTMLInputElement>) => handlePermissionChange('delete', Object.keys(convertedData[i])[0], e.target.checked)}
                            />
                          </div>
                        </span>
                        <span className="flex items-center gap-2">
                          <div>
                            <CheckBox
                              checkboxKey={"list"}
                              size="sm"
                              label={"List"}
                              labelClassName={` font-normal font-sans text-sm text-dark w-12 xs:w-full sm:w-36 lg:w-12 capitalize `}
                              border="sm"
                              register={register(`${Object.keys(convertedData[i])}.list`)}
                              checked={convertedData[i][Object.keys(convertedData[i])[0]]['list']}
                              onChange={(e: ChangeEvent<HTMLInputElement>) => handlePermissionChange('list', Object.keys(convertedData[i])[0], e.target.checked)}
                            />
                          </div>
                        </span>
                      </div>
                    </div>

                  )
                })}
              <div className="flex items-center justify-end gap-2.5">
                <Button
                  type="button"
                  title={"Close"}
                  onClick={() => { navigate(`/administration/roles`) }}
                  className={"!bg-BrandBlack/10 border !text-black !w-auto px-6"}
                />

                <Button
                  type="submit"
                  variant="filled"
                  className={"!w-auto px-6"}
                  title={`${id ? "Update" : "Create"}`}
                  isLoading={isLoading}
                />
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RolesForm;
