import React, { useMemo } from "react";
import { PiPencilSimpleDuotone, PiTrashDuotone } from "react-icons/pi";
import { Role } from "types/administration/role";
import { useNavigate } from "react-router-dom";

interface IRolesColumn {
  setIsEditOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setIsDeleteOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setIsViewOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setSelectedRoleId: React.Dispatch<React.SetStateAction<string | null>>;
  setModalTitle: React.Dispatch<React.SetStateAction<string>>;
  totalCount: number;
  page: number;
}

const RolesColumn = (props: IRolesColumn) => {
  const navigate = useNavigate();
  const {
    setIsDeleteOpen,
    setIsEditOpen,
    setIsViewOpen,
    setModalTitle,
    setSelectedRoleId,
    totalCount,
    page,
  } = props;

  const calculateSerialNumber = (rowIndex: number) => {
    return (page - 1) * 10 + rowIndex + 1;
  };

  const tempColumn = [
    {
      header: "Sr No",
      cell: ({ row }: { row: { original: Role; index: number } }) => {
        return <div>{calculateSerialNumber(row.index)}</div>;
      },
    },
    {
      header: "Role",
      accessorKey: "role",
      enableSorting: true,
      cell: ({ row }: { row: { original: Role } }) => {
        return <React.Fragment><div className="h-10">{row.original.name}</div>  </React.Fragment>;
      },
    },
    {
      header: "Action",
      cell: ({ row }: { row: { original: Role } }) => {
        return (
          <div className="flex gap-4">

            <div className="group relative">
              <PiPencilSimpleDuotone
                className="text-gray-600 w-6 h-6 cursor-pointer transition duration-300 ease-in-out transform"
                onClick={() => {
                  setModalTitle("Edit Role & Permission");
                  setIsEditOpen(true);
                  setSelectedRoleId(row.original._id);
                  navigate(`/administration/roles/edit/${row.original._id}`)
                }}
              />
              <div className="absolute left-1/2 z-10 transform -translate-x-1/2 bottom-full invisible group-hover:visible group-hover:opacity-100 bg-gray-800 text-white text-xs px-2 py-1 rounded transition-opacity">
                Edit
              </div>
            </div>

            <div className="group relative">
              <PiTrashDuotone
                className="text-red-500 w-6 h-6 cursor-pointer transition duration-300 ease-in-out transform"
                onClick={() => {
                  setIsDeleteOpen(true);
                  setSelectedRoleId("12");
                }}
              />
              <div className="absolute left-1/2 z-10 transform -translate-x-1/2 bottom-full invisible group-hover:visible group-hover:opacity-100 bg-gray-800 text-white text-xs px-2 py-1 rounded transition-opacity">
                Delete
              </div>
            </div>
          </div>
        );
      },
    },
  ];

  const columns = useMemo(() => tempColumn, [page, totalCount]);
  return { columns };
};

export default RolesColumn;
