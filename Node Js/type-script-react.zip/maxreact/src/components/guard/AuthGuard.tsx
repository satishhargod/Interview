import React, { useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { tokensSelector } from "redux/ducks/token";
import { Navigate } from "react-router-dom";
import { UserRole, userRolesCategories } from "utils/navigation.utils";
import { profileSelector } from "redux/ducks/profile";

const AuthGuard = ({
  props,
  children,
  modulename,
  userTabs,
}: {
  path?: string;
  props: any;
  children: JSX.Element;
  modulename: string[];
  userTabs: string[] | undefined;
}) => {
  const tokens = useSelector(tokensSelector);

  const byPass =
    process.env.REACT_APP_PERMISSION_BYPASS === "false" ? false : true;

  if (tokens.accessToken) {
    if (userTabs?.includes(modulename[0]) && byPass) {
      // if (byPass) {
      return children;
    } else {
      return <Navigate to={"/404"} replace={true} />;
    }
  } else {
    return <Navigate to={"/auth/login"} replace={true} />;
  }
};

export default AuthGuard;
