import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import Button from '../common/button/Button';
import { changePassword } from 'services/profile';
import PasswordInput from '../common/formInput/PasswordInput';
import { yupResolver } from '@hookform/resolvers/yup';
import { PasswordChange } from 'types/dashboard/dashboard';
import { changePasswordConstraint } from 'validation/auth/authValidation';
import { toastShow } from 'redux/ducks/toast';
import { useDispatch } from 'react-redux';

const ChangePassword = () => {
  const dispatch = useDispatch();
  const [loginProcess, setLoginProcess] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<PasswordChange>({
    defaultValues: {
      cPassword: '',
      nPassword: '',
      rPassword: '',
    },
    resolver: yupResolver(changePasswordConstraint),
  });

  const onPasswordSubmit = async (values: PasswordChange) => {
    setLoginProcess(true);
    const paramData = {
      oldpassword: values.cPassword,
      newpassword: values.nPassword
    }
    try {
      const loginResponse = await changePassword(paramData);
      dispatch(
        toastShow({ message: loginResponse.data.message, type: loginResponse.data.responseType })
      );
      // if (loginResponse.status === 200) {
      // }
      // else {
      //   dispatch(
      //     toastShow({ message: loginResponse.data.message, type: loginResponse.data.responseType })
      //   );
      // }
      setLoginProcess(false);

    } catch (err) {
      console.log(err);
      setLoginProcess(false);
    }

  }
  return (
    <div>
      <div className="relative mb-5">
        <p className="text-BrandBlack text-xl font-medium leading-normal mb-1.5">
          Change password
        </p>
        <p className="text-BrandBlack text-sm font-normal leading-normal">
          Details about your account’s password
        </p>
      </div>
      <form onSubmit={handleSubmit(onPasswordSubmit)}>
        <div className="flex flex-col gap-6">
          <PasswordInput
            label="Current Password"
            placeholder="Enter password"
            register={register("cPassword", {
              required: "Password is required",
            })}
            className={`!px-15 !py-2.5 ${errors.cPassword ? "border-Darkred" : ""
              }`}
            error={errors.cPassword?.message}
          />
          <PasswordInput
            label="New Password"
            placeholder="Enter password"
            register={register("nPassword", {
              required: "Password is required",
            })}
            className={`!px-15 !py-2.5 ${errors.nPassword ? "border-Darkred" : ""
              }`}
            error={errors.nPassword?.message}
          />
          <PasswordInput
            label="Re-type New Password"
            placeholder="Enter password"
            register={register("rPassword", {
              required: "Password is required",
            })}
            className={`!px-15 !py-2.5 ${errors.rPassword ? "border-Darkred" : ""
              }`}
            error={errors.rPassword?.message}
          />
        </div>
        <Button
          title="Update"
          variant="filled"
          type="submit"
          className={"mt-30 !w-auto !py-2.5 !px-10 ml-auto block"}
          isLoading={loginProcess}
        />
      </form>
    </div>
  );
}

export default ChangePassword;