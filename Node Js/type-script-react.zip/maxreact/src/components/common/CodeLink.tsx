import React, { ComponentProps, ReactNode } from "react";
import { Link } from "react-router-dom";

const CodeLink = ({
  children,
  to,
  className,
  onClick,
  refrance,
  ...others
}: Omit<ComponentProps<typeof Link>,""> & {
  children?: ReactNode;
  to: string|{
                pathname: string,
                query: {}
              }
  className?: string;
  onClick?: React.MouseEventHandler<HTMLAnchorElement>;
  refrance?: React.Ref<HTMLAnchorElement>;
  others?: any;
}) => {
  return (
    <Link
      to={to}
      className={className}
      onClick={onClick}
      {...others}
      ref={refrance ? refrance : null}
    >
      {children}
    </Link>
  );
};

export default CodeLink;
