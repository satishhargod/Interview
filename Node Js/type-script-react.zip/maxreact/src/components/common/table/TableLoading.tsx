import React from "react";
import Skeleton from "../Skeleton";
import { ColumnDef } from "@tanstack/react-table";

interface ITableLoading {
  columns:ColumnDef<any>[]
}

const TableLoading = (props: ITableLoading) => {
  const { columns } = props;

  return (
    <tbody>
      {/* use this in table tag */}
      {Array.from({ length: 10 }).map((_: unknown, index: number) => (
        <tr
          className="last:border-b-0 border-b border-gray-400"
          key={`table-row-${index}`}
        >
          {columns.map((_: unknown, index: number) => (
            <td
              className="relative text-sm p-3.5 whitespace-nowrap text-BrandBlack"
              key={`table-cell-${index}`}
            >
              <Skeleton className="h-7 w-full" />
            </td>
          ))}
        </tr>
      ))}
    </tbody>
  );
};

export default TableLoading;
