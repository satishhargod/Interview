import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  useReactTable,
  getCoreRowModel,
  flexRender,
  SortingState,
  ColumnDef,
} from "@tanstack/react-table";
import Pagination from "./Pagination";
import TableLoading from "./TableLoading";
import { TbArrowUp } from "react-icons/tb";
import { TbArrowDown } from "react-icons/tb";
import { TbArrowsSort } from "react-icons/tb";

interface ICustomTableProps {
  data: object[];
  columns: ColumnDef<any>[];
  fetchData: any;
  searchKeyword: string;
  filter?: boolean | null;
  totalCount?: number;
  page: number;
  pageSize: number;
  setPage: (page: number) => void;
  isLoading: boolean;
  setIsLoading: (data: boolean) => void;
  tbodyTdClassName?: string;
}

const CustomTable = (props: ICustomTableProps) => {
  const {
    data,
    columns,
    fetchData,
    searchKeyword = "",
    totalCount = 0,
    page,
    filter = null,
    setPage,
    pageSize,
    isLoading,
    setIsLoading,
    tbodyTdClassName,
  } = props;

  //================================================================//
  //========================  Use Refs =============================//
  const tableRef = useRef(null);

  //================================================================//
  //======================= Use States =============================//

  // const [isLoading, setIsLoading] = useState(false);
  const [prevSearchKeyword, SetPrevSearchKeyword] = useState("");
  const [sorting, setSorting] = useState<SortingState>([]);

  // const [page, setPage] = useState(1);
  // const [pageSize, setPageSize] = useState(10);
  const [tableHeight, setTableHeignt] = useState(0);

  //================================================================//

  const table = useReactTable({
    data,
    columns,
    state: { sorting },
    // onSortingChange: setSorting,
    enableColumnResizing: true,
    columnResizeMode: "onChange",
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    debugTable: true,
    debugHeaders: true,
    debugColumns: true,
    onSortingChange: setSorting,

    // onColumnFiltersChange: setColumnFilters,
  });
  //================================================================//
  //======================= Use Effect =============================//

  useEffect(() => {
    const timeout = setTimeout(() => {
      if (prevSearchKeyword.trim() !== searchKeyword.trim()) {
        fetchTableData();
        SetPrevSearchKeyword(searchKeyword);
        setPage(1);
      }
    }, 1000);

    return () => {
      if (!timeout) return;
      clearTimeout(timeout);
    };
  }, [searchKeyword]);

  useEffect(() => {
    fetchTableData();
  }, [page, pageSize, sorting]);

  useEffect(() => {
    // Check if the element ref is not null
    if (tableRef.current) {
      // Get the bounding client rect of the element
      //@ts-ignore
      const rect = tableRef.current.getBoundingClientRect();

      // Calculate the distance from the top of the document
      const distanceFromTop = rect.top + window.scrollY;
      const data = window.innerHeight;
      setTableHeignt(data - distanceFromTop - 30);
    }
  }, [tableRef]);

  //================================================================//
  //======================= Api Calls ==============================//

  const fetchTableData = async () => {
    try {
      setIsLoading(true);
      const queryParams = {
        page: page,
        limit: pageSize,
        ...(searchKeyword && { search: searchKeyword }),
        ...(sorting.length !== 0 && {
          sortBy: sorting[0].id === 'role' ? 'name' : sorting[0].id,
          order: sorting[0].desc ? "desc" : "asc",
        }),
      };

      await fetchData(queryParams).finally(() => {
        setIsLoading(false);
      });
    } catch (error) {
      setIsLoading(false);
    }
  };

  const handlePageChange = useCallback(
    (newPage: number) => {
      setPage(newPage);
    },
    [setPage]
  );
  //================================================================//

  return (
    <>
      <div
        className={`overflow-auto relative rounded-xl border border-solid border-loginBorder bg-white ${
          totalCount > pageSize ? "rounded-b-none border-b-0" : ""
        }`}
        // style={{ height: `${tableHeight}px` }}
        style={
          totalCount > pageSize
            ? { height: `${tableHeight - 75}px` }
            : { height: `${tableHeight}px` }
        }
      >
        <table
          className={`w-full m-0 p-0 rounded-xl ${
            totalCount === 0 ? "h-full" : ""
          }`}
          ref={tableRef}
        >
          {/* table Header - Header */}
          <thead className="rounded-t-xl bg-tableheaderbg sticky top-0 z-10 overflow-hidden outline outline-1 outline-loginBorder">
            {table.getHeaderGroups().map(({ id, headers }) => (
              <tr key={id} className=" rounded-t-xl">
                {headers.map((header) => (
                  <th
                    key={header.id}
                    colSpan={header.colSpan}
                    style={{
                      width: header.getSize(),
                    }}
                    className="text-start text-15 font-medium leading-normal capitalize py-4 first:pl-7 pr-7 whitespace-nowrap"
                  >
                    {header.isPlaceholder ? null : (
                      <span
                        className="flex items-center gap-2"
                        {...{
                          onClick: header.column.getToggleSortingHandler(),
                        }}
                      >
                        {flexRender(
                          header.column.columnDef.header,
                          header.getContext()
                        )}
                        {flexRender(
                          header.column.getCanSort()
                            ? {
                                asc: (
                                  <TbArrowUp className="text-lg text-primary" />
                                ),
                                desc: (
                                  <TbArrowDown className="text-lg text-primary" />
                                ),
                              }[header.column.getIsSorted() as string] ?? (
                                <TbArrowsSort className="text-lg text-secondary" />
                              )
                            : null,
                          header.getContext()
                        )}
                      </span>
                    )}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          {/* table Body - Data */}

          {isLoading ? (
            <TableLoading columns={columns} />
          ) : totalCount === 0 ? (
            <tbody className="no-data-found h-full">
              <tr className="h-full">
                <td
                  colSpan={columns.length}
                  className="text-center py-4 text-gray-600 text-5xl"
                >
                  No Data Found
                </td>
              </tr>
            </tbody>
          ) : (
            <tbody className="">
              {table.getRowModel().rows.map((row) => (
                <tr
                  key={row.id}
                  className="border-b border-solid border-tdborder last:border-b-0"
                >
                  {row.getVisibleCells().map((cell) => (
                    <td
                      key={cell.id}
                      className={`first:pl-7 py-2 pr-7 text-gray-600 text-15 font-normal leading-normal whitespace-nowrap ${tbodyTdClassName}`}
                    >
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          )}
          {/* table Footer - Pagination */}
          {/* <tfoot className="sticky bottom-0 border-b-0 bg-white rounded-b-xl">
          <tr className="">
            <td colSpan={table.getHeaderGroups()[0].headers.length}>
              
            </td>
          </tr>
        </tfoot> */}
        </table>
      </div>
      <Pagination
        currentPage={page}
        totalCount={totalCount}
        pageSize={pageSize}
        onPageChange={handlePageChange}
      />
    </>
  );
};

export default CustomTable;
