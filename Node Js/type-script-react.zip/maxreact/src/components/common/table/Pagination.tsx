import React from "react";
import { usePagination, DOTS } from "./usePagination";
import { FaChevronLeft, FaChevronRight } from "react-icons/fa";

interface IPagination {
  onPageChange: (page: number) => void;
  totalCount: number;
  currentPage: number;
  pageSize: number;
  className?: string;
  siblingCount?: number;
}

const Pagination = (props: IPagination) => {
  const {
    onPageChange,
    totalCount,
    siblingCount = 1,
    currentPage,
    pageSize,
    className,
  } = props;

  const paginationRange = usePagination({
    currentPage,
    totalCount,
    siblingCount,
    pageSize,
  });
  let lastPage: number = paginationRange
    ? (paginationRange[paginationRange.length - 1] as number)
    : 1;

  if (currentPage === 0 || (paginationRange && paginationRange.length < 2)) {
    return null;
  }

  const onNext = () => {
    if (lastPage) {
      currentPage < lastPage && onPageChange(currentPage + 1);
    } else {
      onPageChange(currentPage + 1);
    }
  };

  const onPrevious = () => {
    if (currentPage !== 1) {
      onPageChange(currentPage - 1);
    }
  };

  return (
    <div
      className={`flex items-center justify-between border border-tdborder bg-white rounded-b-xl px-30 py-4 ${className}`}
    >
      <div>
        <p className="text-15 text-gray-600 font-normal leading-normal">
          Showing <span className="font-medium">{Math.min(pageSize * currentPage, totalCount)}</span>{" "}
          of
          <span className="font-medium"> {totalCount} </span> Entries
        </p>
      </div>
      <div>
        <ul
          className="isolate inline-flex -space-x-px rounded-md shadow-sm"
          aria-label="Pagination"
        >
          <li
            onClick={onPrevious}
            className="relative flex items-center px-13px py-7px cursor-pointer rounded-r border border-solid border-gray-300 text-BrandBlack border-r-0"
          >
            <span className="sr-only">Previous</span>
            <FaChevronLeft className="h-5 w-5" aria-hidden="true" />
          </li>
          <li
            className={`pagination-item cursor-pointer  ${
              currentPage === 1 ? "disabled" : ""
            }`}
          >
            <div className="arrow left" />
          </li>
          {paginationRange &&
            paginationRange.map(
              (
                pageNumber:
                  | string
                  | number
                  | boolean
                  | React.ReactElement<
                      any,
                      string | React.JSXElementConstructor<any>
                    >
                  | Iterable<React.ReactNode>
                  | React.ReactPortal
                  | null
                  | undefined,
                index: React.Key | null | undefined
              ) => {
                if (pageNumber === DOTS) {
                  return (
                    <p
                      key={index}
                      className="relative flex items-center px-13px py-7px cursor-pointer rounded-r border border-solid border-gray-300 text-BrandBlack border-r-0"
                    >
                      <span className="block -mt-1.5">...</span>
                    </p>
                  );
                }

                return (
                  <li
                    key={index}
                    className={`pagination-item cursor-pointer ${
                      pageNumber === currentPage
                        ? "relative flex items-center px-13px py-7px cursor-pointer rounded-r border border-solid border-gray-300 border-r-0 bg-BrandBlack text-white"
                        : "relative flex items-center px-13px py-7px cursor-pointer rounded-r border border-solid border-gray-300 text-BrandBlack border-r-0"
                    }`}
                    onClick={() => onPageChange(pageNumber as number)}
                  >
                    {pageNumber}
                  </li>
                );
              }
            )}
          <li
            onClick={onNext}
            className="relative flex items-center px-13px py-7px cursor-pointer rounded-r border border-solid border-gray-300 text-BrandBlack"
          >
            <span className="sr-only">Previous</span>
            <FaChevronRight className="h-5 w-5" aria-hidden="true" />
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Pagination;
