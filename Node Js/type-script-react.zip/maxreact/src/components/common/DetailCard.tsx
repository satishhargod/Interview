import {
  PiEnvelopeSimpleDuotone,
  PiPhoneDuotone,
  PiMapPinDuotone,
  PiCalendarCheckDuotone,
  PiCalendarBlankDuotone,
  PiEyeDuotone,
  PiPencilDuotone,
  PiTrashDuotone,
} from "react-icons/pi";
import { DEFAULT_IMAGE } from "helper/common/constant";
import Button from "./button/Button";
import Image from "./Image";

interface IDetailCard {
  data: any;
  modal?: string;
  onView: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

const DetailCard = (props: IDetailCard) => {
  const { data, onEdit, onDelete, onView, modal } = props;
  return (
    <div>
      <div className="max-w-full bg-white shadow-dropdownshadow rounded-10 overflow-hidden p-4">
        <div className="relative">
          <Image
            imageClassName="w-full h-40 object-cover object-center border-none rounded-lg"
            src={data.profileImageUrl}
            defaultImage={DEFAULT_IMAGE.defaultCardImage}
            alt="Card"
          />
        </div>
        <div className="relative flex flex-col gap-1">
          <div className="flex justify-between items-center py-3 border-b border-solid border-loginBorder ">
            <h3 className="text-lg font-medium text-black leading-150%">
              {data.name || "CPB Contractors"}
            </h3>
            {!modal ? (
              <div className="flex justify-center gap-2">
                <PiEyeDuotone
                  className="border border-solid border-loginBorder rounded-lg p-2  h-9 w-9 cursor-pointer"
                  onClick={onView}
                />
                <PiPencilDuotone
                  className="border border-solid border-loginBorder rounded-lg p-2  h-9 w-9 cursor-pointer"
                  onClick={onEdit}
                />
                <PiTrashDuotone
                  className="border border-solid text-Darkred border-loginBorder rounded-lg p-2  h-9 w-9 cursor-pointer"
                  onClick={onDelete}
                />
              </div>
            ) : (
              <div className="flex justify-center gap-2">
                <Button
                  className="border border-solid border-loginBorder rounded-lg p-3.5 h-14 w-9 cursor-pointer"
                  onClick={onView}
                  title={"View Jobs"}
                />
              </div>
            )}
          </div>
          <div className="flex items-center gap-2.5 py-1">
            <PiEnvelopeSimpleDuotone className="!h-5 !w-5" />
            <h1 className="text-BrandBlack text-sm font-normal leading-150%">
              {data.email || "CPBContractors@outlook.com"}
            </h1>
          </div>
          <div
            className={`flex items-center gap-2.5 ${
              modal &&
              modal === "job" &&
              "py-2 border-b border-solid border-loginBorder"
            }`}
          >
            <PiPhoneDuotone className="!h-5 !w-5" />
            <h1 className="text-BrandBlack text-sm font-normal leading-150%">
              {data.phone || "+0 123 456 789"}
            </h1>
          </div>
          {!modal && (
            <div className="flex items-center gap-2.5 py-1">
              <PiMapPinDuotone className="!h-5 !w-5" />
              <h1 className="text-BrandBlack text-sm font-normal leading-150%">
                {data.address ||
                  "177 Pacific Highway North Sydney, NSW 2060, AU"}
              </h1>
            </div>
          )}
          {modal && modal === "job" && (
            <>
              <div className="flex items-center gap-2.5 py-1 justify-between">
                <span>Total Jobs : </span>
                <h1 className="text-BrandBlack text-sm font-normal leading-150%">
                  {data.total_jobs || 20}
                </h1>
              </div>
              <div className="flex items-center gap-2.5 py-1 justify-between">
                <span>Total Ongoing Jobs : </span>
                <h1 className="text-BrandBlack text-sm font-normal leading-150%">
                  {data.total_ongoing_jobs || 20}
                </h1>
              </div>
              <div className="flex items-center gap-2.5 py-1 justify-between">
                <span>Total Completed Jobs : </span>
                <h1 className="text-BrandBlack text-sm font-normal leading-150%">
                  {data.total_completed_jobs || 20}
                </h1>
              </div>
            </>
          )}
          {data.startDate && (
            <div className="flex items-center gap-2.5 py-1">
              <PiCalendarCheckDuotone className="!h-5 !w-5" />
              <h1 className="text-BrandBlack text-sm font-normal leading-150%">
                Start Date: 01/01/2024
              </h1>
            </div>
          )}
          {data.endDate && (
            <div className="flex items-center gap-2.5 py-1">
              <PiCalendarBlankDuotone className="!h-5 !w-5" />
              <h1 className="text-BrandBlack text-sm font-normal leading-150%">
                End Date: 10/02/2024
              </h1>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DetailCard;
