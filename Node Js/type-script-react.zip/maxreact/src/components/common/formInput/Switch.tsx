import React from "react";
import cx from "classnames";
import { UseFormRegisterReturn } from "react-hook-form";

const Switch = ({
  label = "",
  parentClassName,
  labelClassName,
  size = "md",
  border = "md",
  register,
  error,
  labelFirst = false,
  isSwitch = false,
  disabled = false,
  onChange,
  onClick,
  watch_register = false,
  checkWrapClassName,
  custom_switch = false,
  checked,
}: {
  label?: string;
  parentClassName?: string;
  labelClassName?: string;
  size?: "sm" | "md" | "lg";
  border?: "sm" | "md";
  register?: UseFormRegisterReturn;
  error?: string;
  labelFirst?: boolean;
  isSwitch?: boolean;
  disabled?: boolean;
  onChange?: (...event: any[]) => void;
  onClick?: (...e: any[]) => void;
  watch_register?: boolean;
  checkWrapClassName?: string;
  custom_switch?: boolean;
  checked?: boolean;
}) => {
  const checkWrapClass = cx(
    `relative flex items-center w-10 h-6 border-2 border-loginBorder bg-BrandBlack/10 rounded-full peer-checked:bg-activetoggle peer-checked:border-activetoggle transition-all duration-300 ${checkWrapClassName}  `
  );
  const checkClass = cx(
    `absolute left-1 right-auto w-4 h-4 bg-white rounded-full peer-checked:bg-white peer-checked:left-auto peer-checked:right-1 z-[1] transition-all duration-300`
  );

  return (
    <div className={`relative inline-block gap-2 ${parentClassName}`}>
      <label
        className={`flex items-center gap-3 ${
          disabled
            ? "cursor-not-allowed opacity-60 select-none"
            : "cursor-pointer"
        } `}
      >
        {labelFirst && label ? (
          <p className={`${labelClassName} font-bold`}>{label}</p>
        ) : (
          ""
        )}
        <span
          className={`relative flex items-center ${
            disabled && "pointer-events-none select-none"
          } `}
        >
          {custom_switch ? (
            <input
              type="checkbox"
              className={`peer rounded appearance-none  absolute inset-0 opacity-0 ${size}`}
              disabled={disabled}
              {...register}
            />
          ) : watch_register ? (
            <input
              type="checkbox"
              className={` peer rounded appearance-none  absolute inset-0 opacity-0 ${size}`}
              name=""
              id=""
              {...register}
              defaultChecked={isSwitch}
              disabled={disabled}
              checked={checked}
            />
          ) : (
            <input
              type="checkbox"
              className={`peer rounded appearance-none  absolute inset-0 opacity-0 ${size}`}
              name=""
              id=""
              {...register}
              onChange={(e) => {
                if (onChange) {
                  onChange(e);
                } else {
                  e.preventDefault();
                }
              }}
              onClick={onClick}
              defaultChecked={isSwitch}
              disabled={disabled}
              checked={checked}

            />
          )}
          <span className={checkWrapClass}></span>
          <span className={checkClass}></span>
        </span>
        {!labelFirst && label ? (
          <p className={`${labelClassName} font-hauora font-bold`}>{label}</p>
        ) : (
          ""
        )}
      </label>
      {error && (
        <div className={`flex w-full`}>
          <p className="text-red-500 text-xs">{error}</p>
        </div>
      )}
    </div>
  );
};

export default Switch;
