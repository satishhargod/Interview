import React, { useEffect } from "react";
import {
  UseFormGetValues,
  UseFormRegisterReturn,
  UseFormSetError,
  UseFormSetValue,
} from "react-hook-form";
import { HiInformationCircle } from "react-icons/hi";
import PhoneInput, { CountryData } from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import { DEFAULT_COUNTRY_CODE } from "helper/common/constant";

const CustomPhoneInput = ({
  className,
  type = "text",
  parentClassName,
  placeholder,
  label,
  error,
  info = false,
  required = false,
  registerPhoneNo,
  registerCountryCode,
  setValueCountry,
  getValueCountry,
  countryCodeClassName,
  containerClassName,
  countryCodeDropDownClassName,
  startIcon,
  iconClasses,
  name,
  labelClassName,
  preferredCountries,
  labelIcon = false,
  disable = false,
  onFocus,
}: {
  className?: string;
  type?: string;
  parentClassName?: string;
  placeholder?: string;
  label?: string;
  error?: string;
  info?: boolean;
  required?: boolean;
  name?: string;
  registerPhoneNo: UseFormRegisterReturn;
  registerCountryCode: UseFormRegisterReturn;
  countryCodeClassName?: string;
  countryCodeDropDownClassName?: string;
  setValueCountry: (value: string) => void;
  startIcon?: React.ReactNode;
  iconClasses?: string;
  containerClassName?: string;
  getValueCountry: string | undefined;
  labelClassName?: string;
  preferredCountries?: string[];
  labelIcon?: React.ReactNode;
  disable?: boolean;
  inputClassname?: string;
  onFocus?: () => void;
}) => {
  const classes = `relative bg-white w-full py-2.5 pr-3 pl-24 border rounded-lg placeholder:text-gray-600 text-base font-normal leading-150% focus:outline-none border-solid border-gray-400 z-0 ${parentClassName} 
  ${
    disable ? "bg-gray-200 cursor-not-allowed" : "border-solid border-gray-400"
  },
  ${error ? "!border-Darkred " : "focus:!border-gray-600"}`;

  const inputClassname = `relative bg-white w-full py-2.5 pr-3 pl-24 border rounded-lg placeholder:text-gray-600 text-base font-normal leading-150% focus:outline-none border-solid border-gray-400 ${
    disable ? "bg-gray-200 cursor-not-allowed" : "border-solid border-gray-400"
  },
  ${error ? "!border-Darkred " : "focus:!border-gray-600"}`;

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = event.target.value.replace(/\D/g, "");
    event.target.value = inputValue;
  };
  return (
    <div className={`relative flex flex-col w-full ${parentClassName} `}>
      {label && (
        <label
          className={`text-contentcolor text-base leading-150% font-normal mb-1.5 block ${labelClassName} `}
        >
          {labelIcon && <span className="mr-2">{labelIcon}</span>}
          {label}
          {required && (
            <span className="text-Darkred text-sm font-normal leading-150% mt-1">
              *
            </span>
          )}
        </label>
      )}
      <div className="flex items-center  " onClick={onFocus}>
        <input type="hidden" {...registerCountryCode} />
        {startIcon && (
          <span className={`left-0 ${iconClasses} `}>{startIcon}</span>
        )}
        <PhoneInput
          placeholder="+00"
          value={getValueCountry || DEFAULT_COUNTRY_CODE}
          onChange={(value, data: CountryData) =>
            setValueCountry(
              value.trim() !== ""
                ? data.dialCode && data.dialCode.startsWith(value[0])
                  ? data.dialCode
                  : value
                : ""
            )
          }
          inputProps={{
            name: "countryCode",
            disabled: true,
          }}
          containerClass={`flag_css ${containerClassName}`}
          inputClass={` !bg-transparent !py-2.5 !pl-0 !ml-12 pr-3 placeholder:!text-gray-600 !text-base !font-normal !leading-150% focus:!outline-none !h-auto !w-12 !border-0 !absolute left-0 top-0 z-[1] -translate-y-2/4 ${countryCodeClassName} `}
          buttonClass={`${countryCodeDropDownClassName}`}
          preferredCountries={preferredCountries}
          dropdownClass="top-5 !z-[2]"
        />
        <input
          type={type}
          placeholder={placeholder}
          className={`${inputClassname}`}
          {...registerPhoneNo}
          onInput={handleInputChange}
        />
      </div>
      {error && (
        <p className="text-Darkred text-sm font-normal leading-150% mt-1">
          {error}
        </p>
      )}
    </div>
  );
};

export default CustomPhoneInput;
