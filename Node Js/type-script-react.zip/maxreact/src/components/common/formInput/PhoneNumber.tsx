import { userProfile } from "types/dashboard/dashboard";
import { UseFormSetValue } from "react-hook-form";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import { DEFAULT_COUNTRY_CODE } from "helper/common/constant";
import classNames from "classnames";

interface popsType {
  value: string;
  setValue: UseFormSetValue<userProfile>;
  parentClassName?: string;
  labelClassName?: string;
  label?: string;
  required?: boolean;
  inputStyle?: object;
  dropDownStyle?: object;
  className?: string;
}

const PhoneNumber = ({
  value = "",
  setValue,
  labelClassName = "",
  parentClassName = "",
  label = "",
  required = false,
  inputStyle = {},
  dropDownStyle = {},
  className = "",
}: popsType) => {
  return (
    <div className={`relative flag_css ${parentClassName} `}>
      {label && (
        <label
          className={`text-contentcolor text-base leading-150% font-normal mb-1.5 block ${labelClassName} `}
        >
          {label}
          {required && <span className="text-red-Darkred font-medium">*</span>}
        </label>
      )}
      <div className="relative">
        <PhoneInput
          country={DEFAULT_COUNTRY_CODE}
          value={value}
          autoFormat
          onChange={(value) => {
            setValue("phone", value);
          }}
          inputStyle={inputStyle}
          dropdownStyle={dropDownStyle}
          inputClass={`relative !bg-white !w-full !py-2.5 !pr-3 !border !border-solid !border-gray-400 !rounded-lg placeholder:!text-gray-600 !text-base !font-normal !leading-150% focus:!outline-none !h-auto focus:!border-gray-600 ${className}`}
        />
      </div>
    </div>
  );
};

export default PhoneNumber;
