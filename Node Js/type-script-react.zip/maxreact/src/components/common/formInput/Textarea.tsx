import React from "react";
import cx from "classnames";
import { HiInformationCircle } from "react-icons/hi";
import { UseFormRegisterReturn } from "react-hook-form";

const Textarea = ({
  register,
  height,
  labelClassName = "",
  parentClassName = "",
  placeholder,
  label = "",
  error = "",
  className = "",
  required = false,
  border = "md",
  info = false,
  disabled = false,
  defaultValue,
  rows,
  cols,
  onChange
}: {
  className?: string;
  height?: string;
  register?: UseFormRegisterReturn;
  labelClassName?: string;
  parentClassName?: string;
  placeholder?: string;
  label?: string;
  error?: string;
  required?: boolean;
  info?: boolean;
  disabled?: boolean;
  border?: "sm" | "md";
  defaultValue?: string;
  rows?: number;
  cols?: number;
  onChange?:React.ChangeEventHandler<HTMLTextAreaElement>
}) => {
  const classes = cx(
    className,
    `relative bg-white text-BrandBlack placeholder:text-gray-600 focus:!outline-none block text-base p-4 w-full rounded-lg border border-loginBorder border-gray-400    
    ${height && "h-32"}      
    ${!error ? "focus:!border-gray-600" : "!border-Darkred"}
    `
  );

  return (
    <div className={`relative flex flex-col ${parentClassName} `}>
      {label && (
        <label
          className={`text-contentcolor text-base leading-150% font-normal mb-1.5 block ${labelClassName} `}
        >
          {label}
          {required && <span className="text-Darkred font-medium">*</span>}
        </label>
      )}
      <textarea
        placeholder={placeholder}
        className={classes}
        {...register} // Register the input with RHF
        disabled={disabled}
        defaultValue={defaultValue}
        cols={cols}
        rows={rows}
        onChange={onChange}
      />
      {error && (
        <p className="text-Darkred text-sm font-normal leading-150% mt-1">
          {error}
        </p>
      )}
    </div>
  );
};

export default Textarea;
