import React, { useState } from "react";
// import DatePicker from "react-datepicker";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { UseFormRegisterReturn } from "react-hook-form";
import { PiWarningCircle } from "react-icons/pi";
import { FaCalendarAlt } from "react-icons/fa";

function CustomInput({ value, onClick }: { value: any, onClick: () => void }) {
    return (
        <div className="input-group">
            <button
                className="w-full border-2 p-2"
                onClick={onClick}
                //  ref={buttonRef}
                style={{ display: "flex", alignItems: "center" }}
            >
                <FaCalendarAlt className="mr-2" />
                {value} {/* Adjust this based on your needs */}
            </button>
        </div>

    );
}

const DateInput = ({
    onChange,
    labelClassName = "",
    parentClassName = "",
    placeholder,
    label = "",
    error = "",
    className = "",
    required = false,
    register,
    getValueCountry,
    disable = false
}: {
    onChange?: any;
    register?: UseFormRegisterReturn;
    className?: string;
    labelClassName?: string;
    getValueCountry: any;
    parentClassName?: string;
    placeholder?: string;
    label?: string;
    error?: string;
    required?: boolean;
    disable?: boolean
}) => {
    return (

        <div className={`relative ${parentClassName} `}>
            {label && (
                <label
                    className={`text-contentcolor text-base leading-150% font-normal mb-1.5 block ${labelClassName} `}
                >
                    {label}
                    {required && <span className="text-red-Darkred font-medium">*</span>}
                </label>
            )}
            <div className="relative">
                <DatePicker
                    customInput={<CustomInput value={new Date(getValueCountry)} onClick={onChange} />}
                    selected={new Date(getValueCountry)}
                    onChange={onChange}
                    className={className}
                // disabled={disable}
                />
                {error && (
                    <button className="absolute right-3 z-[1] text-Darkred top-2/4 -translate-y-2/4">
                        <PiWarningCircle />
                    </button>
                )}
            </div>
            {error && (
                <p className="text-Darkred text-sm font-normal leading-150% mt-1">
                    {error}
                </p>
            )}
        </div>
    );
}

export default DateInput