import React from "react";
import cx from "classnames";
import { UseFormRegisterReturn } from "react-hook-form";
import { PiWarningCircle } from "react-icons/pi";

interface InputProps {
  register?: UseFormRegisterReturn;
  type?: string;
  className?: string;
  labelClassName?: string;
  parentClassName?: string;
  placeholder?: string;
  label?: string;
  error?: string;
  required?: boolean;
  disable?: boolean
  onChange?: any;
}
const Input: React.FC<InputProps> = ({
  type = "text",
  labelClassName = "",
  parentClassName = "",
  placeholder,
  label = "",
  error = "",
  className = "",
  required = false,
  register,
  disable = false,
  onChange,
}) => {
  const classes = cx(
    className,
    "relative bg-white w-full py-1.5 px-3 border rounded-lg placeholder:text-gray-600 text-base font-normal leading-150% focus:outline-none",
    disable ? "bg-gray-200 cursor-not-allowed" : "border-solid border-gray-400",
    !error ? "focus:!border-gray-600" : "!border-Darkred pr-8"
  );

  return (
    <div className={`relative ${parentClassName} `}>
      {label && (
        <label
          className={`text-contentcolor text-base leading-150% font-normal mb-1.5 block ${labelClassName} `}
        >
          {label}
          {required && <span className="text-red-Darkred font-medium">*</span>}
        </label>
      )}
      <div className="relative">
        <input
          type={type}
          placeholder={placeholder}
          className={classes}
          disabled={disable}
          onChange={onChange}
          {...register}
        />
        {error && (
          <button className="absolute right-3 z-[1] text-Darkred top-2/4 -translate-y-2/4">
            <PiWarningCircle />
          </button>
        )}
      </div>
      {error && (
        <p className="text-Darkred text-sm font-normal leading-150% mt-1">
          {error}
        </p>
      )}
    </div>
  );
};

export default Input;
