import { Link } from "react-router-dom";
import React, { useRef } from "react";

const CodeLink = ({
  children,
  href,
  className,
  onClick,
  refrance,
  ...others
}: {
  children?: any;
  href?: any;
  className?: any;
  onClick?: any;
  refrance?: any;
  others?: any;
}) => {
  return (
    <Link
      to={refrance}
      className={className}
      onClick={onClick}
      {...others}
      ref={href}
    >
      {children}
    </Link>
  );
};

export default CodeLink;
