import React, { ReactNode } from "react";
import cx from "classnames";
import { HiCheck } from "react-icons/hi";
import { UseFormRegisterReturn } from "react-hook-form";
import { RxDotFilled } from "react-icons/rx";

const CheckBox = ({
  label,
  isSwitch = false,
  parentClassName,
  labelClassName,
  size = "md",
  border = "md",
  register,
  error,
  labelFirst = false,
  disabled = false,
  onChange,
  checked = false,
  defaultChecked = false,
  checkboxKey,
  with_register = true,
  value = false,
  with_value = false,
  rounded = false,
  unCheckedColor = null,
  name,
  errorClass,
  labelClassNameWithCheckBox,
  checkBoxColor = false,
}: {
  label?: string;
  isSwitch?: boolean;
  parentClassName?: string;
  labelClassName?: string;
  size?: "sm" | "md" | "lg";
  border?: "sm" | "md";
  register?: UseFormRegisterReturn;
  error?: string;
  labelFirst?: boolean;
  disabled?: boolean;
  onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
  checked?: boolean;
  defaultChecked?: boolean;
  checkboxKey?: string;
  with_register?: boolean;
  value?: boolean | string;
  with_value?: boolean;
  rounded?: boolean;
  name?: string;
  errorClass?: string;
  labelClassNameWithCheckBox?: string;
  checkBoxColor?: string | boolean;
  unCheckedColor?: string | null;
}) => {
  const checkWrapClass = cx(
    `relative flex items-center border-2 border-gray-400 bg-white rounded transition-all duration-300 overflow-hidden h-4 w-4`
  );
  const checkClass = cx(
    `absolute flex items-center justify-center inset-0 peer-checked:bg-blacklight rounded scale-0 peer-checked:scale-100 transition-all text-white text-base`
  );
  return (
    <div
      className={`relative flex justify-center -2 ${parentClassName}`}
    >
      <label
        className={`flex items-center gap-2 ${
          isSwitch ? "isSwitch" : ""
        }  ${labelClassNameWithCheckBox}`}
      >
        {labelFirst && label ? (
          <p className={`${labelClassName} font-hauora font-bold`}>{label}</p>
        ) : (
          ""
        )}
        <span
          className={`relative flex items-center ${
            disabled && "opacity-60 pointer-events-none select-none"
          } `}
        >
          {with_register ? (
            <>
              <input
                type="checkbox"
                className={`peer rounded appearance-none absolute inset-0 opacity-0 ${size}`}
                name=""
                id=""
                onClick={
                  onChange as unknown as React.MouseEventHandler<HTMLInputElement>
                }
                {...register}
                // value={with_value ? !!value : label}
                disabled={disabled}
                defaultChecked={!!checked}
                // checked={with_value ? value == ("true" || true) : checked}
                key={checkboxKey}
              />
            </>
          ) : (
            <>
              <input
                type="checkbox"
                className={`peer rounded appearance-none absolute inset-0 opacity-0 ${size}`}
                name=""
                id=""
                onChange={onChange}
                {...register}
                // value={name || label}
                disabled={disabled}
                checked={checked || defaultChecked}
                // defaultChecked={defaultChecked}
                key={checkboxKey}
              />
            </>
          )}

          <span className={checkWrapClass}></span>
          {unCheckedColor && (
            <div className="absolute left-2/4 -translate-x-2/4 text-white">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth="1.5"
                stroke="currentColor"
                className="w-3 h-3"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="m4.5 12.75 6 6 9-13.5"
                />
              </svg>
            </div>
          )}
          <span className={checkClass}>
            {!rounded ? <HiCheck /> : <RxDotFilled />}
          </span>
        </span>
        {!labelFirst && label ? (
          <p className={`${labelClassName} font-hauora font-bold`}>{label}</p>
        ) : (
          ""
        )}
      </label>
      {error && (
        <div className={`flex w-full ${errorClass}`}>
          <p className="text-red-500 text-xs">{error}</p>
        </div>
      )}
    </div>
  );
};

export default CheckBox;
