"use client";

import React, { useState } from "react";
import {  HiOutlineTrash } from "react-icons/hi";
import ConfirmationDialog from "../ConfirmationDialog";
import { DEFAULT_IMAGE } from "helper/common/constant";
import Image from "../Image";

const AvatarUpload = ({
  src,
  alt,
  className,
  loading = false,
  rounded = false,
  handleImageChange,
  handleEditImage,
  handleDeleteImage,
}: {
  src?: string | File | null;
  alt: string;
  className?: string;
  rounded?: boolean;
  loading?: boolean;
  handleImageChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleEditImage?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleDeleteImage?: () => void;
}) => {
  const [showDialog, setShowDialog] = useState(false);
  return (
    <div className={`relative ${className}`}>
      <div className={`group relative w-70 h-70`}>
        <Image
          src={src instanceof Blob ? URL.createObjectURL(src) : src}
          defaultImage={DEFAULT_IMAGE.defaultAvatar}
        />

        {src && (
          <div className="absolute group-hover:scale-100 scale-0 transition-all inset-0 bg-[#fcdada]/80 flex items-center justify-center rounded-full">
            <button
              type="button"
              className="text-Darkred text-2xl"
              onClick={() => {
                // handleDeleteImage && handleDeleteImage();
                setShowDialog(true);
              }}
            >
              <HiOutlineTrash />
            </button>
          </div>
        )}
      </div>
      {/* {!loading && (
      <button
        type="button"
        className="absolute top-0 -right-2 h-8 w-8 bg-white flex items-center justify-center rounded-full border border-light z-[1] overflow-hidden"
      >
        <Camera />
        <input
          type="file"
          className="absolute opacity-0 cursor-pointer w-32 rounded cursor-pointer"
          onChange={
            (e) =>
              src
                ? handleEditImage && handleEditImage(e) // for updating image
                : handleImageChange && handleImageChange(e) // for insert image
          }
          title=""
          accept="image/*"
        />
      </button>
    )} */}

      <ConfirmationDialog
        onConfirm={() => {
          setShowDialog(false);
          handleDeleteImage && handleDeleteImage();
        }}
        isOpen={showDialog}
        onClose={() => setShowDialog(false)}
        icon={<img src="/assets/images/bin.gif" alt="DELETE" />}
        title="Are you sure?"
        message="This action can not be undone. Do you want to continue?"
      />
    </div>
  );
};

export default AvatarUpload;
