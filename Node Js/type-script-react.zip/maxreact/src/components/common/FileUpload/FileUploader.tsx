import React, { useEffect, useState } from "react";
import { UseFormRegisterReturn } from "react-hook-form";
import cx from "classnames";
import Button from "../button/Button";

const FileUploader = ({
  register,
  labelClassName = "",
  parentClassName = "",
  label = "",
  error = "",
  className = "",
  required = false,
  info = false,
  title,
  border = "md",
  handleImageChange,
  handleDeleteImage,
  defaultImage,
  accept,
  uploadIcon,
  is_full_photo = false,
  disableButton = false,
  fileName = "",
}: {
  register?: UseFormRegisterReturn;
  className?: string;
  labelClassName?: string;
  parentClassName?: string;
  label?: string;
  error?: string;
  required?: boolean;
  info?: boolean;
  title?: string;
  border?: "sm" | "md";
  handleImageChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleDeleteImage?: () => void;
  defaultImage?: string | null;
  accept?: string;
  uploadIcon?: React.ReactNode;
  is_full_photo?: boolean;
  disableButton?: boolean;
  fileName?: string;
}) => {
  const classes = cx(
    className,
    `relative text-dark h-full outline-none flex items-center justify-center w-full py-15 border border-dashed border-uploaderborder rounded-lg bg-mainuploader overflow-hidden ${className}`,
    { [`border`]: border === "sm" },
    { [`border-2`]: border === "md" }
  );

  const [image, setImage] = useState<File | Blob | MediaSource | null>(null);
  const [imageName, setImageName] = useState<string>("");

  useEffect(() => {
    if (disableButton) {
      setImageName(fileName);
    } else {
      setImageName(getFileName(defaultImage as string));
    }
  }, [defaultImage]);
  
  useEffect(() => {
    defaultImage ? setImage(defaultImage as unknown as File) : setImage(null);
  }, [defaultImage]);
  

  const getFileName = (mediaUrl?: string) => {
    if (mediaUrl) {
      const urlParts = mediaUrl.split("/");
      let fileNameWithQuery = urlParts[urlParts.length - 1];
      const queryIndex = fileNameWithQuery.indexOf("?");
      if (queryIndex >= 0) {
        fileNameWithQuery = fileNameWithQuery.substring(0, queryIndex);
      }

      return fileNameWithQuery;
    }
    return "";
  };

  return (
    <div className={`relative flex flex-col gap-2 h-full w-full ${parentClassName} `}>
      {label && (
        <label
          className={`flex items-center gap-1 text-dark text-xs ${labelClassName} `}
        >
          {label}
          {required && <span className="text-red-500 font-medium">*</span>}

          {info && <div>Info</div>}
        </label>
      )}
      <div className={` group ${classes}`}>
        {/* 
        ** Important Note **
        -- When a file is not uploaded, the section below will be displayed. 
        */}

        <>
          <input
            type="file"
            accept={accept}
            className="absolute inset-0 opacity-0"
            {...register}
            // onFocus={(v: any) => {
            //   setImage(v.target.files[0]);
            // }}
            onChange={(e: any) => {
              // setImageName(e.target?.files?.[0].name);
              setImage(e.target?.files?.[0]);
              handleImageChange && handleImageChange(e);
            }}
          />
          <p className="fill-gray-500 ">
            {uploadIcon ? (
              uploadIcon
            ) : (
              <Button
                className={
                  "!bg-uploader text-13 font-medium !text-BrandBlack !px-15 !py-2.5"
                }
                title={"Choose Image"}
              />
            )}
          </p>
          <p className=" font-hauora text-sm font-bold text-black-light">
            {title}
          </p>
        </>
      </div>
      {error && <p className="text-red-500 text-xs">{error}</p>}
    </div>
  );
};

export default FileUploader;
 