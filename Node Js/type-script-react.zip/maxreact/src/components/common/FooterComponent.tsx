export function FooterComponent() {
    return (<>
        <div className="flex justify-start items-center h-10 bg-cyan-600"></div>
    </>)
}

export default FooterComponent;