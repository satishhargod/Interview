import React from "react";
import cx from "classnames";

interface InputProps {
  className?: string;
  type?: string;
  parentClassName?: string;
  placeholder?: string;
  label?: string;
  error?: string;
  startIcon?: React.ReactNode;
  endIcon?: React.ReactNode;
  icon?: React.ReactNode;
  required?: boolean;
  value?: string;
  handleChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  disabled?: boolean;
}

const SearchInput: React.FC<InputProps> = ({
  className,
  type = "text",
  parentClassName,
  placeholder,
  label = false,
  error = false,
  startIcon = false,
  endIcon = false,
  required = false,
  value,
  handleChange,
  disabled = false,
}) => {
  const classes = cx(
    className,
    `relative bg-white text-BrandBlack placeholder:text-BrandBlack/60 font-normal tracking-0.14 text-sm focus:outline-none px-15 py-13 pl-11 rounded-lg leading-normal border border-solid border-loginBorder`
  );

  const iconClasses = cx(
    `absolute flex items-center justify-center text-xl z-[1] left-4`,
  );

  return (
    <div className={`relative flex flex-col gap-2 ${parentClassName} `}>
      {label && (
        <label className="flex items-center gap-1 text-dark text-xs">
          {label}
          {required && <span className="text-red-500 font-medium">*</span>}
        </label>
      )}
      <div
        className={`relative flex items-center ${
          disabled && "opacity-60 pointer-events-none select-none"
        } `}
      >
        {startIcon && (
          <span className={` text-BrandBlack/30 ${iconClasses}`}>{startIcon}</span>
        )}
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={handleChange}
          className={classes}
          disabled={disabled}
        />
        {endIcon && <span className={`right-0 ${iconClasses}`}>{endIcon}</span>}
      </div>
      {error && <p className="text-red-500 text-xs">{error}</p>}
    </div>
  );
};

export default SearchInput;
