import React from "react";
import Button from "./button/Button";
import SearchInput from "./SearchInput";
import { HiOutlineSearch } from "react-icons/hi";
import CodeLink from "./CodeLink";
import { useLocation } from "react-router-dom";
import routes from "route/routes";
import Select from "./formInput/Select";

const HeadContent = ({
  title,
  children,
  isLoading,
  customButton,
  parentClass,
  paragraphClass,
  searchEnabled = true,
  filterByPlaceholder,
  filterByDurationEnabled=false,
  onSearch = (e: React.ChangeEvent<HTMLInputElement>) => { },
  addButtonEnable = true,
  addButtonTitle = "Add",
  filterByEnabled = false,
  onFilterBy,
  filterByOptions = [{ value: "", label: "No Options", selected: false }],
  onAdd = () => { },
  // selectedFilter
}: {
  title?: string;
  children?: any;
  isLoading?: boolean;
  customButton?: JSX.Element;
  parentClass?: string;
  paragraphClass?: string;
  searchEnabled?: boolean;
  addButtonEnable?: boolean;
  addButtonTitle?: string;
  filterByDurationEnabled?:boolean;
  filterByEnabled?: boolean;
  filterByPlaceholder?: string;
  onSearch?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onAdd?: () => void;
  onFilterBy?: (obj: {
    label: string;
    value: string;
    selected: boolean;
  }) => void;
  filterByOptions?: { value: string; label: string; selected: boolean }[];
  // selectedFilter?:string
}) => {
  const { pathname } = useLocation();

  const matchRoutes = routes.filter((route) => {
    if (route.path.includes("/:")) {
      return pathname.includes(route.path.split("/:")[0].toString());
    } else {
      return pathname.includes(route.path);
    }
  });

  return (
    <>
      <div
        className={`relative flex items-center justify-between mb-5 md:flex-col md:gap-5 md:items-start lg:flex-row lg:items-center ${parentClass}`}
      >
        {isLoading ? (
          <div role="status" className="max-w-sm animate-pulse">
            <div className="h-7 bg-gray-400 rounded-full  w-56   mb-4"></div>
          </div>
        ) : (
          <div className="">
            <p
              className={`text-BrandBlack font-bold text-22 leading-normal mb-2.5 ${paragraphClass}`}
            >
              {title}
            </p>
            <p
              className={`text-gray-600 font-normal text-sm leading-normal ${paragraphClass}`}
            >
              <CodeLink to={"/dashboard"} className="">
                Dashboard / &nbsp;
              </CodeLink>
              {matchRoutes[matchRoutes.length - 1 || 0].parentName &&
                ((matchRoutes[matchRoutes.length - 1 || 0]
                  .parentPath as string) ? (
                  <CodeLink
                    to={
                      matchRoutes[matchRoutes.length - 1 || 0]
                        .parentPath as string
                    }
                  >
                    {matchRoutes[matchRoutes.length - 1 || 0].parentName} /
                    &nbsp;
                  </CodeLink>
                ) : (
                  `${matchRoutes[matchRoutes.length - 1 || 0].parentName
                  } / `
                ))}
              <CodeLink
                to={matchRoutes[matchRoutes.length - 1 || 0].path}
                className="text-BrandBlack font-bold"
              >
                {matchRoutes[matchRoutes.length - 1 || 0].name}
              </CodeLink>
            </p>
          </div>
        )}
        <div className="relative flex items-center gap-4 ">
          <div className="relative flex items-center gap-2.5 xs:absolute xs:right-0 xs:top-6 xs:z-[45] xs:shadow-shadow xs:rounded xs:p-5 xs:flex-col xs:w-56 xs:bg-white xs:gap-5 md:gap-2.5 md:flex-row md:relative md:top-0 md:shadow-none md:rounded-none md:p-0 md:flex md:w-auto md:bg-transparent">
            {children && (
              <div className="flex items-center gap-5">{children}</div>
            )}

            {customButton ? customButton : <></>}

            {filterByDurationEnabled && (
              <Select
                options={filterByOptions}
                // defaultValue={}
                placeholder={filterByPlaceholder || "Filter By Duration"}
                onChange={onFilterBy}
                parentClassName="w-48"
                isSearchable={false}
                border="sm"
                isClearable
              />
            )}

            {filterByEnabled && (
              <Select
                options={filterByOptions}
                // defaultValue={filterByOptions.filter((data)=>data.value===selectedFilter)}
                placeholder={filterByPlaceholder || "Filter By"}
                onChange={onFilterBy}
                parentClassName="w-48"
                isSearchable={false}
                border="sm"
                isClearable
              />
            )}

            {/* Search Box */}
            {searchEnabled && (
              <SearchInput
                placeholder="Search"
                startIcon={<HiOutlineSearch className="text-gray-500 " />}
                handleChange={onSearch}
                className="h-46 w-60"
              />
            )}

            {/* Add New Button */}
            {addButtonEnable && (
              <Button
                title={addButtonTitle || "Add"}
                className={
                  "px-6 !w-auto !text-15 leading-0 h-46 flex items-center border-transparent border border-solid"
                }
                titleClassName={"leading-normal block"}
                onClick={onAdd}
              />
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default HeadContent;
