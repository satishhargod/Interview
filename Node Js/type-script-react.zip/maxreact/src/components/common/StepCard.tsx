import React from "react";

const StepCard = ({
  title,
  current,
  active,
  onClick,
  page = 1,
}: {
  title?: string;
  current?: boolean;
  active?: boolean;
  onClick?: ()=> void;
  page?: string | number;
}) => {
  return (
    <div>
      <button
        type="button"
        onClick={onClick}
        className={`flex items-center text-sm ${
          current
            ? "font-semibold text-black"
            : active
            ? "text-gray-500"
            : "text-gray-500 hover:text-dark"
        }`}
        disabled={!active}
      >
        <p className="flex gap-3 items-center cursor-pointer">
          <span className="relative flex items-center px-[8px] py-[2px] cursor-pointer rounded border-none bg-BrandBlack text-white">
            {page}
          </span>
          <span className={!current ? "text-3" : ""}>{title}</span>
        </p>
      </button>
    </div>
  );
};

export default StepCard;
