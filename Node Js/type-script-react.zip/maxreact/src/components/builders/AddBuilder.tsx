import React, { useEffect, useState } from "react";
import { RxChevronRight } from "react-icons/rx";
import StepCard from "components/common/StepCard";
import BuilderForm from "./FormBuilder";
import { useNavigate, useParams } from "react-router-dom";
import FormPoc from "./FormPoc";
import HeadContent from "components/common/HeadContent";
import { toastShow } from "redux/ducks/toast";
import { useDispatch } from "react-redux";
import {
  DEFAULT_COUNTRY_CODE,
  ErrorMessage,
  RESPONSE_STATUS,
} from "helper/common/constant";
import { IBuilderDetails } from "types/builders/builders";
import { addBuilder, builderById, updateBuilder } from "services/builder";
import { ICommonField } from "types/common/common";

interface propsType {
  selectedBuilder?: string | undefined;
}

const AddBuilder = (props: propsType) => {
  const { id } = useParams();

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [page, setPage] = useState(1);
  const [builderFormKey, setBuilderFormKey] = useState(0);
  const [basicDetails, setBasicDetails] = useState<IBuilderDetails>({
    name: "",
    address: "",
    phone: "",
    email: "",
    profileImage: "",
    countryCode: DEFAULT_COUNTRY_CODE,
  });
  const [builderContact, setBuilderContact] = useState<ICommonField[]>([
    {
      name: "",
      email: "",
      phone: "",
      countryCode: DEFAULT_COUNTRY_CODE,
    },
  ]);

  const fetchBuilderData = async () => {
    if (id) {
      const existingData = await builderById(id);
      setBasicDetails(existingData.data.data);
      setBuilderContact(existingData.data.data.BuilderContact);
      setBuilderFormKey((prevKey) => prevKey + 1);
    }
  };

  useEffect(() => {
    fetchBuilderData();
  }, []);

  const onSubmit = async (
    values: IBuilderDetails,
    contacts: ICommonField[]
  ) => {
    const formData = new FormData();
    formData.append("name", values.name);
    formData.append("phone", values.phone);
    formData.append("countryCode", values.countryCode as string);
    formData.append("address", values.address);
    formData.append("email", values.email);
    formData.append("isVerified", "false");
    formData.append("profileImage", (values.profileImage as File) || null);
    
    if (contacts[0] && contacts[0].name !== "") {
      formData.append("contacts", JSON.stringify(contacts));
    }
    let builderResponse;
    try {
      if (values._id) {
        formData.append("id", values._id);
        builderResponse = await updateBuilder(formData);
      } else {
        builderResponse = await addBuilder(formData);
      }
      if (builderResponse) {
        if (builderResponse.data?.responseType === RESPONSE_STATUS.success) {
          dispatch(
            toastShow({
              message: builderResponse.data.message,
              type: RESPONSE_STATUS.success,
            })
          );
          navigate("/builder");
        } else {
          dispatch(
            toastShow({
              message: builderResponse.data.message,
              type: RESPONSE_STATUS.error,
            })
          );
        }
      }

      //on success
    } catch (err) {
      console.log(err);
      dispatch(
        toastShow({
          message: ErrorMessage.SomethingWentWrong,
          type: RESPONSE_STATUS.error,
        })
      );
    }
  };

  return (
    <div>
      <HeadContent
        title={id ? "Update Builder" : "Create Builder"}
        searchEnabled={false}
        addButtonEnable={false}
        addButtonTitle="Add Builder"
      />

      <div className="max-w-900 w-full p-30 lg:pr-20 md:pr-30 bg-white border border-solid border-loginBorder rounded-xl">
        <div className="relative flex gap-3">
          <div className="flex items-center gap-3">
            <StepCard
              title={"Builder Details"}
              page={1}
              current={page === 1}
              onClick={() => setPage(1)}
              active={true}
            />
            <RxChevronRight className={`h-6 w-6 ${true && "text-gray-500"}`} />

            <StepCard
              title={"Point of Contacts"}
              page={2}
              current={page === 2}
              onClick={() => id && setPage(2)}
              active={true}
            />
          </div>
        </div>

        {/* Add Builder Form */}
        {page === 1 && (
          <BuilderForm
            key={builderFormKey}
            data={basicDetails}
            addMoreEnable={true}
            onAddMore={(val: IBuilderDetails) => {
              setBasicDetails((prev: IBuilderDetails) => {
                return { ...prev, ...val };
              });
              setPage(2);
            }}
            onHandleSubmit={(val) => {
              onSubmit(val, builderContact);
            }}
            onCancel={() => navigate("/builder")}
          />
        )}

        {/* Point of Contacts */}
        {page === 2 && (
          <FormPoc
            key={builderFormKey + 1}
            data={builderContact}
            onCancel={() => navigate("/builder")}
            onHandleSubmit={(val) => {
              setBuilderContact(val.poc as ICommonField[]);
              onSubmit(basicDetails, val.poc as ICommonField[]);
            }}
          />
        )}
      </div>
    </div>
  );
};

export default AddBuilder;
