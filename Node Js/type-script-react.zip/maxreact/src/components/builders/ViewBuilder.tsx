import React, { useEffect, useState } from "react";
import Dialog from "../common/Dialog";
// import Button from "../common/button/Button";
import { companyDateFormat, truncateString } from "helper/common/function";
import { ICompanyData } from "@/types/company/company";
import Select from "../common/formInput/Select";
import { useForm } from "react-hook-form";
import { getCompanyDataById } from "services/company";
import Loader from "components/common/Loader";
import { FaCircle } from "react-icons/fa6";
import { builderById } from "services/builder";
import { IBuilderDetails } from "types/builders/builders";
import { DEFAULT_IMAGE } from "helper/common/constant";
import Button from "components/common/button/Button";
import Image from "components/common/Image";

interface IViewBuilder {
  onClose: () => void;
  title?: string;
  selectedBuilder: string;
  isOpen: boolean;
  //   isLoading: boolean;
  //   onSubmit: (values: ICompanyData) => void;
}

const ViewBuilder = (props: IViewBuilder) => {
  const { onClose, title, selectedBuilder, isOpen } = props;
  const [builderDetails, setBuilderDetails] = useState<IBuilderDetails>();
  const { register, handleSubmit, setValue } = useForm({
    defaultValues: {
      phone: "",
      name: "",
      email: "",
      address: "",
    },
  });

  const fetchBuilderData = async () => {
    if (selectedBuilder) {
      const builderResponse = await builderById(selectedBuilder);
      console.log("builderResponse: ", builderResponse.data.data);
      //   setValue("status", companyResponse.data.data["status"]);
      setBuilderDetails(builderResponse.data.data);
    } else {
      console.log("Company details are undefined");
    }
  };

  useEffect(() => {
    fetchBuilderData();
  }, []);

  return (
    <div>
      <Dialog
        onClose={onClose}
        title={title}
        isOpen={isOpen}
        className={`${builderDetails ? "h-406px rounded-14" : "h-full"}`}
      >
        {builderDetails ? (
          <div className="flex flex-col">
            <div className="flex items-center justify-between w-full">
              <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
                Builder Logo :
              </span>
              <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
                <div className="relative w-10 h-10 rounded-full">
                  <Image
                    src={builderDetails.profileImageUrl as string}
                    defaultImage={DEFAULT_IMAGE.defaultAvatar}
                  />
                </div>
              </span>
            </div>
            <div className="flex items-center justify-between w-full">
              <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
                Company Name :
              </span>
              <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
                {builderDetails.name}
              </span>
            </div>
            <div className="flex items-center justify-between w-full">
              <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
                Email Address :
              </span>
              <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
                {builderDetails.email}
              </span>
            </div>
            <div className="flex items-center justify-between w-full">
              <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
                Phone Number :
              </span>
              <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
                {builderDetails.phone || "+0 123 456 789"}
              </span>
            </div>
            <div className="flex items-center justify-between w-full">
              <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
                Created At :
              </span>
              <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
                {/* {companyDateFormat(builderDetails.createdAt) || "No Date Available"} */}
                No Date Available
              </span>
            </div>
            <div className="flex items-center justify-between w-full">
              <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
                Account Type:
              </span>
              <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
                {/* {builderDetails.type || "Company"} */}
                Company
              </span>
            </div>
            <div className="flex items-start justify-between w-full">
              <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4 block"></span>
              <div className="w-2/4 mt-4">
                <Button
                  className={"!w-auto px-6"}
                  onClick={onClose}
                  title={"Close"}
                />
              </div>
            </div>
          </div>
        ) : (
          <Loader />
        )}
      </Dialog>
    </div>
  );
};

export default ViewBuilder;
