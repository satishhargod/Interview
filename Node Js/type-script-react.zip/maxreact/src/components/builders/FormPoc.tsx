import { yupResolver } from "@hookform/resolvers/yup";
import { pointOfContactsSchema } from "validation/builders/buildersValidation";
import React, { useEffect, useState } from "react";
import { useFieldArray, useForm } from "react-hook-form";
import Input from "components/common/formInput/Input";
import Button from "components/common/button/Button";
import { IBuilderPocData } from "types/builders/builders";
import { ICommonField } from "types/common/common";
import CustomPhoneInput from "components/common/formInput/CustomPhoneInput";
import { DEFAULT_COUNTRY_CODE } from "helper/common/constant";

interface IPocForm {
  onCancel: () => void;
  onHandleSubmit: (values: IBuilderPocData) => void;
  data: ICommonField[];
}

const FormPoc = (props: IPocForm) => {
  const { data, onCancel, onHandleSubmit } = props;
  const {
    register,
    handleSubmit,
    control,
    trigger,
    setValue,
    getValues,
    getFieldState,
    formState: { errors, isValid },
  } = useForm<IBuilderPocData>({
    defaultValues: { poc: data },
    resolver: yupResolver(pointOfContactsSchema),
  });

  const { fields, append, remove, swap, move, insert } = useFieldArray({
    control,
    name: "poc",
  });
  const [activeField, setActiveField] = useState<string | null>(null);

  return (
    <div className="mt-10 flex w-full">
      <form onSubmit={handleSubmit(onHandleSubmit)}>
        {fields.map((field: any, index: number) => (
          <div key={field.id} className="mb-5 relative group">
            <div className=" flex md:flex-wrap lg:flex-nowrap gap-6">
              <Input
                label={`Name`}
                placeholder="Enter Your Full Name"
                type="text"
                register={register(`poc.${index as number}.name`)}
                className="!px-15 !py-2.5"
                parentClassName="md:w-[calc(50%-12px)] lg:w-1/3"
                error={errors?.poc?.[index]?.name?.message}
              />
              <Input
                label="Email"
                placeholder="Enter Your Email"
                type="text"
                register={register(`poc.${index as number}.email`)}
                className="!px-15 !py-2.5"
                parentClassName="md:w-[calc(50%-12px)] lg:w-1/3"
                error={errors?.poc?.[index]?.email?.message}
              />
              <CustomPhoneInput
                label={"Phone Number"}
                type="text"
                className="!px-15 !py-2.5"
                parentClassName={`md:w-[calc(50%-12px)] lg:!w-1/3 ${
                  activeField === `poc.${index as number}.phone`
                    ? "!z-[10]"
                    : "!z-[1]"
                } `}
                inputClassname="!w-full"
                registerPhoneNo={register(`poc.${index as number}.phone`, {
                  pattern: {
                    value: /^[0-9+-]+$/,
                    message: "Enter Number's only",
                  },
                })}
                registerCountryCode={register(
                  `poc.${index as number}.countryCode`
                )}
                setValueCountry={(value) =>
                  setValue(`poc.${index as number}.countryCode`, value)
                }
                error={
                  errors?.poc?.[index]?.phone?.message ||
                  errors?.poc?.[index]?.countryCode?.message
                }
                getValueCountry={
                  getValues(`poc.${index as number}.countryCode`) as string
                }
                onFocus={() => setActiveField(`poc.${index as number}.phone`)}
              />
            </div>
            {index !== 0 && (
              <Button
                onClick={() => {
                  remove(index);
                }}
                type="button"
                title={"X"}
                variant="filled"
                className={`!bg-BrandBlack/5 !text-black !w-auto h-46 !px-5 block mt-8 absolute lg:-right-16 lg:top-0 md:top-auto md:bottom-0 md:right-0 `}
              />
            )}
          </div>
        ))}

        <Button
          type="button"
          title={"Add Other"}
          className={"!w-auto !px-5"}
          onClick={() => {
            trigger();
            isValid &&
              append({
                name: "",
                email: "",
                phone: "",
                countryCode: DEFAULT_COUNTRY_CODE,
              });
          }}
        />
        <div className="flex gap-5 justify-end">
          <Button
            onClick={onCancel}
            title={"Cancel"}
            type="button"
            variant="outline"
            className={
              "!bg-BrandBlack/10 !text-black mt-30 !w-auto !px-10 block"
            }
          />
          <Button
            // onClick={onClose}
            title={"Save"}
            type="submit"
            variant="outline"
            className={
              "!bg-white border-2 !text-black mt-30 !w-auto !px-10  block"
            }
          />
        </div>
      </form>
    </div>
  );
};

export default FormPoc;
