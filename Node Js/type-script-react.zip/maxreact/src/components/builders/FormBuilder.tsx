import React, { useEffect, useState } from "react";
import Input from "components/common/formInput/Input";
import AvatarUpload from "components/common/FileUpload/AvatarUpload";
import FileUploader from "components/common/FileUpload/FileUploader";
import Button from "components/common/button/Button";
import { useForm } from "react-hook-form";
import { IBuilderDetails } from "types/builders/builders";
import { yupResolver } from "@hookform/resolvers/yup";
import { builderFormSchema } from "validation/builders/buildersValidation";
import {
  ALLOWED_IMAGE_MIME_TYPES,
  MAX_IMAGE_SIZE,
} from "helper/common/constant";
import CustomPhoneInput from "components/common/formInput/CustomPhoneInput";
import { getAddressOnSearch } from "helper/common/function";

interface IBuilderForm {
  data: IBuilderDetails;
  onHandleSubmit: (values: IBuilderDetails) => void;
  onAddMore: (values: IBuilderDetails) => void;
  onCancel: () => void;
  addMoreEnable?: boolean;
}

const BuilderForm = (props: IBuilderForm) => {
  const { data, onHandleSubmit, onAddMore, onCancel, addMoreEnable } = props;
  const [profileImage, setProfileImage] = useState<string | File | undefined>(
    data.profileImageUrl || ""
  );
  const [errorMessageImage, setErrorMessageImage] = useState<
    string | undefined
  >(undefined);
  const [addresses, setAddresses] = useState<string[] | null>(null);

  const {
    register,
    handleSubmit,
    getValues,
    watch,
    setValue,
    setError,
    formState: { errors, isValid },
  } = useForm<IBuilderDetails>({
    defaultValues: { ...data },
    resolver: yupResolver(builderFormSchema),
  });

  const address = watch("address");

  const checkImageType = (image: string) =>
    !ALLOWED_IMAGE_MIME_TYPES.includes(image);
  const checkImageSize = (image: number) => image > MAX_IMAGE_SIZE;

  const handleEditImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const image = e.target.files?.[0] || null;

    if (!image) return;

    if (checkImageType(image.type?.trim())) {
      setErrorMessageImage("Please upload valid image type.");
      return;
    }
    if (checkImageSize(image.size)) {
      setErrorMessageImage(
        "Please upload an image with a size less than 10 MB."
      );
      return;
    }

    setErrorMessageImage(undefined);
    setProfileImage(image);
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const image = e.target.files?.[0] || null;
    if (!image) return;

    if (checkImageType(image.type?.trim())) {
      setErrorMessageImage("Please upload valid image type.");
      return;
    }
    if (checkImageSize(image.size)) {
      setErrorMessageImage(
        "Please upload an image with a size less than 10 MB."
      );
      return;
    }
    setErrorMessageImage(undefined);
    setProfileImage(image);
  };

  const onSubmit = (values: any) => {
    const address = watch("address");
    if (addresses && addresses.includes(address)) {
      onHandleSubmit({ ...values, profileImage: profileImage });
    } else {
      setError("address", {
        message: "Address not found. Please select the Near by location.",
      });
    }
  };

  useEffect(() => {
    (async () => setAddresses(await getAddressOnSearch(address)))();
  }, [address]);
  return (
    <div>
      <div className="flex items-center gap-30 my-6">
        <AvatarUpload
          src={profileImage}
          alt={"profileImgAlt"}
          handleDeleteImage={() => {
            setProfileImage("");
          }}
          handleImageChange={handleImageChange}
          handleEditImage={handleEditImage}
        />
        <FileUploader
          handleImageChange={(e: any) => {
            handleEditImage(e);
            handleImageChange(e);
          }}
        />
      </div>

      {errorMessageImage && (
        <span className="text-Darkred block -mt-5 mb-5">
          {errorMessageImage}
        </span>
      )}
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className=" flex flex-col gap-6">
          <Input
            label={`Builder Name`}
            placeholder="Enter Your Full Name"
            type="text"
            register={register("name")}
            className={`!px-15 !py-2.5 ${errors.name ? "border-Darkred" : ""}`}
            error={errors.name?.message as string}
          />
          <Input
            label="Email"
            placeholder="Enter Your Email"
            type="text"
            register={register("email")}
            className="!px-15 !py-2.5"
            error={errors.email?.message as string}
          />
          <CustomPhoneInput
            label={"Phone Number"}
            type="text"
            className="!px-15 !py-2.5"
            registerPhoneNo={register("phone", {
              pattern: {
                value: /^[0-9+-]+$/,
                message: "Enter Number's only",
              },
            })}
            registerCountryCode={register("countryCode")}
            setValueCountry={(value) => setValue("countryCode", value)}
            error={errors.phone?.message || errors.countryCode?.message}
            getValueCountry={getValues("countryCode") as string}
          />
          <div className="relative">
            <Input
              label="Address"
              placeholder="Enter Your Address"
              className="!px-15 !py-2.5"
              register={register("address")}
              error={errors.address?.message as string}
            />

            {addresses &&
              !addresses.includes(address) &&
              addresses.length > 0 && (
                <div className="flex flex-col absolute p-5 shadow-dialogshadow border border-solid border-loginBorder rounded-lg top-full bg-white mt-2 w-full max-h-36 overflow-y-auto">
                  {addresses.map((address) => (
                    <ul className="pl-4">
                      <li
                        onClick={() => setValue("address", address)}
                        className=" py-2 list-disc"
                      >
                        {address}
                      </li>
                    </ul>
                  ))}
                </div>
              )}
          </div>
        </div>
        <div className="flex gap-5 justify-end">
          <Button
            onClick={onCancel}
            title={"Cancel"}
            type="button"
            variant="outline"
            className={
              "!bg-BrandBlack/10 !text-black mt-30 !w-auto !px-10 block"
            }
          />
          <Button
            // onClick={onAddMore}
            title={data._id ? "Update" : "Save"}
            type="submit"
            variant="outline"
            className={
              "!bg-white border-2 !text-black mt-30 !w-auto !px-10  block"
            }
          />
          {addMoreEnable && (
            <Button
              onClick={() => {
                if (isValid) {
                  onAddMore({ ...getValues(), profileImage: profileImage });
                }
              }}
              title={"Add POC"}
              type="button"
              variant="outline"
              className={
                "!bg-BrandBlack  !text-white mt-30 !w-auto !px-10  block"
              }
            />
          )}
        </div>
      </form>
    </div>
  );
};

export default BuilderForm;
