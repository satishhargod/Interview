import { IRouteAttribute, ISubRouteAttribute } from "types/route";
import { FaAngleRight } from "react-icons/fa6";
import { INavOptions } from "types/layout";
import { Link } from "react-router-dom";
import { useState } from "react";

interface IMenu {
  menuData: INavOptions;
  isActive: boolean;
  collapsed: boolean;
  onNavigate: (path: string) => void;
  isSubMenuVisible: string | null;
  setSubMenuVisible: (menuId: string | null) => void;
  activePath: string;
}

const SideBarMenu = ({
  menuData,
  isActive,
  onNavigate,
  isSubMenuVisible,
  setSubMenuVisible,
  activePath,
  collapsed,
}: IMenu) => {
  // const [openSubNav, setSubnav] = useState(true);
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  const handleNavigation = () => {
    if (!menuData?.subNavigationOptions) {
      onNavigate(menuData.link || "");
    }
    if (isSubMenuVisible === menuData.link) {
      setSubMenuVisible(null);
    } else {
      setSubMenuVisible(menuData.link);
    }
  };
  return (
    <>
      <div
        className={`flex items-center justify-between gap-2.5 text-BrandBlack text-base py-2.5 px-2 rounded-lg font-medium leading-normal cursor-pointer transition duration-100 overflow-hidden ${isActive ? "bg-menubg" : ""
          }`}
        onClick={() => handleNavigation()}
        onMouseEnter={() => handleMouseEnter()}
        onMouseLeave={() => handleMouseLeave()}
      >
        <div className="relative flex items-center gap-2.5 whitespace-nowrap">
          <span className="flex items-center text-3xl">
            {menuData.iconDetails?.icon}
          </span>
          <span>{menuData.title} </span>

        </div>
        {menuData?.subNavigationOptions && (
          <FaAngleRight
            className={`transition-all ease-in-out duration-300 ${isSubMenuVisible !== menuData.link ? "rotate-0" : "rotate-90"
              }`}
          />
        )}
      </div >
      {collapsed && isHovered && menuData?.subNavigationOptions &&
        <div className="pl-20 absolute -mt-20"
          onMouseEnter={() => handleMouseEnter()}
          onMouseLeave={() => handleMouseLeave()}
        >
          <ul className="w-auto p-2 shadow-dialogshadow relative rounded-lg bg-white z-50 before:absolute before:border-8 before:border-solid before:border-transparent before:border-r-white  before:-left-5 before:w-5 before:h-5 before:top-2/4 before:-translate-y-2/4">
            {menuData?.subNavigationOptions?.map((item, index: number) => {
              return (
                <li key={index} className="">
                  <div
                    className={`px-5 text-BrandBlack text-base py-2.5 font-medium leading-normal cursor-pointer block ${isActive && activePath === item.link ? "bg-menubg" : ""
                      }`}
                    onClick={(e: React.MouseEvent) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setIsHovered(false);
                      onNavigate(item.link);
                    }}
                  >
                    {item.title}
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      }
      {!collapsed && <ul className="w-full">
        {!collapsed && isSubMenuVisible === menuData.link &&
          menuData?.subNavigationOptions?.map((item, index: number) => {
            return (
              <li key={index} className="">
                <div
                  className={`pl-12 text-BrandBlack text-base py-2.5 font-medium leading-normal cursor-pointer block ${isActive && activePath === item.link ? "bg-menubg" : ""
                    }`}
                  onClick={(e: React.MouseEvent) => {
                    e.preventDefault();
                    e.stopPropagation();
                    onNavigate(item.link);
                  }}
                >
                  {item.title}
                </div>
              </li>
            );
          })}
        {/* {menuData.subNavigationOptions &&
          menuData.subNavigationOptions.length > 0 &&
          openSubNav && (
            <div className="flex flex-col mt-4">
              <ul className="flex gap-4 flex-col">
                {menuData.subNavigationOptions &&
                  menuData.subNavigationOptions.map((subNav, index) => {
                    let isActivatedTab = false;
                    const currentPath = activePath?.replace("/", "");
                    if (currentPath?.startsWith(subNav.value)) {
                      isActivatedTab = true;
                    }
                    return (
                      <Link
                        to={subNav.link}
                        className={` ${isActivatedTab ? "bg-black/40" : ""} ${
                          isSubMenuVisible
                            ? "px-6"
                            : `pl-6 pr-1 py-2 hover:bg-black/40 rounded-full rounded-r-none`
                        } transition-all duration-300`}
                      >
                        <li className="flex items-end">
                          <p className="w-[calc(100%_-_80px)] pr-10px text-white text-sm leading-4 font-semibold">
                            <span className="block">Step {index + 1}: </span>
                            <span className="block mt-1">{subNav.title}</span>
                          </p>
                          <span
                            className={`badge inline-block text-center py-px bg-white w-20 text-xs leading-4 rounded-full h-fit font-semibold capitalize ${subNav.status}`}
                          >
                            {subNav.status}
                          </span>
                        </li>
                      </Link>
                    );
                  })}
              </ul>
            </div>
          )} */}
      </ul>}
    </>
  );
};

export default SideBarMenu;
