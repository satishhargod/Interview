import { HeaderProps } from "types/layout";
import { FaBars } from "react-icons/fa6";
import { useEffect, useRef, useState } from "react";
import { Exiticon, Notification, Profileicon } from "icons";
import { useNavigate } from "react-router-dom";
import Logout from "../logout/Logout";
import { useSelector } from "react-redux";
import { profileSelector } from "redux/ducks/profile";
import Image from "components/common/Image";
import { DEFAULT_IMAGE } from "helper/common/constant";

const Header = ({ onToggleSidebar }: HeaderProps) => {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isLogoutOpen, setIsLogoutOpen] = useState(false);
  const profile = useSelector(profileSelector);
  const navigate = useNavigate();
  const profileRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        profileRef.current &&
        !profileRef.current.contains(event.target as Node)
      ) {
        // Clicked outside the modal, close it
        setIsProfileOpen(false);
      }
    };

    // Attach the event listener to the document body
    document.addEventListener("mousedown", handleClickOutside);

    // Clean up the event listener when the component is unmounted
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <header className="bg-white flex items-center justify-between py-4 px-6 fixed left-0 right-0 top-0 border-b border-solid border-loginBorder z-999">
      <div className="flex items-center gap-30">
        <span
          title={"click me"}
          onClick={onToggleSidebar}
          className="p-2 border border-solid border-loginBorder rounded-lg cursor-pointer"
        >
          <FaBars className="text-2xl" />
        </span>
        <img src="/assets/images/logo.svg" alt="" className="w-135 h-50" />
      </div>
      <div className="flex items-center gap-5 relative">
        <Notification />
        <div
          className={`w-10 h-10 rounded-full cursor-pointer  border-solid border-black transition-all ease-in-out duration-300`}
          onClick={() => setIsProfileOpen((prev) => !prev)}
        >
          <Image
            src={typeof profile.image === "string" ? profile.image : ""}
            defaultImage={DEFAULT_IMAGE.defaultAvatar}
          />
        </div>
        {isProfileOpen && (
          <div
            className="absolute bg-white rounded-lg border border-solid border-loginBorder shadow-dropdownshadow w-150 right-0 top-12 px-3 py-2"
            ref={profileRef}
          >
            <ul>
              <li>
                <a className="flex items-center gap-2.5 px-1 py-2 cursor-pointer">
                  <Profileicon />
                  <span
                    className={
                      "text-black text-base font-normal leading-normal block"
                    }
                    // title={"Profile"}
                    onClick={() => {
                      navigate("/dashboard/profile");
                      setIsProfileOpen((prev) => !prev);
                    }}
                  >
                    Profile
                  </span>
                </a>
              </li>
              <li>
                <a
                  className="flex items-center gap-2.5 px-1 py-2 cursor-pointer "
                  onClick={() => setIsLogoutOpen(true)}
                >
                  <Exiticon />
                  <span className="text-black text-base font-normal leading-normal block">
                    Logout
                  </span>
                </a>
              </li>
            </ul>
            <Logout
              isLogoutOpen={isLogoutOpen}
              setIsLogoutOpen={setIsLogoutOpen}
            />
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
