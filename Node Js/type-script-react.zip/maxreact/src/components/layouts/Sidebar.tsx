import { useEffect, useState } from "react";
import routes from "route/routes";
import { useLocation } from "react-router-dom";
import { SideBarProps } from "types/layout";
import SideBarMenu from "./SideBarMenu";
import { UserRole, userRolesCategories } from "utils/navigation.utils";
import { useSelector } from "react-redux";
import { profileSelector } from "redux/ducks/profile";
import { NavigationOptions } from "route/Navigation";

const Sidebar = ({ collapsed, activeSection, onNavigate }: SideBarProps) => {
  const profileData = useSelector(profileSelector);
  const [navigationList, setNavigationList] = useState(NavigationOptions);
  const [isSubMenuVisible, setSubMenuVisible] = useState<string | null>(null);
  const location = useLocation().pathname;
  // const [role, setRole] = useState(userRolesCategories.Admin);

  // if (activeSection.trim().length === 0) {
  //   activeSection = location;
  // }

  const getUserRole = (role: string) => {
    // Normalize to lowercase for case-insensitive comparison
    const normalizedRole = role?.toLowerCase();
    // Find the matching role in the enum
    const matchedRole = Object.keys(UserRole).find(
      (enumRole) => UserRole[enumRole].toLowerCase() === normalizedRole
    );

    return matchedRole || "Invalid Role";
  };

  useEffect(() => {
    const data = getUserRole(profileData?.roles[0]);
    const role = userRolesCategories[data];

    console.log(profileData, data);
    const filterdSideBarItem = navigationList.filter((item) => {
      if (item.isAllow) {
        if (role?.includes(item.title)) {
          return item;
        } else {
          return false;
        }
      }
    });
    setNavigationList(filterdSideBarItem);
  }, []);

  return (
    <div
      className={`bg-white h-screen border-r border-solid border-0 border-r-loginBorder p-6 transition-all ease-in-out duration-300 overflow-hidden z-50 xs:fixed xs:top-0 xs:left-0 xl:static ${
        collapsed ? "w-94" : "w-255"
      }`}
    >
      <ul className=" h-full w-full pt-84">
        {navigationList.map((menuData, index) => {
          if (menuData.isAllow === true) {
            const pathArray = activeSection.toString();
            let active = false;
            if (menuData?.subNavigationOptions) {
              const currentPath = activeSection?.replace("/", "");
              active = menuData.subNavigationOptions.some((data) =>
                currentPath?.endsWith(data.value)
              );
            } else {
              // active = menuData.link === activeSection;
              const currentPath = activeSection?.replace("/", "");
              if (currentPath?.startsWith(menuData.value)) {
                active = true;
              }
            }

            return (
              <li className="mb-1.5" key={index}>
                <SideBarMenu
                  menuData={menuData}
                  collapsed={collapsed}
                  isActive={active}
                  onNavigate={onNavigate}
                  isSubMenuVisible={isSubMenuVisible}
                  setSubMenuVisible={setSubMenuVisible}
                  activePath={activeSection}
                />
              </li>
            );
          }
        })}
      </ul>
      {/* </nav> */}
    </div>
  );
};

export default Sidebar;
