import HeadContent from 'components/common/HeadContent';
import  { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import SiteAbstractData from './SiteAbstractData';
import CustomTable from 'components/common/table/CustomTable';
import ViewSiteColumns from './columns/ViewSiteColumns';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import { FaQuestion } from 'react-icons/fa';

const data = [{
  jobId: 1,
  siteAddress: 'dfhsdffuideh',
  stagesOfErec: 1,
  hirePeriod: '1 week',
  createdDate: new Date().toLocaleString(),
  createdBy: 'Jhon',
  contractPrice: '$752.5',
  status: true,
}, {
  jobId: 2,
  siteAddress: 'rytreuiryuier',
  stagesOfErec: 2,
  hirePeriod: '2 week',
  createdDate: new Date().toLocaleString(),
  createdBy: 'Eleanor Pena',
  contractPrice: '$700.5',
  status: false,
}]

const ViewSite = () => {
  const { id } = useParams();
  const navigate = useNavigate()
  const [viewSiteData, setViewSiteData] = useState<any>([]);

  const [totalCount, setTotalCount] = useState(10);
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(10);

  const [isLoading, setIsLoading] = useState(false)
  const [tableLoader, setTableLoader] = useState(false)
  const [isDeleteLoading, setIsDeleteLoading] = useState(false);

  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState();
  const [isModalOpenData, setIsModalOpenData] = useState({ value: false, data: false, id: null, name: "", email: "" });

  const [selectedViewSite, setSelectedViewSite] = useState<any>(null);
  console.log('selectedViewSite: ', selectedViewSite);
  const [modalTitle, setModalTitle] = useState("");

  const [searchKeyword, setSearchKeyword] = useState("");

  const fetchVIewSiteData = (values: { page: number, limit: number, search?: string, status?: boolean }) => {
    console.log('values: ', values);
    setViewSiteData(data);
    // setTotalCount(2);
  }

  const demo = "archer";
  return (
    <div>
      <div>
        <HeadContent
          title="Builders"
          searchEnabled={true}
          onSearch={() => { }}
          filterByDurationEnabled
          addButtonEnable={true}
          addButtonTitle="Add New Job"
          //   onAdd={() => navigate(`/jobs/create`)}
          onAdd={() => navigate(`/jobs/create/${demo}`)}
        />
      </div>
      <div>
        <SiteAbstractData />
      </div>
      <div>

        <CustomTable
          data={viewSiteData}
          columns={
            ViewSiteColumns({
              setIsDeleteOpen,
              setIsEditOpen,
              setIsViewOpen,
              setSelectedViewSite,
              setModalTitle,
              setIsModalOpen,
              setIsModalOpenData,
              totalCount,
              page,
            }).columns
          }
          fetchData={fetchVIewSiteData}
          searchKeyword={searchKeyword}
          totalCount={totalCount}
          page={page}
          setPage={setPage}
          pageSize={pageSize}
          isLoading={tableLoader}
          setIsLoading={setTableLoader}
        />

      </div>
      {selectedViewSite && isDeleteOpen && (
        <ConfirmationDialog
          title="Are you sure?"
          message="This action can not be undone. Do you want to continue?"
          onClose={() => setIsDeleteOpen(false)}
          onConfirm={() => { }}
          isOpen={isDeleteOpen}
          icon={<img src="/assets/images/bin.gif" alt="DELETE" />}
          isLoading={isDeleteLoading}
        />
      )}
      {isModalOpen && (
        <ConfirmationDialog
          title="Are you sure?"
          message={`You want to ${isModalOpenData.data === true ? "Active" : "In-Active"
            } Company`}
          onClose={() => {
            setIsModalOpenData({ value: false, id: null, name: '', email: '', data: false })
            setIsModalOpen(undefined)
          }}
          onConfirm={() => {}}
          isOpen={isModalOpenData.value}
          icon={<FaQuestion />}
        />
      )
      }
    </div>
  )
}

export default ViewSite