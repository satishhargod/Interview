import React from 'react'
import { DEFAULT_IMAGE } from "helper/common/constant";
import Image from 'components/common/Image';
import Button from 'components/common/button/Button';

const SiteAbstractData = () => {
    return (
        <div>
            <div className="max-w-full bg-white shadow-dropdownshadow rounded-10 overflow-hidden p-4 flex">
                <div className="relative">
                    <Image
                        src={''}
                        imageClassName={'w-full h-40 object-cover object-center border-none rounded-lg'}
                        alt="card"
                        defaultImage={DEFAULT_IMAGE.defaultCardImage}
                    />
                </div>
                <div>
                    <div className='flex w-full gap-30'>
                        <div>
                            <span>Builder Name: </span>
                            <span>CPB Contractors</span>
                        </div>
                        <div>
                            <span>Builder Email: </span>
                            <span>cpbcontractors@outlook.com</span>
                        </div>
                        <div>
                            <span>Phone Number: </span>
                            <span>+612 1234 5678</span>
                        </div>
                    </div>
                    <div  className='w-1/4 mt-30'>
                        <Button 
                            title={'View Contact Details'}
                        />
                    </div>
                </div>
            </div>
        </div>
    )
}

export default SiteAbstractData