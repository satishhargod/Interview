import { yupResolver } from '@hookform/resolvers/yup'
import { createSchema } from 'validation/job/createJobValidation'
import Button from 'components/common/button/Button'
import DateInput from 'components/common/formInput/DateInput'
import Input from 'components/common/formInput/Input'
import Select from 'components/common/formInput/Select'
import HeadContent from 'components/common/HeadContent'
import React, { useEffect, useState } from 'react'
import { Controller, useForm } from 'react-hook-form'
import { useLocation, useParams } from 'react-router-dom'

const AssigneeToValue = {
    selectStaffForInspection: '',
    assigneeWorker: '',
}
const transportValue = {
    totalAllowances: 0,
    costAfterAllowances: 0,
}

const subContractorsAllowancesValue = {
    erectPrice: 0,
    dismantlePrice: 0,
    alterationPrice: 0,
    lytaPrice: 0,
    travelPrices: 0,
    totalPrice: 0,
}

const createJobValues = {
    builder: "",
    bEmail: '',
    bNumber: 0,
    bLocation: '',
}

const leadDetailsValue = {
    stagesHire: 0,
    hirePeriod: 0,
    hStartDate: new Date(),
    hEndDate: new Date(),
    dayAfterThereAfter: 0,
    contractPrice: 0,
    inspectionDate: new Date(),
}

interface propsType {
    builder?: string
}

const options = [
    { label: 'Archer', value: 'archer' },
    { label: 'Demo', value: 'demo' },
];


const CreateJobs = (props: propsType) => {
    const { data } = useParams();
    const location=useLocation().pathname;
    const createHeader = (title: string) => {
        return (
            <p className="text-BrandBlack font-bold text-22 leading-normal mb-2.5">
                {title}
            </p>
        )
    }

    const {
        register,
        handleSubmit,
        control,
        setValue,
        formState: { errors },
    } = useForm({
        defaultValues: { ...createJobValues, ...leadDetailsValue, ...subContractorsAllowancesValue, ...transportValue, ...AssigneeToValue },
        resolver: yupResolver(createSchema)
    });

    useEffect(() => {
        const loc=location.split('/')
        if(data){
            if(loc.includes('edit')){
                console.log("edit");
            }else{
                setValue('builder', data)

            }
        }
    }, [setValue])

    const onSubmit = (values: any) => {
        console.log('values: ', values);

    }

    return (
        <div>
            <div>
                <HeadContent
                    title="Jobs"
                    searchEnabled={false}
                    addButtonEnable={false}
                />
            </div>
            <div>
                <div>
                    <form
                        onSubmit={handleSubmit(onSubmit)}
                        className={"h-full"}
                    >
                        <div>
                            <div>
                                {createHeader("Create Jobs")}
                                <div className='flex w-full justify-between items-center gap-2'>
                                    <Controller
                                        name="builder"
                                        control={control}
                                        render={({ field }) => {
                                            console.log('field: ', field);
                                            return (
                                                <Select
                                                    label="Select Builder"
                                                    options={options.filter((data) => data.value !== field.value)}
                                                    register={register("builder")}
                                                    border="sm"
                                                    value={options.find((opt) => opt.value === field.value)}
                                                    onChange={(obj) => {
                                                        // setError("builder", { message: "" });
                                                        // setValue("builder", obj.value);
                                                        field.onChange(obj.value)
                                                    }}
                                                    parentClassName='w-2/4'
                                                    error={errors.builder?.message as string}
                                                />
                                            )
                                        }}
                                    />
                                    <Input
                                        label="Builder Email"
                                        placeholder="Enter email"
                                        type="text"
                                        register={register("bEmail")}
                                        parentClassName='w-2/4'
                                        className={'h-46'}
                                        // className={`${errors.email ? "border-Darkred" : ""}`}
                                        error={errors.bEmail?.message as string}
                                    />
                                </div>
                                <div className='flex w-full justify-between items-center gap-2'>
                                    <Input
                                        label="Contract Number"
                                        placeholder="1234567890"
                                        type="text"
                                        register={register("bNumber")}
                                        parentClassName='w-2/4'
                                    // className={`${errors.email ? "border-Darkred" : ""}`}
                                    // error={errors.email?.message as string}
                                    />
                                    <Input
                                        label="Location"
                                        placeholder="Location 01"
                                        type="text"
                                        register={register("bLocation")}
                                        parentClassName='w-2/4'
                                    // className={`${errors.email ? "border-Darkred" : ""}`}
                                    // error={errors.email?.message as string}
                                    />
                                </div>
                            </div>
                            <div>
                                {createHeader("Lead Details")}
                                <div className='flex w-full justify-between items-center gap-2'>
                                    <Controller
                                        name="stagesHire"
                                        control={control}
                                        render={({ field }) => {
                                            return (
                                                <Select
                                                    label="Stages Hire"
                                                    options={options.filter((data) => data.value !== field.value)}
                                                    register={register("stagesHire")}
                                                    border="sm"
                                                    value={options.find((opt) => opt.value === field.value)}
                                                    onChange={(obj) => {
                                                        // setError("builder", { message: "" });
                                                        // setValue("stagesHire", obj.value);
                                                        field.onChange(obj.value)
                                                    }}
                                                    parentClassName='w-2/4'
                                                    // error={errors.builder?.message as string}
                                                />
                                            )
                                        }}
                                    />
                                    <Controller
                                        name="hirePeriod"
                                        control={control}
                                        render={({ field }) => {
                                            return (
                                                <Select
                                                    label="Hire Period"
                                                    options={options.filter((data) => data.value !== field.value)}
                                                    register={register("hirePeriod")}
                                                    border="sm"
                                                    value={options.find((opt) => opt.value === field.value)}
                                                    onChange={(obj) => {
                                                        // setError("builder", { message: "" });
                                                        // setValue("stagesHire", obj.value);
                                                        field.onChange(obj.value)
                                                    }}
                                                    parentClassName='w-2/4'
                                                    // error={errors.builder?.message as string}
                                                />
                                            )
                                        }}
                                    />
                                </div>
                                <div className='flex w-full justify-between items-center gap-2'>
                                    <Controller
                                        name="hStartDate"
                                        control={control}
                                        render={({ field }) => (
                                            <DateInput
                                                key={"hStartDate"}
                                                className={"w-full border-2 h-46"}
                                                getValueCountry={new Date(field.value)}
                                                onChange={(date: any) => {
                                                    field.onChange(date);
                                                }}
                                                label={"Hire Start date"}
                                            />
                                        )}
                                    />
                                    <Controller
                                        name="hEndDate"
                                        control={control}
                                        render={({ field }) => (
                                            <DateInput
                                                key={'hEndDate'}
                                                className={"w-full border-2 h-46"}
                                                // selected={getValues("hEndDate")}
                                                getValueCountry={new Date(field.value)}
                                                label={'Hire End Date'}
                                                onChange={(date: any) => {
                                                    // console.log("end", date)
                                                    field.onChange(date);
                                                }}
                                            />
                                        )}
                                    />
                                </div>
                                <div className='flex w-full justify-between items-center gap-2'>
                                    <div className='flex'>
                                        <Input
                                            label="Day After There after"
                                            placeholder="60 USD"
                                            type="text"
                                            register={register("dayAfterThereAfter")}
                                            parentClassName='w-255'
                                            className={'h-46'}
                                        // className={`${errors.email ? "border-Darkred" : ""}`}
                                        // error={errors.email?.message as string}
                                        />
                                        <Input
                                            label="Contract Price"
                                            placeholder="1000 USD"
                                            type="text"
                                            register={register("contractPrice")}
                                            parentClassName='w-255'
                                            className={'h-46'}
                                        // className={`${errors.email ? "border-Darkred" : ""}`}
                                        // error={errors.email?.message as string}
                                        />
                                    </div>
                                    <Controller
                                        name="inspectionDate"
                                        control={control}
                                        render={({ field }) => (
                                            <DateInput
                                                className={"w-full border-2 h-46"}
                                                key={'hEndDate'}
                                                // selected={getValues("hEndDate")}
                                                getValueCountry={new Date(field.value)}
                                                label={'Inspection Date'}
                                                onChange={(date: any) => {
                                                    field.onChange(date);
                                                }}
                                            />
                                        )}
                                    />
                                </div>
                            </div>
                            <div>
                                {createHeader("Sub Contractors Allowances")}
                                <div className='flex w-full justify-between items-center gap-2'>
                                    <Input
                                        label="Erect Price"
                                        placeholder="60 USD"
                                        type="text"
                                        register={register("erectPrice")}
                                        parentClassName='w-2/4'
                                        className={'h-46'}
                                    // className={`${errors.email ? "border-Darkred" : ""}`}
                                    // error={errors.email?.message as string}
                                    />
                                    <Input
                                        label="Dismantle Price"
                                        placeholder="60 USD"
                                        type="text"
                                        register={register("dismantlePrice")}
                                        parentClassName='w-2/4'
                                        className={'h-46'}
                                    // className={`${errors.email ? "border-Darkred" : ""}`}
                                    // error={errors.email?.message as string}
                                    />
                                    <Input
                                        label="Alteration Price"
                                        placeholder="1000 USD"
                                        type="text"
                                        register={register("alterationPrice")}
                                        parentClassName='w-2/4'
                                        className={'h-46'}
                                    // className={`${errors.email ? "border-Darkred" : ""}`}
                                    // error={errors.email?.message as string}
                                    />
                                </div>
                                <div className='flex w-full justify-between items-center gap-2'>
                                    <Input
                                        label="Lyta Price"
                                        placeholder="1000 USD"
                                        type="text"
                                        register={register("lytaPrice")}
                                        parentClassName='w-2/4'
                                        className={'h-46'}
                                    // className={`${errors.email ? "border-Darkred" : ""}`}
                                    // error={errors.email?.message as string}
                                    />
                                    <Input
                                        label="Travel Prices"
                                        placeholder="1000 USD"
                                        type="text"
                                        register={register("travelPrices")}
                                        parentClassName='w-2/4'
                                        className={'h-46'}
                                    // className={`${errors.email ? "border-Darkred" : ""}`}
                                    // error={errors.email?.message as string}
                                    />
                                    <Input
                                        label="Total Price"
                                        placeholder="1000 USD"
                                        type="text"
                                        register={register("totalPrice")}
                                        parentClassName='w-2/4'
                                        className={'h-46'}
                                    // className={`${errors.email ? "border-Darkred" : ""}`}
                                    // error={errors.email?.message as string}
                                    />
                                </div>
                            </div>
                            <div>
                                {createHeader("Transport")}
                                <div className='flex w-full justify-between items-center gap-2'>
                                    <Controller
                                        name="totalAllowances"
                                        control={control}
                                        render={({ field }) => {
                                            return (
                                                <Select
                                                    label="Total Allowances"
                                                    options={options.filter((data) => data.value !== field.value)}
                                                    register={register("totalAllowances")}
                                                    border="sm"
                                                    value={options.find((opt) => opt.value === field.value)}
                                                    onChange={(obj) => {
                                                        // setError("builder", { message: "" });
                                                        // setValue("stagesHire", obj.value);
                                                        field.onChange(obj.value)
                                                    }}
                                                    parentClassName='w-2/4'
                                                    // error={errors.builder?.message as string}
                                                />
                                            )
                                        }}
                                    />
                                    <Controller
                                        name="costAfterAllowances"
                                        control={control}
                                        render={({ field }) => {
                                            return (
                                                <Select
                                                    label="Cost After Allowances"
                                                    options={options.filter((data) => data.value !== field.value)}
                                                    register={register("costAfterAllowances")}
                                                    border="sm"
                                                    value={options.find((opt) => opt.value === field.value)}
                                                    onChange={(obj) => {
                                                        // setError("builder", { message: "" });
                                                        // setValue("stagesHire", obj.value);
                                                        field.onChange(obj.value)
                                                    }}
                                                    parentClassName='w-2/4'
                                                    // error={errors.builder?.message as string}
                                                />
                                            )
                                        }}
                                    />

                                </div>
                            </div>
                            <div>
                                {createHeader("Assignee to")}
                                <div className='flex w-full justify-between items-center gap-2'>
                                    <Controller
                                        name="selectStaffForInspection"
                                        control={control}
                                        render={({ field }) => {
                                            return (
                                                <Select
                                                    label="Select staff for inspection"
                                                    options={options.filter((data) => data.value !== field.value)}
                                                    register={register("selectStaffForInspection")}
                                                    border="sm"
                                                    value={options.find((opt) => opt.value === field.value)}
                                                    onChange={(obj) => {
                                                        // setError("builder", { message: "" });
                                                        // setValue("stagesHire", obj.value);
                                                        field.onChange(obj.value)
                                                    }}
                                                    parentClassName='w-2/4'
                                                    error={errors.selectStaffForInspection?.message as string}
                                                />
                                            )
                                        }}
                                    />
                                    <Controller
                                        name="assigneeWorker"
                                        control={control}
                                        render={({ field }) => {
                                            return (
                                                <Select
                                                    label="Assignee Worker"
                                                    options={options.filter((data) => data.value !== field.value)}
                                                    register={register("assigneeWorker")}
                                                    border="sm"
                                                    value={options.find((opt) => opt.value === field.value)}
                                                    onChange={(obj) => {
                                                        // setError("builder", { message: "" });
                                                        // setValue("stagesHire", obj.value);
                                                        field.onChange(obj.value)
                                                    }}
                                                    parentClassName='w-2/4'
                                                    error={errors.assigneeWorker?.message as string}
                                                />
                                            )
                                        }}
                                    />
                                </div>
                            </div>
                        </div>
                        <div className='flex'>
                            <Button
                                title={"Cancel"}
                            />
                            <Button
                                type='submit'
                                title={"save"}
                            />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default CreateJobs