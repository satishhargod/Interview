import React, { useMemo } from "react";
import { AiTwotoneEye } from "react-icons/ai";
import { PiPencilSimpleDuotone, PiTrashDuotone } from "react-icons/pi";
import Switch from "components/common/formInput/Switch";
import { useNavigate } from "react-router-dom";
interface ICompanyColumn {
    setIsEditOpen: React.Dispatch<React.SetStateAction<boolean>>
    setIsDeleteOpen: React.Dispatch<React.SetStateAction<boolean>>
    setIsViewOpen: React.Dispatch<React.SetStateAction<boolean>>
    setSelectedViewSite: React.Dispatch<React.SetStateAction<any>>;
    setModalTitle: React.Dispatch<React.SetStateAction<string>>
    setIsModalOpen: any;
    totalCount: number;
    setIsModalOpenData: any;
    page: number;
}

const ViewSiteColumns = (props: ICompanyColumn) => {
    const navigate = useNavigate()
    const { setIsDeleteOpen, setIsEditOpen, setIsViewOpen, setModalTitle, setSelectedViewSite, totalCount, page, setIsModalOpen, setIsModalOpenData } = props

    const tempColumn = [
        {
            header: "Job ID",
            cell: ({ row }: { row: { original: any, index: number } }) => {
                return <div>{row.original.jobId}</div>;
            },
        },
        {
            header: "Site Address",
            cell: ({ row }: { row: { original: any } }) => {
                return <React.Fragment>
                    {row.original.siteAddress} </React.Fragment>;
            },
        },
        {
            header: "Stages of Erec",
            cell: ({ row }: { row: { original: any } }) => {
                return <React.Fragment key={row.original.stagesOfErec}> {row.original.stagesOfErec} </React.Fragment>;
            },
        },
        {
            header: "Hire Period",
            cell: ({ row }: { row: { original: any } }) => {
                return <React.Fragment key={row.original.hirePeriod}> {row.original.hirePeriod} </React.Fragment>;
            },
        },
        {
            header: "Created Date",
            cell: ({ row }: { row: { original: any } }) => {
                return <React.Fragment key={row.original.createdDate}> {row.original.createdDate} </React.Fragment>;
            },
        },
        {
            header: "Created By",
            cell: ({ row }: { row: { original: any } }) => {
                return <React.Fragment key={row.original.createdBy}> {row.original.createdBy} </React.Fragment>;
            },
        },
        {
            header: "Contract Price",
            cell: ({ row }: { row: { original: any } }) => {
                return <React.Fragment key={row.original.contractPrice}> {row.original.contractPrice} </React.Fragment>;
            },
        },
        {
            header: 'Status',
            accessorKey: "Status",
            enableSorting: true,
            cell: ({ row }: { row: { original: any } }) => {
                return (
                    <div>
                        <Switch
                            size="md"
                            isSwitch={row.original.status}
                            onClick={(e: any) => {
                                e.preventDefault();
                                setIsModalOpenData({ value: true, data: !row.original.status, id: row.original.companyDetails?._id, name: row.original.name, email: row.original.email });
                                setIsModalOpen(true)
                            }}
                        />
                    </div>
                );
            },
        },
        {
            header: "Action",
            cell: ({ row }: { row: { original: any } }) => {
                
                return (
                    <div className="flex gap-4">
                        <div className="group relative">
                            <AiTwotoneEye
                                className="text-gray-600 w-6 h-6 cursor-pointer transition duration-300 ease-in-out transform"
                                onClick={() => {
                                    setModalTitle("Company Details");
                                    setSelectedViewSite(row.original);
                                    setIsViewOpen(true);
                                }}
                            />
                            <div className="absolute left-1/2 z-10 transform -translate-x-1/2 bottom-full invisible group-hover:visible group-hover:opacity-100 bg-gray-800 text-white text-xs px-2 py-1 rounded transition-opacity">
                                View
                            </div>
                        </div>

                        <div className="group relative">
                            <PiPencilSimpleDuotone
                                className="text-gray-600 w-6 h-6 cursor-pointer transition duration-300 ease-in-out transform"
                                onClick={() => {
                                    setModalTitle("Edit Company");
                                    navigate(`/jobs/edit/${row.original.jobId}`)
                                }}
                            />
                            <div className="absolute left-1/2 z-10 transform -translate-x-1/2 bottom-full invisible group-hover:visible group-hover:opacity-100 bg-gray-800 text-white text-xs px-2 py-1 rounded transition-opacity">
                                Edit
                            </div>
                        </div>

                        <div className="group relative">
                            <PiTrashDuotone
                                className="text-red-500 w-6 h-6 cursor-pointer transition duration-300 ease-in-out transform"
                                onClick={() => {
                                    setSelectedViewSite(row.original);
                                    setIsDeleteOpen(true);
                                }}
                            />
                            <div className="absolute left-1/2 z-10 transform -translate-x-1/2 bottom-full invisible group-hover:visible group-hover:opacity-100 bg-gray-800 text-white text-xs px-2 py-1 rounded transition-opacity">
                                Delete
                            </div>
                        </div>
                    </div>
                );
            },
        },
    ];

    const columns = useMemo(() => tempColumn, [page, totalCount]);
    return { columns };
};

export default ViewSiteColumns;
