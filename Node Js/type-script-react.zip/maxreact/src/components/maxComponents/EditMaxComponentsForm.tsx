import React, { useEffect, useState } from "react";
import Dialog from "../common/Dialog";
import Input from "../common/formInput/Input";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import Button from "../common/button/Button";
import Loader from "components/common/Loader";
import { IMaxComponentsData } from "types/maxCompoents/maxcomponents";
import { maxComponentsFormSchema } from "validation/maxComponents/maxComponentsValidation";
import {
  addMaxComponent,
  getMaxComponentDetails,
  updateMaxComponent,
} from "services/maxComponents";
import { RESPONSE_STATUS } from "helper/common/constant";
import { toastShow } from "redux/ducks/toast";
import { dispatchToast } from "helper/common/function";

interface IEditMaxComponentsForm {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  submitBtnTitle?: string;
  closeButton?: boolean;
  selectedComponentId: string | null;
  setIsEditOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setPage: React.Dispatch<React.SetStateAction<number>>;
  pageSize?: number;
  fetchMaxComponentsData: (filter: object) => Promise<void>;
}

const EditMaxComponents = (props: IEditMaxComponentsForm) => {
  const {
    isOpen,
    title,
    onClose,
    submitBtnTitle = "Submit",
    closeButton = true,
    selectedComponentId,
    setIsEditOpen,
    setPage,
    fetchMaxComponentsData,
    pageSize
  } = props;

  const initialValue = {
    code: "",
    description: "",
    inventoryQty: "",
  };

  const {
    register,
    handleSubmit,
    setValue,
    setError,
    formState: { errors, isSubmitting },
  } = useForm({
    defaultValues: initialValue,
    resolver: yupResolver(maxComponentsFormSchema),
  });

  const [isDataLoading, setisDataLoading] = useState(false);

  const getSingleComponentDetails = async () => {
    try {
      if (selectedComponentId) {
        setisDataLoading(true);
        const getDetailsRes = await getMaxComponentDetails(selectedComponentId);
        if (getDetailsRes.data.data) {
          setValue("code", getDetailsRes.data.data.code);
          setValue("description", getDetailsRes.data.data.description);
          setValue("inventoryQty", getDetailsRes.data.data.inventoryQty);
        }
        setisDataLoading(false);
      }
    } catch (error) {
      setisDataLoading(false);
    }
  };

  const onSubmit = async (value: IMaxComponentsData) => {
    const params = {
      code: value.code,
      description: value.description,
      inventoryQty: value.inventoryQty,
    };
    try {
      let apiResponse;
      if (selectedComponentId) {
        apiResponse = await updateMaxComponent({
          ...params,
          id: selectedComponentId,
        });
      } else {
        apiResponse = await addMaxComponent(params);
      }

      if (apiResponse.data.toast) {
        dispatchToast(apiResponse.data.message, apiResponse.data.responseType);
      } else {
        setError("code", { message: apiResponse.data.message });
      }

      if (apiResponse.data.responseType === RESPONSE_STATUS.success) {
        setIsEditOpen(false);
        setPage(1);
        await fetchMaxComponentsData({
          page: 1,
          limit: pageSize,
        });
      }
    } catch (error) {}
  };

  useEffect(() => {
    selectedComponentId && getSingleComponentDetails();
  }, [selectedComponentId]);

  return (
    <div>
      <Dialog onClose={onClose} isOpen={isOpen} title={title}>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className={`${isDataLoading ? "h-406px rounded-14" : "h-full"}`}
        >
          {isDataLoading ? (
            <Loader className={"rounded-14"} />
          ) : (
            <div className="flex gap-6 flex-col">
              <div className="flex gap-5">
                <Input
                  label="Code"
                  placeholder="Enter Code"
                  register={register("code")}
                  error={errors["code"]?.message as string}
                  className="!px-15 !py-2.5"
                />
                <Input
                  label="Inventory Qty"
                  placeholder="Enter Quantity"
                  register={register("inventoryQty")}
                  error={errors["inventoryQty"]?.message as string}
                  className="!px-15 !py-2.5 !pr-8"
                />
              </div>
              <Input
                label="Description"
                placeholder="Enter Description"
                register={register("description")}
                error={errors["description"]?.message as string}
                className="!px-15 !py-2.5 !pr-8"
              />
              <div className="flex items-center justify-end gap-2.5">
                {closeButton && (
                  <Button
                    type="button"
                    title={"Close"}
                    onClick={onClose}
                    className={
                      "!bg-BrandBlack/10 border !text-black !w-auto px-6"
                    }
                  />
                )}
                <Button
                  type="submit"
                  variant="filled"
                  isLoading={isSubmitting}
                  className={"!w-auto px-6"}
                  title={submitBtnTitle}
                />
              </div>
            </div>
          )}
        </form>
      </Dialog>
    </div>
  );
};

export default EditMaxComponents;
