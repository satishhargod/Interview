// import { truncateString } from "helper/common/function";
import { IMaxComponentsData } from "types/maxCompoents/maxcomponents";
import Button from "components/common/button/Button";
import React, { useMemo } from "react";
import { AiTwotoneEye } from "react-icons/ai";
import { PiPencilSimpleDuotone, PiTrashDuotone } from "react-icons/pi";
import { RoleEnum } from "types/common/common";

interface IMaxComponentsColumn {
  setIsEditOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setIsDeleteOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setIsViewOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setSelectedComponentId: React.Dispatch<React.SetStateAction<string | null>>;
  setModalTitle: React.Dispatch<React.SetStateAction<string>>;
  totalCount: number;
  page: number;
  roles: string[];
}

const MaxComponentsColumn = (props: IMaxComponentsColumn) => {
  const {
    setIsDeleteOpen,
    setIsEditOpen,
    setIsViewOpen,
    setModalTitle,
    setSelectedComponentId,
    totalCount,
    page,
    roles,
  } = props;

  const calculateSerialNumber = (rowIndex: number) => {
    return (page - 1) * 10 + rowIndex + 1;
  };

  const tempColumn = [
    {
      header: "Sr No",
      cell: ({
        row,
      }: {
        row: { original: IMaxComponentsData; index: number };
      }) => {
        return <div>{calculateSerialNumber(row.index)}</div>;
      },
    },
    {
      header: "Code",
      accessorKey: "code",
      enableSorting: true,
      cell: ({ row }: { row: { original: IMaxComponentsData } }) => {
        return <React.Fragment> {row.original.code} </React.Fragment>;
      },
    },
    {
      header: "Description",
      accessorKey: "description",
      enableSorting: true,
      cell: ({ row }: { row: { original: IMaxComponentsData } }) => {
        return <React.Fragment> {row.original.description} </React.Fragment>;
      },
    },
    {
      header: "Inventory Qty",
      accessorKey: "inventoryQty",
      enableSorting: true,
      cell: ({ row }: { row: { original: IMaxComponentsData } }) => {
        return <React.Fragment> {row.original.inventoryQty} </React.Fragment>;
      },
    },
  ];

  const actions = [
    {
      header: "Action",
      cell: ({ row }: { row: { original: IMaxComponentsData } }) => {
        return (
          <div className="flex gap-4">
            <div className="group relative">
              <PiPencilSimpleDuotone
                className="text-gray-600 w-6 h-6 cursor-pointer transition duration-300 ease-in-out transform"
                onClick={() => {
                  setSelectedComponentId(row.original._id as string);
                  setModalTitle("Edit Max-Component");
                  setIsEditOpen(true);
                }}
              />
              <div className="absolute left-1/2 z-10 transform -translate-x-1/2 bottom-full invisible group-hover:visible group-hover:opacity-100 bg-gray-800 text-white text-xs px-2 py-1 rounded transition-opacity">
                Edit
              </div>
            </div>

            <div className="group relative">
              <PiTrashDuotone
                className="text-gray-600 w-6 h-6 cursor-pointer transition duration-300 ease-in-out transform"
                onClick={() => {
                  setSelectedComponentId(row.original._id as string);
                  setIsDeleteOpen(true);
                }}
              />
              <div className="absolute left-1/2 z-10 transform -translate-x-1/2 bottom-full invisible group-hover:visible group-hover:opacity-100 bg-gray-800 text-white text-xs px-2 py-1 rounded transition-opacity">
                Delete
              </div>
            </div>
          </div>
        );
      },
    },
  ];

  const columns = useMemo(
    () =>
      roles.includes(RoleEnum.Admin) ? [...tempColumn, ...actions] : tempColumn,
    [page, totalCount]
  );
  return { columns };
};

export default MaxComponentsColumn;
