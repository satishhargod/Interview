import { DetailDataType } from "types/dashboard/dashboard";
import Button from "components/common/button/Button";
import { DetailData } from "utils/ApiConstants";

const ContentData = () => {
    
    return (
      <>
        <div className="flex items-center justify-between mb-5">
          <div className="relative">
            <h5 className="text-BrandBlack text-lg font-bold leading-150%">
              Recently created jobs
            </h5>
          </div>
          <div>
            <Button className={"!px-5"} title={"View More"} />
          </div>
        </div>
        <div className="grid grid-cols-4 gap-4">
          {DetailData.map((tile: DetailDataType, index: number) => (
            <div
              className="card-top-common bg-white p-4 flex flex-col rounded-10"
              key={`tile_${index + 1}`}
            >
              <p className="line-clamp-1 text-grayText text-lg 2xl:text-xl leading-6">
                {tile.image}
              </p>
              <div className="flex gap-4 items-center mt-9">
                <div className={`rounded-lg w-20 h-20 flex`}>
                  <div>{tile.title}</div>
                  <div className="flex px-5">
                    <div>view</div>
                    <div>edit</div>
                    <div>delete</div>
                  </div>
                </div>
              </div>
              <span className="text-dark cursor-default ">{tile.email}</span>
              <span className="text-dark cursor-default ">{tile.call}</span>
              <span className="text-dark cursor-default ">{tile.address}</span>
              <span className="text-dark cursor-default ">{tile.start}</span>
              <span className="text-dark cursor-default ">{tile.end}</span>
            </div>
          ))}
        </div>
      </>
    );
}

export default ContentData;