import {
  MaxComponentsIcon,
  TotalCompany,
  TotalJobs,
  TotalStaff,
  TotalWorkers,
} from "icons";
import { PiHammerDuotone } from "react-icons/pi";
import { useNavigate } from "react-router-dom";
import { AbstractDataType } from "types/dashboard/dashboard";




const OverviewData = () => {

  const navigate = useNavigate()
  const abstractData: AbstractDataType[] = [
    {
      icon: <TotalStaff />,
      counts: "08",
      title: "Total Staff",
    },
    {
      icon: <TotalWorkers />,
      counts: "3012",
      title: "Total Workers",
    },
    {
      icon: <TotalCompany />,
      counts: "30",
      title: "Total Companies",
      onClick:()=> navigate("/company")
      
    },
    {
      icon: <TotalJobs />,
      counts: "25",
      title: "Total Jobs",
      onClick:()=> navigate("/jobs")
    },
    {
      icon: <PiHammerDuotone className="h-8 w-8"/>,
      counts: "11",
      title: "Total Builders",
      onClick:()=> navigate("/builder")

    },
    {
      icon: <MaxComponentsIcon />,
      counts: "40",
      title: "Total Max-Components",
      onClick:()=> navigate("/max-components")
    },
  ];

  return (
    <div className="grid grid-cols-6 gap-4 mb-6">
      {abstractData.map((tile: AbstractDataType, index: number) => (
        <div
          className="card-top-common bg-white p-4 border border-solid border-loginBorder flex flex-col rounded-xl"
          key={`tile_${index + 1}`}
          onClick={tile.onClick}
        >
          <div className="relative inline-block">
            <span className="rounded-lg p-2.5 bg-BrandBlack/5 inline-block">
              {tile.icon}
            </span>
          </div>
          <div className="flex gap-2.5 flex-col mt-5">
            <div className={`text-gray-600 text-21 font-medium leading-150% `}>
              {tile.title}
            </div>
            <span className=" text-34 text-BrandBlack font-bold leading-normal ">
              {tile.counts}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
};

export default OverviewData;
