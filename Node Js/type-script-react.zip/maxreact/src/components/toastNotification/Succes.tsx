import { AiFillCheckCircle } from 'react-icons/ai';

const Success = () => {
  return (
    <div className='relative h-9 w-9 min-w-[36px] flex items-center justify-center bg-[#67BD6D] text-white text-xl rounded-md' >
      <AiFillCheckCircle />
    </div>
  );
};

export default Success;