import React, { useEffect, useState } from "react";
import Dialog from "../common/Dialog";
import Input from "../common/formInput/Input";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { companyFormSchema } from "validation/company/companyValidation";
import Button from "../common/button/Button";
import Select from "../common/formInput/Select";
import { ICompanyData } from "@/types/company/company";
import { getCompanyDataById } from "services/company";
import Loader from "components/common/Loader";
import { FaCircle } from "react-icons/fa";

interface IEditCompanyForm {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  fieldValue: ICompanyData;
  submitBtnTitle?: string;
  closeButton?: boolean;
  isLoading: boolean;
  onSubmit: (values: ICompanyData) => void;
}



const EditCompanyForm = (props: IEditCompanyForm) => {
  const {
    isOpen,
    title,
    isLoading,
    onClose,
    fieldValue,
    submitBtnTitle = "Submit",
    closeButton = true,
    onSubmit,
  } = props;
  const [innerLoader, setInnerLoader] = useState(true);

  const {
    register,
    handleSubmit,
    setValue,
    setError,
    formState: { errors },
  } = useForm({
    defaultValues: fieldValue,
    resolver: yupResolver(companyFormSchema),
  });

  const fetchCompanyData = async () => {
    setInnerLoader(true);
    if (fieldValue.companyDetails) {
      const companyResponse = await getCompanyDataById(
        fieldValue.companyDetails._id
      );
      Object.keys(companyResponse.data.data.userDetails).forEach((key) => {
        setValue(key, companyResponse.data.data.userDetails[key]);
      });
    } else {
      console.log("Company details are undefined");
    }
    setInnerLoader(false);
  };

  useEffect(() => {
    fetchCompanyData();
  }, [isOpen]);

  const option = [
    {
      value: true,
      label: "Active",
      icon: <FaCircle className="text-green-500" />,
    },
    {
      value: false,
      label: "Inactive",
      selected: false,
      icon: <FaCircle className="text-red-500" />,
    },
  ];

  return (
    <div>
      <Dialog onClose={onClose} isOpen={isOpen} title={title}>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className={`${innerLoader ? "h-406px rounded-14" : "h-full"}`}
        >
          {innerLoader ? (
            <Loader className={"rounded-14"} />
          ) : (
            <div className="flex gap-6 flex-col">
              <Input
                label="Company Name"
                placeholder="Enter Company Name"
                register={register("name")}
                error={errors["name"]?.message as string}
                className="!px-15 !py-2.5"
              />
              <Input
                label="Email Address"
                placeholder="Enter Company Email"
                register={register("email")}
                error={errors["email"]?.message as string}
                className="!px-15 !py-2.5 !pr-8"
              />
              <Select
                label="Status"
                options={option}
                register={register("status")}
                border="sm"
                defaultValue={option.filter(
                  (opt) => opt.value === fieldValue.status
                )}
                error={errors["status"]?.message as string}
                onChange={(obj) => {
                  setError("status", { message: "" });
                  setValue("status", Boolean(obj.value));
                }}
              />
              <div className="flex items-center justify-end gap-2.5">
                {closeButton && (
                  <Button
                    type="button"
                    title={"Close"}
                    onClick={onClose}
                    className={
                      "!bg-BrandBlack/10 border !text-black !w-auto px-6"
                    }
                  />
                )}
                <Button
                  type="submit"
                  variant="filled"
                  isLoading={isLoading}
                  className={"!w-auto px-6"}
                  title={submitBtnTitle}
                />
              </div>
            </div>
          )}
        </form>
      </Dialog>
    </div>
  );
};

export default EditCompanyForm;
