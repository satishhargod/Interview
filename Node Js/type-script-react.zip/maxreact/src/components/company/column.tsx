import React, { useMemo, useState } from "react";
import { AiTwotoneEye } from "react-icons/ai";
import { PiPencilSimpleDuotone, PiTrashDuotone } from "react-icons/pi";
import { ICompanyData } from "types/company/company";
import Switch from "components/common/formInput/Switch";
interface ICompanyColumn {
  setIsEditOpen: React.Dispatch<React.SetStateAction<boolean>>
  setIsDeleteOpen: React.Dispatch<React.SetStateAction<boolean>>
  setIsViewOpen: React.Dispatch<React.SetStateAction<boolean>>
  setSelectedCompany: React.Dispatch<React.SetStateAction<ICompanyData | null>>;
  setModalTitle: React.Dispatch<React.SetStateAction<string>>
  setIsStatusChangeOpen:React.Dispatch<React.SetStateAction<boolean>>;
  totalCount: number;
  page: number;
}

const CompanyColumn = (props: ICompanyColumn) => {

  const { setIsDeleteOpen, setIsEditOpen, setIsViewOpen,setIsStatusChangeOpen, setModalTitle,setSelectedCompany, totalCount, page } = props

  const calculateSerialNumber = (rowIndex: number) => {
    return (page - 1) * 10 + rowIndex + 1;
  };

  const tempColumn = [
    {
      header: "Sr No",
      cell: ({ row }: { row: { original: ICompanyData, index: number } }) => {
        return <div>{calculateSerialNumber(row.index)}</div>;
      },
    },
    {
      header: "Company Name",
      accessorKey: "name",
      enableSorting: true,
      cell: ({ row }: { row: { original: ICompanyData } }) => {
        return <React.Fragment> <div className="relative w-10 h-10 rounded-full flex items-center gap-2">
          <img
            src={row.original.avatar !== null ? row.original.avatarUrl : "/assets/images/default.png"}
            alt=""
            height={40}
            width={40}
            className="rounded-full object-cover object-center h-full w-full"
          />
          {row.original.name}</div> </React.Fragment>;
      },
    },
    {
      header: "Email Address",
      accessorKey: "email",
      enableSorting: true,
      cell: ({ row }: { row: { original: ICompanyData } }) => {
        return <React.Fragment key={row.original.email}> {row.original.email} </React.Fragment>;
      },
    },
    {
      header: 'Status',
      accessorKey: "status",
      enableSorting: true,
      cell: ({ row }: { row: { original: ICompanyData } }) => {
        return (
          <div>
            <Switch
              size="md"
              checked={row.original.status}
              onChange={() => {
                setIsStatusChangeOpen(true)
                setSelectedCompany(row.original);
              }}
            />
          </div>
        );
      },
    },
    {
      header: "Action",
      cell: ({ row }: { row: { original: ICompanyData } }) => {
        return (
          <div className="flex gap-4">
            <div className="group relative">
              <AiTwotoneEye
                className="text-gray-600 w-6 h-6 cursor-pointer transition duration-300 ease-in-out transform"
                onClick={() => {
                  setModalTitle("Company Details");
                  setSelectedCompany(row.original);
                  setIsViewOpen(true);
                }}
              />
              <div className="absolute left-1/2 z-10 transform -translate-x-1/2 bottom-full invisible group-hover:visible group-hover:opacity-100 bg-gray-800 text-white text-xs px-2 py-1 rounded transition-opacity">
                View
              </div>
            </div>

            <div className="group relative">
              <PiPencilSimpleDuotone
                className="text-gray-600 w-6 h-6 cursor-pointer transition duration-300 ease-in-out transform"
                onClick={() => {
                  setModalTitle("Edit Company");
                  setSelectedCompany(row.original);
                  setIsEditOpen(true);
                }}
              />
              <div className="absolute left-1/2 z-10 transform -translate-x-1/2 bottom-full invisible group-hover:visible group-hover:opacity-100 bg-gray-800 text-white text-xs px-2 py-1 rounded transition-opacity">
                Edit
              </div>
            </div>

            <div className="group relative">
              <PiTrashDuotone
                className="text-red-500 w-6 h-6 cursor-pointer transition duration-300 ease-in-out transform"
                onClick={() => {
                  setSelectedCompany(row.original);
                  setIsDeleteOpen(true);
                }}
              />
              <div className="absolute left-1/2 z-10 transform -translate-x-1/2 bottom-full invisible group-hover:visible group-hover:opacity-100 bg-gray-800 text-white text-xs px-2 py-1 rounded transition-opacity">
                Delete
              </div>
            </div>
          </div>
        );
      },
    },
  ];

  const columns = useMemo(() => tempColumn, [page, totalCount]);
  return { columns };
};

export default CompanyColumn;
