import React, { useEffect, useState } from "react";
import Dialog from "../common/Dialog";
import Button from "../common/button/Button";
import { companyDateFormat, truncateString } from "helper/common/function";
import { ICompanyData } from "@/types/company/company";
import Select from "../common/formInput/Select";
import { useForm } from "react-hook-form";
import { getCompanyDataById } from "services/company";
import Loader from "components/common/Loader";
import { FaCircle } from "react-icons/fa6";

interface IViewCompany {
  onClose: () => void;
  title?: string;
  data: ICompanyData;
  isOpen: boolean;
  isLoading: boolean;
  onSubmit: (values: ICompanyData) => void;
}

const ViewCompany = (props: IViewCompany) => {
  const { onClose, title, data, isOpen, onSubmit, isLoading } = props;
  const [companyDetails, setCompanyDetails] = useState<ICompanyData>();
  const {
    register,
    handleSubmit,
    setValue,
  } = useForm({
    defaultValues: data,
  });

  const fetchCompanyData = async () => {
    if (data.companyDetails) {
      const companyResponse = await getCompanyDataById(data.companyDetails?._id);
      setValue("status", companyResponse.data.data["status"]);
      setCompanyDetails(companyResponse.data.data.userDetails);
    } else {
      console.log('Company details are undefined');
    }
  }

  useEffect(() => {
    fetchCompanyData()
  }, [])

  const option = [
    {
      value: true,
      label: "Active",
      selected: false,
      icon: <FaCircle className="text-green-500" />,
    },
    {
      value: false,
      label: "Inactive",
      selected: false,
      icon: <FaCircle className="text-red-500" />,
    },
  ];

  return (
    <div>
      <Dialog onClose={onClose} title={title} isOpen={isOpen} className={`${companyDetails === undefined ? "h-406px rounded-14" : "h-full"}`}>
        {companyDetails !== undefined ? (<div className="flex flex-col">
          <div className="flex items-center justify-between w-full">
            <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
              Company Logo :
            </span>
            <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
              <div className="relative w-10 h-10 rounded-full">
                <img
                  src={
                    companyDetails.avatar !== null
                      ? companyDetails.avatarUrl
                      : "/assets/images/default.png"
                  }
                  alt=""
                  height={50}
                  width={50}
                  className="rounded-full object-cover object-center h-full w-full"
                />
              </div>
            </span>
          </div>
          <div className="flex items-center justify-between w-full">
            <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
              Company Name :
            </span>
            <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
              {companyDetails.name}
            </span>
          </div>
          <div className="flex items-center justify-between w-full">
            <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
              Email Address :
            </span>
            <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
              {companyDetails.email}
            </span>
          </div>
          <div className="flex items-center justify-between w-full">
            <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
              Phone Number :
            </span>
            <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
              {companyDetails.phone || "+0 123 456 789"}
            </span>
          </div>
          <div className="flex items-center justify-between w-full">
            <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
              Created At :
            </span>
            <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
              {companyDateFormat(companyDetails.createdAt) || "No Date Available"}
            </span>
          </div>
          <div className="flex items-center justify-between w-full">
            <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4">
              Account Type:
            </span>
            <span className="text-gray-600 text-base font-normal leading-12 w-2/4">
              {companyDetails.type || "Company"}
            </span>
          </div>
          <div className="flex items-start justify-between w-full">
            <span className="text-BrandBlack text-base font-normal leading-12 capitalize w-2/4 block">
              Is Active :
            </span>
            <div className="w-2/4 mt-4">
              <span className="text-gray-600 text-base font-normal leading-12">
                <form onSubmit={handleSubmit(onSubmit)}>
                  <div className="flex gap-6 flex-col">
                    <Select
                      options={option}
                      register={register("status")}
                      border="sm"
                      parentClassName="w-32"
                      defaultValue={option.filter(
                        (opt) => opt.value === companyDetails.status
                      )}
                      onChange={(obj) => {
                        setValue("status", Boolean(obj.value));
                      }}
                    />
                    <div className="flex items-center gap-2.5">
                      <Button
                        isLoading={isLoading}
                        title={"Update"}
                        type="submit"
                        variant="filled"
                        className={"!w-auto px-6"}
                      />
                    </div>
                  </div>
                </form>
              </span>
            </div>
          </div>
        </div>
        ) : <Loader />}</Dialog>
    </div>
  );
};

export default ViewCompany;
