import { validateField } from "helper/common/constant";
import * as Yup from "yup";

export const builderFormSchema: Yup.ObjectSchema<any, Yup.AnyObject, any, ""> =
  Yup.object({
    name: validateField.stringPrefixJoiValidation
      .required("Builder's Name is Required")
      .min(4, "Name Must be at least 3+ characters long"),
    email: validateField.email,
    phone: validateField.stringPrefixJoiValidation
      .required("Phone is Required")
      .min(10, "Please Enter a 10-digit Number")
      .max(10, "Please Enter a 10-digit Number")
      .matches(/^\d+$/, { message: "Please Enter Digits Only!!" }),
    countryCode: validateField.stringPrefixJoiValidation.required(
      "Country Code is Required"
    ),
    address: validateField.stringPrefixJoiValidation.required(
      "Address is Required!"
    ),
  });

export const pointOfContactsSchema: Yup.ObjectSchema<
  any,
  Yup.AnyObject,
  any,
  ""
> = Yup.object({
  poc: Yup.array().of(
    Yup.object().shape({
      name: Yup.string()
        .required("Name is Required")
        .min(4, "Name Must be at least 4 characters long"),
      email: Yup.string().email("Invalid Email").required("Email is Required"),
      phone: Yup.string()
        .required("Phone is Required")
        .min(10, "Please Enter a 10-digit Number")
        .max(10, "Please Enter a 10-digit Number")
        .matches(/^\d+$/, { message: "Please Enter Digits Only!!" }),
      countryCode: validateField.stringPrefixJoiValidation.required(
        "Country Code is Required"
      ),
    })
  ),
});
