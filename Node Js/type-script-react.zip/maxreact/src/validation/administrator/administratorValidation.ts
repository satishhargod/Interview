import { validateField } from "helper/common/constant";
import * as Yup from "yup";

const { name } = validateField;

export const userFormSchema: Yup.ObjectSchema<any, Yup.AnyObject, any, ""> =
  Yup.object({
    name: name,
    email: validateField.email,
    status:
      validateField.stringPrefixJoiValidation.required("Status is Required"),
    roleId: validateField.stringPrefixJoiValidation.required("Role is Required"),
    type: validateField.stringPrefixJoiValidation.required("Type is Required"),
  });

export const roleFormSchema: Yup.ObjectSchema<any, Yup.AnyObject, any, ""> =
  Yup.object({
    name: name,
  });