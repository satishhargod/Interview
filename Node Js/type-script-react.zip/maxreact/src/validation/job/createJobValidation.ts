
import { validateField } from "helper/common/constant";
import * as Yup from "yup";

const { email } = validateField;

export const createSchema: Yup.ObjectSchema<any, Yup.AnyObject, any, ""> =
  Yup.object({
    bEmail: email.required("Builder Email is required"),
    builder: Yup.string()
    .required("Builder is required"),
    selectStaffForInspection:Yup.string()
    .required("Select Staff For Inspection is required"),
    assigneeWorker:Yup.string()
    .required("Assignee Worker is required")
  });
