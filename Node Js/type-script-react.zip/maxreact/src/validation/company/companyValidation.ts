import { validateField } from "helper/common/constant";
import * as Yup from "yup";

export const companyFormSchema: Yup.ObjectSchema<any, Yup.AnyObject, any, ""> =
  Yup.object({
    name: validateField.stringPrefixJoiValidation
      .required("Company Name is Required")
      .min(4, "Name Must be at least 3+ characters long"),
    email: validateField.email,
    status: validateField.stringPrefixJoiValidation.required(
      "Company Status is Required"
    ),
  });
