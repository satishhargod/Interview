import { validateField } from "helper/common/constant";
import * as Yup from "yup";

export const maxComponentsFormSchema: Yup.ObjectSchema<
  any,
  Yup.AnyObject,
  any,
  ""
> = Yup.object({
  code: validateField.stringPrefixJoiValidation
    .required("Code is Required")
    .min(2, "Code Must be at least 2+ characters long"),
  description: validateField.stringPrefixJoiValidation
    .required("Description is Required")
    .min(2, "Description Must be at least 4+ characters long"),
  inventoryQty: validateField.stringPrefixJoiValidation
    .required("Inventory Quantity is Required")
    .matches(/^\d+$/, { message: "Please Enter Number Only" })
    .default("0"),   
});
