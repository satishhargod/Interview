const handleError = (errorCode) => {
    if (errorCode === 401) {
        //do things
    }
    return null;
};

export default handleError;
