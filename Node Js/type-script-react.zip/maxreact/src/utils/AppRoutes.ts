export const AppRoutes = {
    ANY: '*',
    HOME: '/home'
}