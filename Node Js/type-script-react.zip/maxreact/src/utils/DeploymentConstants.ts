export const DEPLOYMENT_MODE = {
    PROD: 'prod',
    STAGE: 'stage'
}