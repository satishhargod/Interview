import { INavOptions } from "@/types/layout";

export const NavigationOptions: Array<INavOptions> = [
  {
    title: 'Dashboard',
    value: 'dashboard',
    link: '/dashboard',
    count: 0,
    iconDetails: {
        icon: '',
        props: { className: 'w-full h-full' },
    },
    subNavigationOptions: [],
    moduleName: ['dashboard'],
    isAllow: true,
  },
  {
    title: 'Company',
    value: 'company',
    link: '/company',
    iconDetails: {
      icon: '',
      props: { className: 'w-full h-full' },
    },
    isSubNavigationOpen: false,
    subNavigationOptions: [],
    moduleName: ['company'],
    isAllow: true,
  },
  {
    title: 'Jobs',
    value: 'jobs',
    count: 0,
    link: '/jobs',
    iconDetails: {
      icon: '',
      props: { className: 'w-full h-full' },
    },
    isSubNavigationOpen: false,
    subNavigationOptions: [],
    moduleName: ['jobs'],
    isAllow: true,
  },
  {
    title: 'Schedules',
    value: 'schedules',
    link: '/schedules',
    iconDetails: {
      icon: '',
      props: { className: 'w-full h-full' },
    },
    isSubNavigationOpen: false,
    subNavigationOptions: [],
    moduleName: ['schedules'],
    isAllow: true,
  },
  {
    title: 'Reports',
    value: 'reports',
    link: '/reports',
    iconDetails: {
      icon: '',
      props: { className: 'w-full h-full' },
    },
    isSubNavigationOpen: false,
    subNavigationOptions: [],
    moduleName: ['reports'],
    isAllow: true,
  },
  {
    title: 'Transport',
    value: 'transport',
    link: '/transport',
    iconDetails: {
      icon: 'transport',
      props: { className: 'w-full h-full' },
    },
    isSubNavigationOpen: false,
    subNavigationOptions: [],           
    moduleName: ['transport'],
    isAllow: true,
  },
  {
    title: 'Administration',
    value: 'administration',
    link: '#',
    iconDetails: {
      icon: '',
      props: { className: 'w-full h-full' },
    },
    isSubNavigationOpen: false,
    moduleName: ['users', 'roles'],
    isAllow: true,
    subNavigationOptions: [
      {
        title: 'Users',
        value: 'users',
        link: '/administration/users',
        status: 'Activated',
        moduleName: ['users'],
      },
      {
        title: 'Roles',
        value: 'roles',
        link: '/administration/roles',
        status: 'Completed',
        moduleName: ['roles'],
      },
    ],
  },
];

export const userRolesCategories: { [key: string]: string[] } = {
  Staff: ['Dashboard','Company', 'Jobs', 'Schedules', 'Reports', 'Transport', 'Builder', 'Administration', 'Profile', 'Users' , "Roles"],
  Admin: ['Dashboard','Company', 'Jobs', 'Schedules', 'Reports', 'Transport', 'Builder', 'Administration', "Profile", 'Users', "Roles" ,"404","Max-Components"],
  Worker: ['Dashboard','Company', 'Jobs', 'Schedules', 'Reports', 'Transport', 'Builder', 'Administration', "Profile", 'Users',"Roles" , "Max-Components"],
  Company: ['Dashboard', 'Jobs', 'Schedules', 'Reports', 'Transport', 'Builder', 'Administration', "Profile", 'Users',"Roles"],
};

export const UserRole: { [key: string]: string } = {
  Admin : 'admin',
  Staff : 'staff',
  Company : 'company',
  Worker : 'worker'
}
