import React, { Suspense, useEffect, useState } from "react";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { ConnectedProps, connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import RouteComponent from "route/route";
import { tokensSelector } from "redux/ducks/token";
import Header from "components/layouts/Header";
import Sidebar from "components/layouts/Sidebar";
import { INavOptions } from "@/types/layout";

const Layout = (props: PropsFromRedux) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [selectedNavigationTab, setSelectedNavigationTab] =
    useState<string>("");

  // const getTabValue = (role: string, tabs: Array<INavOptions>) => {
  //   const sideBarTabs = [];
  //   const apiPermissions = Object.keys(role);
  //   for (let i = 0; i < tabs.length; i++) {
  //     const navBackEndKey = tabs[i].moduleName;
  //     const byPass =
  //       process.env.REACT_APP_PERMISSION_BYPASS === "false" ? false : true;
  //  if (isAdmin) {
  //       isAuthRequired = true;
  //     } else {
  //       for (let j = 0; j < navBackEndKey.length; j++) {
  //         if (allModuleNames.includes(navBackEndKey[j])) {
  //           isAuthRequired = true;
  //           if (apiPermissions.includes(navBackEndKey[j])) {
  //             isTabVisible = true;
  //             break;
  //           }
  //         }
  //       }
  //     }
  //   }
  // };

  useEffect(() => {
    if (!props.tokens.accessToken) {
      navigate("/login", { replace: true });
    } else {
      // show dashboard active (exceptional conditions)
      const path = location.pathname === "/" ? "dashboard" : location.pathname;
      setSelectedNavigationTab(path);
    }
  }, [location.pathname]);

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleNavigation = (path: string) => {
    setSelectedNavigationTab(path);
    navigate(path);
  };

  const overLapSideBarWindowWidth = 1279;

  useEffect(() => {
    window.innerWidth <= overLapSideBarWindowWidth &&
      setIsSidebarCollapsed(true);
  }, []);

  return (
    // <Suspense fallback={<GlobalLoader />}>
    <Suspense>
      <Outlet />
      <div
        className="flex-1 flex flex-col overflow-hidden"
        onClick={() => {
          if (
            !isSidebarCollapsed &&
            window.innerWidth <= overLapSideBarWindowWidth
          )
            setIsSidebarCollapsed(true);
        }}
      >
        <Header onToggleSidebar={toggleSidebar} />
        <div className="flex h-screen">
          <Sidebar
            collapsed={isSidebarCollapsed}
            activeSection={selectedNavigationTab}
            onNavigate={handleNavigation}
          />
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-bodybg mt-84 xs:pl-94 xl:pl-0">
            <div className="pl-6 pt-5 pr-30 pb-30">
              <RouteComponent />
            </div>
          </main>
        </div>
      </div>
    </Suspense>
  );
};

const mapStateToProps = createStructuredSelector({
  tokens: tokensSelector,
});

const connector = connect(mapStateToProps);

type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(Layout);
