import User from "pages/administration/User";
import {
  Administrationicon,
  CompanyIcon,
  DashboardIcon,
  Jobsicon,
  MaxComponentsIcon,
  Reportsicon,
  Schedulesicon,
  Transporticon,
} from "icons";
import { PiHammerDuotone } from "react-icons/pi";
import { INavOptions } from "types/layout";

export const NavigationOptions: Array<INavOptions> = [
  {
    title: "Dashboard",
    value: "dashboard",
    link: "/dashboard",
    iconDetails: {
      icon: <DashboardIcon />,
      props: { className: "w-full h-full" },
    },
    // subNavigationOptions: [],
    moduleName: ["Dashboard"],
    isAllow: true,
  },
  {
    title: "Company",
    value: "company",
    link: "/company",
    iconDetails: {
      icon: <CompanyIcon />,
      props: { className: "w-full h-full" },
    },
    isSubNavigationOpen: false,
    // subNavigationOptions: [],
    moduleName: ["Company"],
    isAllow: true,
  },
  {
    title: "Jobs",
    value: "jobs",
    link: "/jobs",
    iconDetails: {
      icon: <Jobsicon />,
      props: { className: "w-full h-full" },
    },
    isSubNavigationOpen: false,
    // subNavigationOptions: [],
    moduleName: ["Jobs"],
    isAllow: true,
  },
  {
    title: "Schedules",
    value: "schedules",
    link: "/schedules",
    iconDetails: {
      icon: <Schedulesicon />,
      props: { className: "w-full h-full" },
    },
    isSubNavigationOpen: false,
    // subNavigationOptions: [],
    moduleName: ["Schedules"],
    isAllow: true,
  },
  {
    title: "Reports",
    value: "reports",
    link: "/reports",
    iconDetails: {
      icon: <Reportsicon />,
      props: { className: "w-full h-full" },
    },
    isSubNavigationOpen: false,
    // subNavigationOptions: [],
    moduleName: ["Reports"],
    isAllow: true,
  },
  {
    title: "Transport",
    value: "transport",
    link: "/transport",
    iconDetails: {
      icon: <Transporticon />,
      props: { className: "w-full h-full" },
    },
    isSubNavigationOpen: false,
    // subNavigationOptions: [],
    moduleName: ["Transport"],
    isAllow: true,
  },
  {
    title: "Builder",
    value: "builder",
    link: "/builder",
    iconDetails: {
      icon: <PiHammerDuotone />,
      props: { className: "w-full h-full" },
    },
    isSubNavigationOpen: false,
    // subNavigationOptions: [],
    moduleName: ["Builder"],
    isAllow: true,
  },
  {
    title: "Administration",
    value: "administration",
    link: "/administration",
    iconDetails: {
      icon: <Administrationicon />,
      props: { className: "w-full h-full" },
    },
    isSubNavigationOpen: false,
    moduleName: ["Administration"],
    isAllow: true,
    subNavigationOptions: [
      {
        title: "Users",
        value: "users",
        link: "/administration/users",
        isAllow: true,
        moduleName: ["Users"],
      },
      {
        title: "Roles",
        value: "roles",
        link: "/administration/roles",
        isAllow: true,
        moduleName: ["Roles"],
      },
    ],
  },
  {
    title: "Max-Components",
    value: "max-components",
    link: "/max-components",
    iconDetails: {
      icon: <MaxComponentsIcon />,
      props: { className: "w-full h-full" },
    },
    isSubNavigationOpen: false,
    // subNavigationOptions: [],
    moduleName: ["Max-Components"],
    isAllow: true,
  },
];
