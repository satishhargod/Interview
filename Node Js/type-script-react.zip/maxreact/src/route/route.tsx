import { Route, Routes } from "react-router-dom";
import routes from "./routes";
import AuthGuard from "components/guard/AuthGuard";
import {
  IRouteAttribute,
  IRouteComponent,
  ISubRouteAttribute,
} from "types/route";
import Profile from "pages/profile/Profile";
import { useEffect, useRef } from "react";
import { profileSelector } from "redux/ducks/profile";
import { useSelector } from "react-redux";
import { UserRole, userRolesCategories } from "utils/navigation.utils";

const RouteComponent = (props?: IRouteComponent) => {
  const profileData = useSelector(profileSelector);
  // const [role, setRole] = useState<string[]>();
  const tabOptions = useRef<string[]>();

  const getUserRole = (role: string) => {
    const normalizedRole = role.toLowerCase();
    // Normalize to lowercase for case-insensitive comparison

    // Find the matching role in the enum
    const matchedRole = Object.keys(UserRole).find(
      (enumRole) => UserRole[enumRole].toLowerCase() === normalizedRole
    );

    return matchedRole || "Invalid Role";
  };

  useEffect(() => {
    const data = getUserRole(profileData?.roles[0]);
    tabOptions.current = userRolesCategories[data];
  }, []);

  return (
    <Routes>
      {routes &&
        tabOptions.current &&
        routes.map((route: IRouteAttribute, idx: number) => {
          return route.component ? (
            <Route
              key={idx}
              path={route.path}
              element={
                <AuthGuard
                  props={props}
                  modulename={route.moduleName}
                  userTabs={tabOptions.current}
                >
                  {route.component}
                </AuthGuard>
              }
            />
          ) : null;
        })}
    </Routes>
  );
};

export default RouteComponent;
