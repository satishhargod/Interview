import Dashboard from "pages/dashboard/Dashboard";
import Company from "pages/company/Company";
import User from "pages/administration/User";
import Profile from "pages/profile/Profile";
import Builders from "pages/builders/Builders";
import AddBuilder from "components/builders/AddBuilder";
import NotFound from "pages/notFound/NotFound";
import MaxComponents from "pages/maxComponents/MaxComponent";
import Job from "pages/job/Job";
import CreateJobs from "components/job/CreateJobs";
import ViewSite from "components/job/ViewSite";
import Roles from "pages/administration/Roles";
import RolesForm from "components/adminstration/roles/RolesForm";
import { CompanyIcon } from "icons";

const routes = [
  {
    path: "/dashboard",
    name: "Dashboard",
    component: <Dashboard />,
    moduleName: ["Dashboard"],
  },
  {
    path: "/company",
    name: "Company",
    icon: <CompanyIcon />,
    component: <Company />,
    moduleName: ["Company"],
  },
  {
    path: "/dashboard/profile",
    name: "Profile",
    component: <Profile />,
    moduleName: ["Profile"],
  },
  {
    path: "/jobs",
    name: "Jobs",
    component: <Job />,
    moduleName: ["Jobs"],
  },
  {
    path: "/jobs/create",
    name: "Add New Jobs",
    component: <CreateJobs />,
    moduleName: ["Jobs"],
  },
  {
    path: "/jobs/create/:data",
    name: "Add New Jobs",
    component: <CreateJobs />,
    moduleName: ["Jobs"],
  },
  {
    path: "/jobs/edit/:data",
    name: "Edit Jobs",
    component: <CreateJobs />,
    moduleName: ["Jobs"],
  },
  {
    path: "/jobs/site/view/:id",
    name: "Sites",
    component: <ViewSite />,
    moduleName: ["Jobs"],
  },
  // {
  //   path: "/schedules",
  //   name: "Schedules",
  //   // component: place Componenet here
  //   moduleName: [],
  // },
  // {
  //   path: "/reports",
  //   name: "Reports",
  //   // component: place Componenet here
  //   moduleName: [],
  // },
  // {
  //   path: "/transport",
  //   name: "Transport",
  //   // component: place Componenet here
  //   moduleName: [],
  // },
  {
    path: "/builder",
    name: "Builders",
    component: <Builders />,
    moduleName: ["Builder"],
  },
  {
    parentName:"Builder",
    parentPath:"/builder",
    path: "/builder/create",
    name: "Create Builder",
    component: <AddBuilder />,
    moduleName: ["Builder"],
  },
  {
    parentName:"Builder",
    parentPath:"/builder",
    path: "/builder/edit/:id",
    name: "Edit Builder",
    component: <AddBuilder />,
    moduleName: ["Builder"],
  },
  {
    path: "/administration/users",
    name: "Users",
    component: <User />,
    moduleName: ["Users"],
  },
  {
    path: "/administration/roles",
    name: "Roles & Permissions",
    component: <Roles />,
    moduleName: ["Roles"],
  },
  {
    path: "/administration/roles/create",
    name: "Create New Role",
    parentName:"Roles & Permissions",
    parentPath:"/administration/roles",
    component: <RolesForm />,
    moduleName: ["Roles"],
  },
  {
    path: "/administration/roles/edit/:id",
    name: "Edit Role",
    parentName:"Roles & Permissions",
    parentPath:"/administration/roles",
    component: <RolesForm />,
    moduleName: ["Roles"],
  },
  {
    path: "/max-components",
    name: "Max-Components",
    component: <MaxComponents />,
    moduleName: ["Max-Components"],
  },
  // {
  //   path: "/settings",
  //   name: "Settings",
  //   // component: place Componenet here
  //   moduleName: [],
  // },
  {
    path: "*",
    component: <NotFound />,
    moduleName: ["404"],
  },
];

export default routes;
