import { axiosDelete, axiosGet, axiosPatch, axiosPost } from "axios/config";

export const getBuilders = (filter: object) => {
  return axiosGet(`/builders`, filter);
};

export const deleteBuilder = (id: string) => {
  return axiosDelete(`/builders/${id}`);
};

export const addBuilder = (data: object) => {
  return axiosPost(`/builders`, data);
};

// export const builder = (data: object) => {
//     return axiosPost(`/builder/store`, data);
// };

export const builderById = (id:string)=>{
  return axiosGet(`/builders/${id}`)
}

export const updateBuilder = (data: object) => {
  return axiosPatch(`/builders/update`, data);
};