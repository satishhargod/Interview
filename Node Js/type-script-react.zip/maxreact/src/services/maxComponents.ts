import { axiosDelete, axiosGet, axiosPatch, axiosPost } from "axios/config";

export const getMaxComponents = (filter: object) => {
  return axiosGet(`/max/maxs`, filter);
};

export const deleteMaxComponent = (id: string) => {
  return axiosDelete(`/max/delete/${id}`);
};

export const addMaxComponent = (data: object) => {
  return axiosPost(`/max/create`, data);
};

export const getMaxComponentDetails = (id: string) => {
  return axiosGet(`/max/details/${id}`);
};

export const updateMaxComponent = (data:object) => {
  return axiosPatch(`/max/update`, data);
};
