import { axiosGet, axiosPatch, axiosPost } from "axios/config";

export const getPermissionList = () => {
    return axiosGet(`/permission/permissions`);
}

export const createRoleWithPermission = (data:object) => {
    return axiosPost(`/permission/create`,data);
}

export const getSelectedPermissions = (id:object) => {
    return axiosGet(`/permission/get-selected-permissions`,id);
}

export const updatePermission= (param:object) => {
    return axiosPatch(`/permission/update`,param)
}