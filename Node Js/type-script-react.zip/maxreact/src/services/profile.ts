import { axiosGet, axiosPost } from "axios/config";

export const updateProfile = (data: object) => {
    return axiosPost(`/auth/update-profile`, data);
  };

  export const changePassword = (data: object) => {
    return axiosPost(`/auth/change-password`, data);
  };

  export const getProfile = (id:number) => {
    return axiosGet(`/auth/user-profile/${id}`);
  };

  export async function convertFileToDataURL(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            resolve(reader.result as string);
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}