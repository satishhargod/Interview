import { axiosDelete, axiosGet, axiosPatch, axiosPost } from "axios/config";

export const getUserList = (filter?: object) => {
  return axiosGet(`/user/users`, filter);
};

export const deleteUser = (id: string) => {
  return axiosDelete(`/user/delete/${id}`);
};

export const addUser = (data: object) => {
  return axiosPost(`/user/create`, data);
};

export const getUserById = (id: string) => {
  return axiosGet(`/user/details/${id}`);
};

export const updateUser = (data:object) => {
  return axiosPatch(`/user/update`, data);
};
