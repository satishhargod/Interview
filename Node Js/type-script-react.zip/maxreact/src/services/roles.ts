import { axiosGet } from "axios/config";

export const getRoleList = (param?:object) => {
    return axiosGet(`/role/roles`,param);
}