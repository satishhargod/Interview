import { axiosDelete, axiosGet, axiosPatch, axiosPost } from "axios/config";

export const createCompany = (data: object) => {
    return axiosPost(`/company/create`, data);
  };

  export const updateCompany = (data: object) => {
    return axiosPatch(`/company/update`, data);
  };

  export const getCompanies = (values:object) => {
    return axiosGet(`/company/companies`,values);
  };

  export const deleteCompany = (id:string) => {
    return axiosDelete(`/company/delete/${id}`,)
  }

  export const getCompanyDataById=(value:string)=> {
    return axiosGet(`/company/details/${value}`);
  }