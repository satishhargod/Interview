import { store } from "redux/Store";
import { toastShow } from "redux/ducks/toast";
import libphonenumber from "google-libphonenumber";
import { MAP_API_KEY, MAP_SEARCH_URL, SEARCH_TYPE } from "./constant";
import { IAddressOptions } from "types/common/common";

export function truncateString(str: string, num: number) {
  if (str !== null ?? str.length > num) {
    return str.slice(0, num) + "...";
  } else {
    return str;
  }
}

export const companyDateFormat = (dateStr: string | Date) => {
  return new Date(dateStr as Date).toLocaleString("en", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
};

export const dispatchToast = (
  message: string,
  type: "success" | "error" | "info" | "warning" | null
) => {
  store.dispatch(toastShow({ message, type }));
};

export const isValidPhoneNumber = (value: string) => {
  if (!value) return false;

  try {
    const phoneNumberUtil = libphonenumber.PhoneNumberUtil.getInstance();
    const parsedNumber = phoneNumberUtil?.parse("+" + value, "");
    return phoneNumberUtil.isValidNumber(parsedNumber);
  } catch (error) {
    return false;
  }
};

export function removeCountryCode(
  phoneNumber: string,
  phoneUtil: any
): string | null {
  try {
    const parsedNumber = phoneUtil.parse(phoneNumber, "+1"); // "+1" default region
    if (phoneUtil.isValidNumber(parsedNumber)) {
      const nationalSignificantNumber =
        phoneUtil.getNationalSignificantNumber(parsedNumber);
      return nationalSignificantNumber;
    }
  } catch (e) {
    console.error(e);
  }
  return null;
}

export const separateCountryCodePhone = (phoneValue: string) => {
  let countryCode;
  let phone;

  const phoneNumberUtil = libphonenumber.PhoneNumberUtil.getInstance();
  try {
    if (!!phoneValue) {
      const parsedNumber = phoneNumberUtil.parse("+" + phoneValue, "");
      if (phoneNumberUtil.isValidNumber(parsedNumber)) {
        const tempCountryCode = parsedNumber?.getCountryCode();
        countryCode = tempCountryCode?.toString()!;
        const strippedPhoneNumber = removeCountryCode(
          "+" + phoneValue,
          phoneNumberUtil
        );
        phone = strippedPhoneNumber || "";
      }
    }

    if (!!countryCode && !!phone) {
      return { countryCode, phone };
    } else {
      return { countryCode: "", phone: "" };
    }
  } catch (error) {
    return { countryCode: "", phone: "" };
  }
};

export const getAddressOnSearch = async (address: string, limit = 10) => {
  let queryString = `&limit=${limit}&key=${MAP_API_KEY}`;
  try {
    let response = await fetch(
      `${MAP_SEARCH_URL}/${SEARCH_TYPE.FS}/${address}.json?minFuzzyLevel=2&maxFuzzyLevel=2&&relatedPois=off${queryString}`
    );
    const resJson = await response.json();
    let result = resJson.results;
    return result.map((x: IAddressOptions) => {
      return x.poi
        ? `${x.poi.name}, ${x.address.freeformAddress}`
        : x.address.freeformAddress;
    });
  } catch (error) {
    return null;
  }
};
