import * as Yup from "yup";

export const validateField = {
  name: Yup.string()
    .trim()
    .required("Name is Required")
    .min(4, "Name Must be at least 3+ characters long"),
  email: Yup.string()
    .trim()
    .required("Email Field is Required")
    .matches(/^[\w\.-]+@[a-zA-Z\d\.-]+\.[a-zA-Z]{2,}$/, {
      message: "Please enter a valid email",
    })
    .lowercase()
    .max(150),
  password: Yup.string()
    .trim()
    .required("Password is Required")
    .min(8, "Password must be at least 8 characters")
    .max(25, "Password must be at most 25 characters")
    .matches(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&]{8,25}$/,
      "Password must include at least one uppercase letter, one lowercase letter, one number, and one special character"
    ),
  stringPrefixJoiValidation: Yup.string().trim(),
  forgetEml: Yup.string()
    .trim()
    .required("Enter your email address to receive a password reset link")
    .matches(/^[\w\.-]+@[a-zA-Z\d\.-]+\.[a-zA-Z]{2,}$/, {
      message: "Please enter a valid email",
    })
    .max(150),
};

// For Default Image - static path
export const DEFAULT_IMAGE = {
  defaultAppLogo: "/assets/images/logo.svg",
  loginBanner: "/assets/images/Login-Banner.png",
  defaultAvatar: "/assets/images/default.png",
  defaultCardImage: "/assets/images/Max-Builders-Default.png",
  defaultDelete: "/assets/images/bin.gif",
};

export const ALLOWED_IMAGE_MIME_TYPES = [
  "image/pjpeg",
  "image/jpeg",
  "image/png",
  "image/x-png",
  "image/apng",
  "image/gif",
  "image/avif",
  "image/jpeg",
  "image/png",
  "image/svg+xml",
  "image/webp",
  "image/heic",
  "image/heif",
];

export const MAX_IMAGE_SIZE = 10 * 1024 * 1024; // 10 MB in bytes
export const EXPIRATION_TIME = 7 * 24 * 60 * 60 * 1000; // 7 days in milliseconds
export const DEFAULT_COUNTRY_CODE = "1";

export const RESPONSE_STATUS = {
  success: "success" as "success",
  error: "error" as "error",
};

export enum ErrorMessage {
  UserAssignRole = "Error in assigning User Role",
  SomethingWentWrong = "Something Went Wrong",
  RegistrationError = "Error in registration",
  AccessTokenError = "No Access Token Found ",
  UnAuthorizedUser = "Unauthorized User for this portal",
  PhoneRequire = "Phone Number Require",
  EmailVerification = "Please Verify Your Email",
  PhoneVerification = "Please Verify Your Phone",
  PhoneVerificationLink = "Error in sending phone otp",
  EmailVerificationLink = "Error in sending email otp",
  FetchAllReportError = "Error in fetching all reports",
  InvalidToken = "Invalid token",
  TokenExpired = "Token is Expired. Please Login Again!!",
}

// export const ACCOUNT_TYPE = [
//   {
//     value: "staff",
//     label: "Staff",
//   },
//   {
//     value: "worker",
//     label: "Worker",
//   },
// ];

// TOMTOM MAP
export const MAP_SEARCH_URL = "https://api.tomtom.com/search/2";
export const MAP_API_KEY = process.env.REACT_APP_TOMTOM_MAP_API_KEY as string;
export const SEARCH_TYPE = {
  RG: "reverseGeocode",
  FS: "search",
};

// used for user type in add/edit user's type
export enum USER_TYPE {
  worker = "worker",
  staff = "",
}

export const USER_TYPE_OPTION = [
  {
    value:"staff",
    label:"Staff"
  },
  {
    value:"worker",
    label:"Worker"
  },
]