export interface createJob {
    builder: string,
    bEmail: string,
    bNumber: number,
    bLocation: string
}

export interface leadDetails {
    stagesHire: number,
    hirePeriod: number,
    hStartDate: Date,
    hEndDate: Date,
    dayAfterThereAfter: number,
    contractPrice: number,
    inspectionDate: Date,
}

export interface subContractorsAllowances {
    erectPrice: number,
    dismantlePrice: number,
    alterationPrice: number,
    lytaPrice: number,
    travelPrices: number,
    totalPrice: number,
}
export interface Transport {
    totalAllowances: number,
    costAfterAllowances: number,
}

export interface AssigneeTo {
    selectStaffForInspection: string,
    assigneeWorker: string,
}