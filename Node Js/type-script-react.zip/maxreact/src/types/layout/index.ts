export interface HeaderProps {
    onToggleSidebar: React.MouseEventHandler<HTMLSpanElement>;
  }

  export interface SideBarProps {
    collapsed:boolean;
    activeSection:string;
    onNavigate:(path:string) => void
  }
export interface INavOptions {
    title: string;
    value: string;
    link: string;
    iconDetails?: {
      icon: any;
      props: any;
      hoverOrSelectedIcon?: string;
    };
    isSubNavigationOpen?: boolean;
    subNavigationOptions?:
      | {
          title: string;
          value: string;
          link: string;
          component?: any;
          status?: string
          isAllow?: boolean,
          moduleName: string[];
        }[]
      | [];
    count?: number;
    moduleName: string[];
    isAllow: boolean;
  }