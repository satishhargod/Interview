export enum ToastMessage {
    SomethingWentWrong = "Something Went Wrong",
}

export enum ToastType {
    Success = "success",
    Error = "error",
    Info = "info",
    Warning = "warning",
}
