import { ICommonField } from "../common/common";

export interface ICompanyData extends ICommonField{
  status: boolean;
  type?: string;
  createdAt: string;
  companyDetails?:companyDetail
}


export interface companyDetail{
  _id:string,
}
