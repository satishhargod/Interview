export interface AbstractDataType {
  icon: JSX.Element;
  counts: string;
  title: string;
  onClick?:()=> void
}

export interface DetailDataType {
  image: string;
  title: string;
  email: string;
  call: string;
  address: string;
  start: string;
  end: string;
}

export interface PasswordChange {
  cPassword: string;
  nPassword: string;
  rPassword: string;
}

export interface userProfile {
  file: string;
  name: string;
  email: string;
  phone: string;
  countryCode?: string | number;
}

export interface ProfileType {
  id: number;
  name: string;
  userName: string;
  email: string;
  roles: string[];
  image: string | File;
  companyId?: string;
  phone: string;
}
