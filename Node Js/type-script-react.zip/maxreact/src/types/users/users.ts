export interface IUser {
  _id?: string;
  userId?: string;
  profileImage?:string | File | null;
  type?:any;
  name: string;
  username: string;
  email: string;
  avatar?: string | File | null;
  phone: string | null;
  avatarUrl?: string;
  status: boolean | null;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  roleId?:string;
  userRoleData?: {
    name?: string;
  };
}
