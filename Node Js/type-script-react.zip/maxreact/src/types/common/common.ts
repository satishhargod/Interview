import { AccessToken, RefreshToken } from "../auth/auth";

export interface IAppProps {
  tokens: {
    accessToken: AccessToken | null;
    refreshToken: RefreshToken | null;
  };
}

export interface ICommonField {
  _id?: string;
  avatarUrl?: string;
  avatar?: string | File;
  name: string;
  email: string;
  phone: string;
  countryCode: string;
}

export enum RoleEnum {
  Admin = "admin",
  Staff = "staff",
  Worker = "worker",
  Company = "company",
}
export interface IAddressOptions {
  position: object;
  poi: { name: string };
  address: {
    freeformAddress: string;
  };
}

export interface ISelectOptions {
  value: any;
  label: string;
  icon?: JSX.Element;
}
