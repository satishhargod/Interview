export interface ISubRouteAttribute{
    name: string;
    path: string;
    icon?: JSX.Element;
    component?: JSX.Element;
    isSideBar:boolean;
    moduleName: string[];
}
export interface IRouteAttribute {
  path: string;
  icon?: JSX.Element;
  isSideBar?:boolean;
  component?: JSX.Element;
  name?: string;
  subRoute?: ISubRouteAttribute[]| null;
  moduleName: string[];
}

export interface IRouteComponent {}