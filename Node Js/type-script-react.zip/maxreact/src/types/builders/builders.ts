import { ICommonField } from "../common/common";

export interface IBuilderDetails extends ICommonField {
  // name: string;
  // email: string;
  // phone: string;
  address: string;
  profileImage?: string | File;
  startDate?: string;
  endDate?: string;
  profileImageUrl?: string;
}

export interface IBuilderPocData {
  poc: {
    name: string;
    email: string;
    phone: string;
    countryCode: string | number;
  }[];
}
