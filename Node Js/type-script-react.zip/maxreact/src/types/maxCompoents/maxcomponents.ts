export interface IMaxComponentsData {
  _id?: string;
  code: string;
  description: string;
  inventoryQty: string | number;
  createdAt?:Date | string;
  updatedAt?:Date | string;
}
