export interface Role {
    _id: string,
    slug: string,
    name: string,
    companyId?: string,
}

export interface PermissionSelected {
    name:string,
    permissionId:string,
    roleId:string,
    _id:string
}