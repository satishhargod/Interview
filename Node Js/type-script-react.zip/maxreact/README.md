# Getting Started with React-TypeScript App with Redux & Tailwind CSS

# node version will be 20.10.0
