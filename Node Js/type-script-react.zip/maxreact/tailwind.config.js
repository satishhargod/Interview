/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        Opensans: 'Open Sans',
      },
      colors: {
        BrandBlack: "#211F21",
        contentcolor: "#201E1F",
        blacklight: "#241E20",
        Darkred: "#B01115",
        inputtextcolor: "#212529",
        bodybg: "#FBF9F9",
        loginBorder: "#E5E7EB",
        menubg: "#211f210d",
        tableheaderbg: "#F4F4F4",
        tdborder: "#211f2114",
        active: "#e7f5f0",
        inactive: "#f7e7e8",
        activetext: "#0E9F6E",
        uploader: "#E9E9E9",
        mainuploader: "#F8F8F8",
        uploaderborder: "#CED4DA",
        skeletonbg: "#f6f4f6",
        activetoggle: "#89e589",

        gray: {
          400: "#CED4DA",
          600: "#6C757D",
          300: "#DEE2E6",
        },
      },
      lineHeight: {
        "150%": "150%",
        0: "0",
        12: "48px",
      },
      margin: {
        30: "30px",
        105: "105px",
        61: "61px",
        84: "84px",
        60: "60px",
        87: "87px",
      },
      padding: {
        84: "84px",
        15: "15px",
        30: "30px",
        13: "13px",
        "5px": "5px",
        25: "25px",
        "13px": "13px",
        "7px": "7px",
        94: "94px",
      },
      fontSize: {
        67: "67px",
        22: "22px",
        15: "15px",
        13: "13px",
        21: "21px",
        34: "34px",
      },
      letterSpacing: {
        1.236: "1.236px",
        0.899: "0.899px",
        0.14: "0.14px",
      },
      gap: {
        84: "84px",
        30: "30px",
      },
      maxWidth: {
        945: "945px",
        900: "900px",
        375: "375px",
        570: "570px",
        300: "300px",
        400: "400px",
        675: "675px",
        350: "350px",
      },
      height: {
        50: "50px",
        30: "30px",
        46: "46px",
        70: "70px",
        "406px": "406px",
      },
      width: {
        135: "135px",
        30: "30px",
        94: "94px",
        255: "255px",
        150: "150px",
        350: "350px",
        77: "77px",
        70: "70px",
      },
      boxShadow: {
        dropdownshadow: "0px 2px 10px 0px rgba(0, 0, 0, 0.10);",
        dialogshadow: "0px 10px 30px 5px rgba(0, 0, 0, 0.05)",
      },
      borderRadius: {
        14: "14px",
        10: "10px",
      },
      zIndex: {
        999: "999"
      }
    },
    screens: {
      xs: "280px",
      sm: "640px",
      md: "768px",
      lg: "1024px",
      xl: "1280px",
      "2xl": "1536px",
    },
    animation: {
      skeleton: "skeleton 1s linear 0s infinite",
      spin: "spin 1s linear infinite",
    },

    keyframes: {
      skeleton: {
        "0%": { left: "-20%" },
        "100%": { left: "120%" },
      },
      spin: {
        from: {
          transform: "rotate(0deg)",
        },
        to: {
          transform: "rotate(360deg)",
        },
      },
    },
  },
  plugins: [],
};
