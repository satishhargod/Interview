var Configs = {
    deploymentEnv: 'stage'
};