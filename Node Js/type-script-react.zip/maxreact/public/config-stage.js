var Configs = {
    deploymentEnv: 'stage'
};
export {};