var Configs = {
    deploymentEnv: 'prod'
};
export {};