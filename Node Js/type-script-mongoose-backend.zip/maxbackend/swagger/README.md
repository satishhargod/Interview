# Command To Run Swagger

- npm run doc:generate
