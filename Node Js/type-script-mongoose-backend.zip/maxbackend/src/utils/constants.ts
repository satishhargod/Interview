export enum UserType {
    ADMIN = 'admin',
    STAFF = "staff"
};