export const responseFlag = {
  SUCCESS: 'success',
  ERROR: 'error',
};

export const mailSubject = {
  FORGOT_PASSWORD: 'Forgot password',
};
